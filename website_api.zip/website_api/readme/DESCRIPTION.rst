Features:
 - Arhivarea categorii publice
