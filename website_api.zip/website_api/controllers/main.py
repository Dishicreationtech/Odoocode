# ©  2008-2021 Deltatech
#              Dorin Hongu <dhongu(@)gmail(.)com
# See README.rst file on addons root folder for license details

from odoo import http
from odoo.http import request
import base64
import io
from PIL import Image
from datetime import datetime

class Websession(http.Controller):

    @http.route('/web/session/authenticate/api', type='json', auth="public", cors="*", csrf=False)
    def authenticate(self, db, login, password, base_location=None):
        data_auth = request.session.authenticate(db, login, password)
        if data_auth:
            data = request.env['ir.http'].session_info()
            user = request.env.user
            user_ids = request.env['res.partner'].sudo().search([("user_id", "=", user.id)])
            data.update({
                'contacts': [{'id':contact.id, 'name': contact.name, 'mobile':  contact.mobile, 'email' : contact.email, 'user_id':user.id} for contact in user_ids]
                })
            return data
        else:
            return {'status_message': 200, 'contacts': {}}

    @http.route('/web/activiti/attachment/data', type='json', auth="public", cors="*", csrf=False)
    def Activiti(self, data=None):
        partner_ids = request.env['res.partner'].search([('id','=', data.get('partner'))])
        partner_name = partner_ids.mapped('name')
        val = False

        activty_type = request.env.ref('mail.mail_activity_data_todo').sudo()
        activity_id = request.env['mail.activity'].sudo().create({
                    'summary': data.get('activity_title'),
                    'note': data.get('remarks'),
                    'activity_type_id': activty_type.id,
                    'res_model_id': request.env['ir.model'].sudo().search([('model', '=', 'res.partner')],
                                                                       limit=1).id,
                    'res_model': 'res.partner',
                    'res_id' : data.get('partner'),
                    'user_id' : (data.get('user_id')),
                    'longitude': data.get('longitude'),
                    'latitude': data.get('latitude'),
                })
        if activity_id:
            val = True
            if data.get('images'):
                for image in data.get('images'):
                    image_data =  (image)
                activity_id.write({'image': image_data})
            if data.get('attachment'):
                attach_data =  bytes(data.get('attachment'), encoding='utf-8')
                attachment_id = request.env["ir.attachment"].sudo().create({
                        "name": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "datas":  attach_data,
                        "res_model": "mail.activity",
                        "res_id": activity_id.id,
                    })
                partner_attachment_id = request.env["ir.attachment"].sudo().create({
                        "name": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "datas":  attach_data,
                        "res_model": "res.partner",
                        "res_id" : data.get('partner'),
                    })
                activity_id.attachment_id = attachment_id.id

        return {'status_message': 200, 'activity_id': activity_id}


    @http.route('/web/contact/create/data', type='json', auth="public", cors="*")
    def Contacts(self, data=None):
        partner_id = False
        if data:
            partner_id = request.env['res.partner'].create({
                    "name": data.get('name') or '',
                    "email": data.get('email') or '',
                    "phone": data.get('phone') or '',
                    "mobile": data.get('mobile') or '',
                    "street": data.get('street') or '',
                    "city": data.get('city') or '',
                })
            partner_id.company_type = 'company'
            activty_type = request.env.ref('mail.mail_activity_data_todo').sudo()
            activity_id = request.env['mail.activity'].sudo().create({
                    'activity_type_id': activty_type.id,
                    'res_model_id': request.env['ir.model'].sudo().search([('model', '=', 'res.partner')],
                                                                       limit=1).id,
                    'res_model': 'res.partner',
                    'res_id' : partner_id.id,
                })
            if activity_id:
                val = True
                if data.get('attachment'):
                    attach_data =  bytes(data.get('attachment'), encoding='utf-8')
                    partner_attachment_id = request.env["ir.attachment"].sudo().create({
                            "name": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "datas":  attach_data,
                            "res_model": "res.partner",
                            "res_id" : data.get('partner'),
                        })
                    activity_id.attachment_id = partner_attachment_id.id


        return {'status_message': 200, 'partner_id': partner_id.name}