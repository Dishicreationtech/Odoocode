# -*- coding: utf-8 -*-
{
    'name': "Portal Accounting Reports",
    'summary': "Accounting reports in Customer portal",
    'description': "Partner ledger, aged receivable, aged payable financial reports on customer portal",
    'author': "",
    'website': "",
    'category': '',
    'version': '12.0.1.0.0',

    # any module necessary for this one to work correctly
    'depends': ['account', 'account_reports'],

    # always loaded
    'data': [
        'views/portal_accounting_templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [],
    'installable': True,
    'auto_install': False,
    'application': False,
}