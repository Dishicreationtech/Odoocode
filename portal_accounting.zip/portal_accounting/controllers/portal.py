# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import http, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.http import content_disposition, request
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DT
import json
from datetime import date
from werkzeug.exceptions import NotFound


reports_with_models = {
    'Partner Ledger': 'account.partner.ledger',
    'Aged Receivable': 'account.aged.receivable',
    'Aged Payable': 'account.aged.payable',
}


class PortalAccount(CustomerPortal):

    def _prepare_portal_layout_values(self):
        values = super(PortalAccount, self)._prepare_portal_layout_values()
        values['reports_count'] = 1
        return values

    # ------------------------------------------------------------
    # My Reports
    # ------------------------------------------------------------

    def _reports_get_page_view_values(self, document, access_token, **kwargs):
        values = {
            'page_name': 'portal_accounting',
        }
        return self._get_page_view_values(False, document, access_token, values, 'my_reports_history', False, **kwargs)

    def prepare_financial_reports_values(self):
        model_with_options = {model: request.env[model].sudo()._get_options()
                              for report_name, model in reports_with_models.items()}
        return model_with_options

    @http.route(['/my/reports'], type='http', auth="user", website=True)
    def portal_my_reports(self, **kw):
        values = self._prepare_portal_layout_values()
        values.update({
            'page_name': 'portal_accounting',
            'default_url': '/my/reports',
            'accounting_reports': reports_with_models,
        })
        return request.render("portal_accounting.portal_my_reports", values)

    def set_partners(self, options):
        logged_in_partner = request.env['res.users'].sudo().browse(request.session.uid).partner_id.id
        options['partner'] = True
        options['selected_partner_ids'] = [logged_in_partner]
        options['partner_ids'] = [logged_in_partner]
        options['selected_partner_categories'] = []
        return options

    def set_default_options_for_profit_loss(self, model, options):
        # Future purpose
        current_year = date.today().year
        # Profit and Loss
        options['date'] = {'date_from': str(date(current_year, 1, 1)),
                           'date_to': str(date(current_year, 12, 31)), 'filter': 'custom', 'string': current_year}
        if model:
            options['journals'] = request.env[model].sudo()._get_journals()
        options['unfold_all'] = True
        return options

    def set_default_options_for_account_aged_receivable(self, options):
        current_date = date.today()
        options['date'] = {'date': str(current_date), 'filter': 'today', 'string': 'As of %s' % (
            current_date.strftime(DT))}
        options['partner'] = True
        options['unfold_all'] = True
        options = self.set_partners(options)
        return options

    def set_default_options_for_account_aged_payable(self, options):
        return self.set_default_options_for_account_aged_receivable(options)

    def set_default_options_for_account_partner_ledger(self, options):
        options = self.set_default_options_for_profit_loss(False, options)
        options = self.set_partners(options)
        return options

    def download_report(self, report_type, model, options, report_obj):
        report_name = report_obj.get_report_filename(options)
        if report_type == 'pdf':
            response = request.make_response(
                request.env[model].sudo().get_pdf(options),
                headers=[
                    ('Content-Type', 'application/pdf'),
                    ('Content-Disposition', content_disposition(report_name + '.pdf'))
                ]
            )
        elif report_type == 'xlsx':
            response = request.make_response(
                None,
                headers=[
                    ('Content-Type', 'application/vnd.ms-excel'),
                    ('Content-Disposition', content_disposition(report_name + '.xlsx'))
                ]
            )
            report_obj.get_xlsx(options, response)
        else:
            raise NotFound()
        return response

    @http.route(['/print_selected_financial_report/<string:model>/<string:report_type>'], type='http', aiuth='user',
                website=True)
    def print_financial_report(self, model, report_type):
        models_with_options = self.prepare_financial_reports_values().get(model, {})
        report_obj = request.env[model].sudo()
        report_action = report_obj.with_context(model=model).print_pdf(models_with_options).get('data', {})
        options = json.loads(report_action.get("options", {}))
        if hasattr(self, f"set_default_options_for_{'_'.join(model.split('.'))}"):
            options = getattr(self, f"set_default_options_for_{'_'.join(model.split('.'))}")(options)
        response = self.download_report(report_type, model, options, report_obj)
        return response
