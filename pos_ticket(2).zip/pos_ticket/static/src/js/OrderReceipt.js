odoo.define('l10n_sa_pos.pos', function (require) {
"use strict";

var models = require('point_of_sale.models');
var core = require('web.core');
var utils = require('web.utils');

var _t = core._t;
var round_di = utils.round_decimals;


var _super_order = models.Order.prototype;
models.Order = models.Order.extend({
    export_for_printing: function() {
      var result = _super_order.export_for_printing.apply(this,arguments);
      const codeWriter = new window.ZXing.BrowserQRCodeSvgWriter()
      let qr_values = window.location.origin + "/my/pos_picking/" + result.name;
      let qr_code_svg = new XMLSerializer().serializeToString(codeWriter.write(qr_values, 150, 150));
      result.qr_code = "data:image/svg+xml;base64,"+ window.btoa(qr_code_svg);

      return result;
    },

});

});
