odoo.define('pos_ticket.pos', function(require) {
	"use strict";

	const models = require('point_of_sale.models');

	models.load_fields('res.partner', ['ref', 'company_id','loyalty_points']);
});
