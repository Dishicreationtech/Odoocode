odoo.define('pos_ticket.ClientDetailsEdit', function(require) {

    const { _t } = require('web.core');
    const ClientDetailsEdit = require('point_of_sale.ClientDetailsEdit');
    const Registries = require('point_of_sale.Registries');
    const session = require('web.session');

    const posTicketExtraField = ClientDetailsEdit => class extends ClientDetailsEdit {
        constructor() {
            super(...arguments);
            this.intFields = ['country_id', 'state_id', 'property_product_pricelist', 'company_id'];
        }
        saveChanges() {
            let processedChanges = {};
            for (let [key, value] of Object.entries(this.changes)) {
                if (this.intFields.includes(key)) {
                    processedChanges[key] = parseInt(value) || false;
                } else {
                    processedChanges[key] = value;
                }
            }
            if ((!this.props.partner.name && !processedChanges.name) ||
                processedChanges.name === '' ){
                return this.showPopup('ErrorPopup', {
                  title: _t('A Customer Name Is Required'),
                });
            }
            if ((!this.props.partner.company_id && !processedChanges.company_id) ||
                processedChanges.company_id === '' ){
                return this.showPopup('ErrorPopup', {
                  title: _t('A Company Name Is Required'),
                });
            }
            processedChanges.id = this.props.partner.id || false;
            this.trigger('save-changes', { processedChanges });
        }
    };

    Registries.Component.extend(ClientDetailsEdit, posTicketExtraField);

    return ClientDetailsEdit;
});