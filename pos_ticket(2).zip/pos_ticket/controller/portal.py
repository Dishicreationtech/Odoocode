from odoo import http
from odoo.http import request


class PosTciketController(http.Controller):

    @http.route(['/my/pos_picking/<string:name>'], auth='user', type='http')
    def receipt_receive_from_pos_ticket(self, name):
        pos = request.env['pos.order'].search([('pos_reference', '=', name)])
        action = http.request.env.ref("stock.action_picking_tree_all")
        url = '/web#id=%s&action=%s&model=stock.picking&edit=1&view_type=form' % (pos.picking_ids.ids[0], action.id)
        return request.redirect(url)