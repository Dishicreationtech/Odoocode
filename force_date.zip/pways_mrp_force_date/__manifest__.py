{
    'name': 'MRP Force Date',
    'depends': ['mrp', 'pways_stock_force_date', 'out_grower_employee'],
    'author': "Preciseways",
    'category': 'Manufacturing',
    'website': "www.preciseways.com",
    'version':"14.0.0",
    'data': ['views/mrp_production_view.xml'],
    'application': True,
    'installable': True,
    'license': 'OPL-1',
}
