# -*- coding: utf-8 -*-
from datetime import datetime
from odoo import models, fields, api, _
from odoo.fields import Datetime
from odoo.tools.float_utils import float_compare, float_round, float_is_zero
from collections import defaultdict

class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    force_date = fields.Datetime('Force Date')

    def _prepare_mrp_costing_lines(self, costing_line_ids):
        res = super(MrpProduction, self)._prepare_mrp_costing_lines(costing_line_ids)
        if self.force_date:
            for val in res:
                val.update({
                    'force_date': self.force_date,
                })
        return res

    def button_mark_done(self):
        self.move_raw_ids.filtered(lambda x: x.state not in ('done', 'cancel')).write({'force_date': self.force_date})
        self.move_finished_ids.filtered(lambda x: x.state not in ('done', 'cancel')).write({'force_date': self.force_date})
        res = super(MrpProduction, self).button_mark_done()
        if self.force_date:
            self.with_context({'force_date': True}).write({'date_planned_start': self.force_date})
        return res
