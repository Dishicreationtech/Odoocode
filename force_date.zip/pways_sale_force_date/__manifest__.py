{
    'name': 'Sale Force Date',
    'depends': ['sale_stock', 'pways_stock_force_date'],
    'author': "Preciseways",
    'category': 'Sales',
    'website': "www.preciseways.com",
    'version':"14.0.0",
    'data': ['views/sale_order_view.xml'],
    'application': True,
    'installable': True,
    'license': 'OPL-1',
}
