# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class StockMove(models.Model):
    _inherit = 'stock.move'

    def _get_new_picking_values(self):
        res = super(StockMove, self)._get_new_picking_values()
        group_id = self.mapped('group_id')
        if group_id and group_id.sale_id and group_id.sale_id.force_date:
            res['force_date'] = group_id.sale_id.force_date
        return res
