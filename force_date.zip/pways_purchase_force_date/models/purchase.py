# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def _prepare_bill_vals(self, vendor_journal_id, invoice_line_list):
        res = super(StockPicking, self)._prepare_bill_vals(vendor_journal_id, invoice_line_list)
        if self.force_date:
            res['date'] = self.force_date
            res['invoice_date'] = self.force_date
        return res

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    force_date = fields.Datetime('Force Date')

    def _prepare_picking(self):
        res = super(PurchaseOrder, self)._prepare_picking()
        if self.force_date:
            res['force_date'] = self.force_date
        return res

    def _prepare_invoice(self):
        res = super(PurchaseOrder, self)._prepare_invoice()
        if self.force_date:
            res.update({
                'invoice_date': self.force_date,
                'date': self.force_date,
            })
        return res
