{
    'name': 'Purchase Force Date',
    'depends': ['mrp', 'pways_stock_force_date'],
    'author': "Preciseways",
    'category': 'Purchase',
    'website': "www.preciseways.com",
    'version':"14.0.0",
    'data': ['views/purchase_order_view.xml'],
    'application': True,
    'installable': True,
    'license': 'OPL-1',
}
