# -*- coding: utf-8 -*-
from datetime import datetime
from odoo import models, fields, api, _
from odoo.fields import Datetime
from odoo.tools.float_utils import float_compare, float_round, float_is_zero
from collections import defaultdict
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT


class Picking(models.Model):
    _inherit = "stock.picking"

    force_date = fields.Datetime('Force Date')

    def _action_done(self):
        # self._check_company()
        # todo_moves = self.mapped('move_lines').filtered(lambda self: self.state in ['draft', 'waiting', 'partially_available', 'assigned', 'confirmed'])
        # for picking in self:
        #     if picking.owner_id:
        #         picking.move_lines.write({'restrict_partner_id': picking.owner_id.id})
        #         picking.move_line_ids.write({'owner_id': picking.owner_id.id})
        #     for move_line in picking.move_line_ids.filtered(lambda x: not x.move_id):
        #         moves = picking.move_lines.filtered(lambda x: x.product_id == move_line.product_id)
        #         moves = sorted(moves, key=lambda m: m.quantity_done < m.product_qty, reverse=True)
        #         if moves:
        #             move_line.move_id = moves[0].id
        #         else:
        #             new_move = self.env['stock.move'].create({
        #                 'name': _('New Move:') + move_line.product_id.display_name,
        #                 'product_id': move_line.product_id.id,
        #                 'product_uom_qty': move_line.qty_done,
        #                 'product_uom': move_line.product_uom_id.id,
        #                 'description_picking': move_line.description_picking,
        #                 'location_id': picking.location_id.id,
        #                 'location_dest_id': picking.location_dest_id.id,
        #                 'picking_id': picking.id,
        #                 'picking_type_id': picking.picking_type_id.id,
        #                 'restrict_partner_id': picking.owner_id.id,
        #                 'company_id': picking.company_id.id,
        #                 'force_date' : picking.force_date
        #             })
        #             move_line.move_id = new_move.id
        #             new_move._action_confirm()
        #             todo_moves |= new_move
        # todo_moves._action_done(cancel_backorder=self.env.context.get('cancel_backorder'))
        res = super(Picking, self)._action_done()
        date = self.force_date or fields.Datetime.now()
        self.write({'date_done': date, 'priority': '0'})
        return res

class StockMove(models.Model):
    _inherit = 'stock.move'

    force_date = fields.Datetime('Force Date')

    def _action_done(self, cancel_backorder=False):
        moves_todo = super(StockMove, self)._action_done(cancel_backorder=cancel_backorder)
        picking = moves_todo and moves_todo[0].picking_id or False
        date = moves_todo.mapped('force_date') and min(moves_todo.mapped('force_date')) or picking and picking.force_date or fields.Datetime.now()
        moves_todo.write({'state': 'done', 'date': date})
        return moves_todo

    def _create_account_move_line(self, credit_account_id, debit_account_id, journal_id, qty, description, svl_id, cost):
        self.ensure_one()
        with_context = {}
        if self.picking_id and self.picking_id.force_date:
            with_context = {'force_period_date': self.picking_id.force_date}
        super(StockMove, self.with_context(with_context))._create_account_move_line(credit_account_id, debit_account_id, journal_id, qty, description, svl_id, cost)

    def _create_in_svl(self, forced_quantity=None):
        svl_ids = super(StockMove, self)._create_in_svl(forced_quantity=forced_quantity)
        for svl in svl_ids:
            force_date = (svl.stock_move_id and svl.stock_move_id.force_date) or (svl.stock_move_id and svl.stock_move_id.picking_id and svl.stock_move_id.picking_id.force_date)
            if force_date:
                self.env.cr.execute("""
                       UPDATE
                       stock_valuation_layer
                       SET create_date = '%s'
                       WHERE id = %s
                       """ % (force_date, svl.id))
        return svl_ids

    def _create_out_svl(self, forced_quantity=None):
        svl_ids = super(StockMove, self)._create_out_svl(forced_quantity=forced_quantity)
        for svl in svl_ids:
            force_date = (svl.stock_move_id and svl.stock_move_id.force_date) or (svl.stock_move_id and svl.stock_move_id.picking_id and svl.stock_move_id.picking_id.force_date)
            if force_date:
                self.env.cr.execute("""
                       UPDATE
                       stock_valuation_layer
                       SET create_date = '%s'
                       WHERE id = %s
                       """ % (force_date, svl.id))

        return svl_ids

class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    force_date = fields.Datetime('Force Date')

    def _action_done(self):
        """ This method is called during a move's `action_done`. It'll actually move a quant from
        the source location to the destination location, and unreserve if needed in the source
        location.

        This method is intended to be called on all the move lines of a move. This method is not
        intended to be called when editing a `done` move (that's what the override of `write` here
        is done.
        """
        Quant = self.env['stock.quant']

        # First, we loop over all the move lines to do a preliminary check: `qty_done` should not
        # be negative and, according to the presence of a picking type or a linked inventory
        # adjustment, enforce some rules on the `lot_id` field. If `qty_done` is null, we unlink
        # the line. It is mandatory in order to free the reservation and correctly apply
        # `action_done` on the next move lines.
        ml_to_delete = self.env['stock.move.line']
        ml_to_create_lot = self.env['stock.move.line']
        tracked_ml_without_lot = self.env['stock.move.line']
        for ml in self:
            # Check here if `ml.qty_done` respects the rounding of `ml.product_uom_id`.
            uom_qty = float_round(ml.qty_done, precision_rounding=ml.product_uom_id.rounding, rounding_method='HALF-UP')
            precision_digits = self.env['decimal.precision'].precision_get('Product Unit of Measure')
            qty_done = float_round(ml.qty_done, precision_digits=precision_digits, rounding_method='HALF-UP')
            if float_compare(uom_qty, qty_done, precision_digits=precision_digits) != 0:
                raise UserError(_('The quantity done for the product "%s" doesn\'t respect the rounding precision \
                                  defined on the unit of measure "%s". Please change the quantity done or the \
                                  rounding precision of your unit of measure.') % (ml.product_id.display_name, ml.product_uom_id.name))

            qty_done_float_compared = float_compare(ml.qty_done, 0, precision_rounding=ml.product_uom_id.rounding)
            if qty_done_float_compared > 0:
                if ml.product_id.tracking != 'none':
                    picking_type_id = ml.move_id.picking_type_id
                    if picking_type_id:
                        if picking_type_id.use_create_lots:
                            # If a picking type is linked, we may have to create a production lot on
                            # the fly before assigning it to the move line if the user checked both
                            # `use_create_lots` and `use_existing_lots`.
                            if ml.lot_name and not ml.lot_id:
                                lot = self.env['stock.production.lot'].search([
                                    ('company_id', '=', ml.company_id.id),
                                    ('product_id', '=', ml.product_id.id),
                                    ('name', '=', ml.lot_name),
                                ])
                                if lot:
                                    ml.lot_id = lot.id
                                else:
                                    ml_to_create_lot |= ml
                        elif not picking_type_id.use_create_lots and not picking_type_id.use_existing_lots:
                            # If the user disabled both `use_create_lots` and `use_existing_lots`
                            # checkboxes on the picking type, he's allowed to enter tracked
                            # products without a `lot_id`.
                            continue
                    elif ml.move_id.inventory_id:
                        # If an inventory adjustment is linked, the user is allowed to enter
                        # tracked products without a `lot_id`.
                        continue

                    if not ml.lot_id and ml not in ml_to_create_lot:
                        tracked_ml_without_lot |= ml
            elif qty_done_float_compared < 0:
                raise UserError(_('No negative quantities allowed'))
            else:
                ml_to_delete |= ml

        if tracked_ml_without_lot:
            raise UserError(_('You need to supply a Lot/Serial Number for product: \n - ') +
                              '\n - '.join(tracked_ml_without_lot.mapped('product_id.display_name')))
        ml_to_create_lot._create_and_assign_production_lot()

        ml_to_delete.unlink()

        (self - ml_to_delete)._check_company()

        # Now, we can actually move the quant.
        done_ml = self.env['stock.move.line']
        for ml in self - ml_to_delete:
            date = ml.force_date or ml.move_id and ml.move_id.force_date or ml.picking_id and ml.picking_id.force_date
            if ml.product_id.type == 'product':
                rounding = ml.product_uom_id.rounding

                # if this move line is force assigned, unreserve elsewhere if needed
                if not ml._should_bypass_reservation(ml.location_id) and float_compare(ml.qty_done, ml.product_uom_qty, precision_rounding=rounding) > 0:
                    qty_done_product_uom = ml.product_uom_id._compute_quantity(ml.qty_done, ml.product_id.uom_id, rounding_method='HALF-UP')
                    extra_qty = qty_done_product_uom - ml.product_qty
                    ml._free_reservation(ml.product_id, ml.location_id, extra_qty, lot_id=ml.lot_id, package_id=ml.package_id, owner_id=ml.owner_id, ml_to_ignore=done_ml)
                # unreserve what's been reserved
                if not ml._should_bypass_reservation(ml.location_id) and ml.product_id.type == 'product' and ml.product_qty:
                    try:
                        Quant._update_reserved_quantity(ml.product_id, ml.location_id, -ml.product_qty, lot_id=ml.lot_id, package_id=ml.package_id, owner_id=ml.owner_id, strict=True)
                    except UserError:
                        Quant._update_reserved_quantity(ml.product_id, ml.location_id, -ml.product_qty, lot_id=False, package_id=ml.package_id, owner_id=ml.owner_id, strict=True)

                # move what's been actually done
                quantity = ml.product_uom_id._compute_quantity(ml.qty_done, ml.move_id.product_id.uom_id, rounding_method='HALF-UP')
                available_qty, in_date = Quant._update_available_quantity(ml.product_id, ml.location_id, -quantity, lot_id=ml.lot_id, package_id=ml.package_id, owner_id=ml.owner_id)
                if date:
                    if in_date and in_date > date:
                        in_date = Datetime.from_string(date)
                if available_qty < 0 and ml.lot_id:
                    # see if we can compensate the negative quants with some untracked quants
                    untracked_qty = Quant._get_available_quantity(ml.product_id, ml.location_id, lot_id=False, package_id=ml.package_id, owner_id=ml.owner_id, strict=True)
                    if untracked_qty:
                        taken_from_untracked_qty = min(untracked_qty, abs(quantity))
                        Quant._update_available_quantity(ml.product_id, ml.location_id, -taken_from_untracked_qty, lot_id=False, package_id=ml.package_id, owner_id=ml.owner_id)
                        Quant._update_available_quantity(ml.product_id, ml.location_id, taken_from_untracked_qty, lot_id=ml.lot_id, package_id=ml.package_id, owner_id=ml.owner_id)
                Quant._update_available_quantity(ml.product_id, ml.location_dest_id, quantity, lot_id=ml.lot_id, package_id=ml.result_package_id, owner_id=ml.owner_id, in_date=in_date)
            done_ml |= ml
        # Reset the reserved quantity as we just moved it to the destination location.
        for ml in (self - ml_to_delete).with_context(bypass_reservation_update=True):
            date = ml.force_date or ml.move_id and ml.move_id.force_date or ml.picking_id and ml.picking_id.force_date or fields.Datetime.now()
            ml.write({'product_uom_qty': 0.00, 'date': date})


class Inventory(models.Model):
    _inherit = "stock.inventory"

    force_date = fields.Datetime('Force Date')


class Inventory(models.Model):
    _inherit = "stock.inventory.line"

    def _get_move_values(self, qty, location_id, location_dest_id, out):
        self.ensure_one()
        return {
            'name': _('INV:') + (self.inventory_id.name or ''),
            'product_id': self.product_id.id,
            'product_uom': self.product_uom_id.id,
            'product_uom_qty': qty,
            'date': self.inventory_id.date,
            'company_id': self.inventory_id.company_id.id,
            'inventory_id': self.inventory_id.id,
            'state': 'confirmed',
            'restrict_partner_id': self.partner_id.id,
            'location_id': location_id,
            'location_dest_id': location_dest_id,
            'force_date': self.inventory_id.force_date,
            'move_line_ids': [(0, 0, {
                'product_id': self.product_id.id,
                'lot_id': self.prod_lot_id.id,
                'product_uom_qty': 0,  # bypass reservation here
                'product_uom_id': self.product_uom_id.id,
                'qty_done': qty,
                'package_id': out and self.package_id.id or False,
                'result_package_id': (not out) and self.package_id.id or False,
                'location_id': location_id,
                'location_dest_id': location_dest_id,
                'owner_id': self.partner_id.id,
                'force_date' : self.inventory_id.force_date
            })]
        }
        # res = super(Inventory, self)._get_move_values(qty, location_id, location_dest_id, out)
        # if self.inventory_id.force_date:
        #     res['force_date'] = self.inventory_id.force_date
        #     res['move_line_ids'][0][2]['force_date'] = self.inventory_id.force_date
        # return res

class Weighment(models.Model):
    _inherit = "grower.weighment"

    def _prepare_moves(self):
        res = super(Weighment, self)._prepare_moves()
        for move in res:
            trip_date = datetime.strptime(datetime.strftime(datetime.strptime((str(self.trip_id.trip_date) + " 01:00:00"), DEFAULT_SERVER_DATETIME_FORMAT),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
            move.update({'force_date': trip_date})
        return res