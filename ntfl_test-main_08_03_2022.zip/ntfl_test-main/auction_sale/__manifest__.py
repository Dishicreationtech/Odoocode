# -*- coding: utf-8 -*-
{
    'name': "Auction Sale",
    'summary': """Auction Sale""",
    'description': """ Auction Sale for ntfl by creating request from the sale users """,
    'author': "Preciseways",
    'website': "http://www.preciseways.com",
    'version': '14.0',
    'depends': ['sale_management','stock', 'sale_stock', 'fleet', 'hr', 'inter_warehouse_transfer'],
    'data': [
        'security/ir.model.access.csv',
        'report/auction_sale_template.xml',
        'data/auction.xml',
        'data/olial_seq.xml',
        'views/auction_request_view.xml',
        'views/truck_request.xml',
        'views/stock_picking_view.xml',
        'views/tea_arrival_view.xml',
    ],
}
