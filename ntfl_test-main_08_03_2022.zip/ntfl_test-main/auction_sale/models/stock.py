# -*- coding: utf-8 -*-
from odoo import fields, models, _
from odoo.exceptions import UserError


class StockMove(models.Model):
    _inherit = 'stock.move'

    pick_id = fields.Many2one('stock.picking')

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    sample_move_ids = fields.One2many('stock.move', 'pick_id')
    auction_request_id = fields.Many2one('auction.request')
    visible_catalog = fields.Boolean(compute='compute_visible_catalog')

    def compute_visible_catalog(self):
        for picking in self:
            if picking.transfer_id and picking.location_id.usage == 'transit' and picking.state == 'done':
                picking.visible_catalog = True
            else:
                picking.visible_catalog = False

    def action_catalog(self):
        print('CREATE CATALOG::::::::::::::::::')

    def _action_done(self):
        res = super(StockPicking, self)._action_done()
        for picking in self.filtered(lambda x: x.transfer_id.auction_request_id and x.location_dest_id.usage == 'transit'):
            for line in picking.move_line_ids:
                if not line.product_id.sample_product_id:
                    raise UserError(_('Please set sample product.'))
                quant = self.env['stock.quant'].search([('location_id', '=', picking.location_id.id), ('product_id', '=', line.product_id.sample_product_id.id), ('lot_id.name', '=', line.lot_id.name)], limit=1)
                if not quant or quant.quantity < line.qty_done:
                    raise UserError(_('Sample product not available'))
                out_move = self.env['stock.move'].create({
                    'name': line.product_id.name,
                    'pick_id': picking.id,
                    'location_id': picking.location_id.id,
                    'location_dest_id': picking.location_dest_id.id,
                    'product_id': line.product_id.sample_product_id.id,
                    'product_uom': line.product_uom_id.id,
                    'product_uom_qty': 1.0,
                })
                self.env['stock.move.line'].create({
                    'move_id': out_move.id,
                    'lot_id': quant.lot_id.id,
                    'qty_done': 1.0,
                    'product_id': line.product_id.sample_product_id.id,
                    'product_uom_id': line.product_uom_id.id,
                    'location_id': picking.location_id.id,
                    'location_dest_id': picking.location_dest_id.id,
                })
                in_picking = line.move_id.move_dest_ids.mapped('picking_id')
                in_move = self.env['stock.move'].create({
                    'name': line.product_id.name,
                    'pick_id': in_picking.id,
                    'location_id': in_picking.location_id.id,
                    'location_dest_id': in_picking.location_dest_id.id,
                    'product_id': line.product_id.sample_product_id.id,
                    'product_uom': line.product_uom_id.id,
                    'product_uom_qty': 1.0,
                    'move_orig_ids': [(4, out_move.id, 0)],
                })
                out_move._action_done()
                quant = self.env['stock.quant'].search([('location_id', '=', picking.location_dest_id.id), ('product_id', '=', line.product_id.sample_product_id.id), ('lot_id.name', '=', line.lot_id.name)], limit=1)
                self.env['stock.move.line'].create({
                    'move_id': in_move.id,
                    'lot_id': quant.lot_id.id,
                    'product_id': line.product_id.sample_product_id.id,
                    'product_uom_id': line.product_uom_id.id,
                    'location_id': in_picking.location_id.id,
                    'location_dest_id': in_picking.location_dest_id.id,
                })
                in_move._action_confirm()
                in_move._action_assign()
        for picking in self.filtered(lambda x: x.sample_move_ids and x.location_id.usage == 'transit'):
            for move in picking.sample_move_ids:
                move.write({'quantity_done': 1.0})
            picking.sample_move_ids._action_done()
        return res

class StockTransfer(models.Model):
    _inherit = 'stock.transfer'

    auction_request_id = fields.Many2one('auction.request')
