from odoo import models, fields, api, _

class TruckRequest(models.Model):
	_name = "truck.request"

	name = fields.Char(default='New',readonly=True,string="Approvel Subject")
	request_owner = fields.Char(string="Request Owner")
	category = fields.Char()
	date_confirm = fields.Date(string="Date Confirmed")
	date = fields.Date()
	reference = fields.Char()
	note = fields.Text()
	request_lines = fields.One2many("truck.request.lines", "request_id")


	@api.model
	def create(self, vals):
		if vals.get('name', 'New') == 'New':
			vals['name'] = self.env['ir.sequence'].next_by_code('truck.request') or '/'
		return super(TruckRequest, self).create(vals)


class TruckRequestLines(models.Model):
    _name="truck.request.lines"

    request_id = fields.Many2one("truck.request", string='Request ID')
    product_id = fields.Many2one("product.product", string='Product')
    quantity = fields.Float(string="Quantity",default=1)
   

