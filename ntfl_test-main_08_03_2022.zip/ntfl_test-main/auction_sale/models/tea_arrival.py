from odoo import models, fields, api, _

class TeaArrival(models.Model):
    _name = "tea.arrival"
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']
    _description = 'Tea Arrival'

    name = fields.Char(default='New',readonly=True,string="Approvel Subject")
    partner_id = fields.Many2one('res.partner', string="Estate Name")
    dispatch_id = fields.Many2one('stock.picking', string="Dispatch")
    arrival_date = fields.Date()
    transporter_id = fields.Many2one('res.partner', string="Trasporter")
    reg_no = fields.Char(string="Truck Reg. No")
    driver_id = fields.Many2one('res.partner', string="Driver")
    tea_arrival_ids = fields.One2many("tea.arrival.lines", "arrival_id")
    lines_count  = fields.Integer(compute="_get_count_list")
    sample_count = fields.Float(compute="_get_count_list")
    remarks = fields.Text(string="Remarks")

    def _get_count_list(self):
        for rec in self:
            rec.lines_count = len(rec.tea_arrival_ids)
            rec.sample_count = sum(rec.mapped('tea_arrival_ids.sample_qty'))

    @api.onchange('dispatch_id')
    def onchange_dispatch_id(self):
        line_ids = [(5,0,0)]
        if self.dispatch_id:
            picking_ids = self.env['stock.picking'].search([('id','=',self.dispatch_id.id), ('state','=','done'), ('picking_type_code', '=', 'incoming')])
            tea_line_ids = picking_ids.mapped('move_line_ids')
            sample_moves = picking_ids.mapped('sample_move_ids')
            for line in tea_line_ids:
                sample_qty = sum(sample_moves.filtered(lambda x: x.product_id.id == line.product_id.sample_product_id.id).mapped('product_uom_qty'))
                line_ids.append([0, 0, { 
                    'product_id': line.product_id.id, 
                    'lot_id': line.lot_id and line.lot_id.id,
                    'product_uom_qty': line.qty_done,
                    'product_uom': line.product_uom_id,
                    'price_unit':line.product_id.lst_price,
                    'sample_qty' : sample_qty,
                }])
        self.tea_arrival_ids = line_ids

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('tea.arrival') or '/'
        return super(TeaArrival, self).create(vals)


class TeaArrivalLines(models.Model):
    _name = "tea.arrival.lines"
    _description = 'Tea Arrival lines'

    arrival_id = fields.Many2one("tea.arrival", string='Arrival ID')
    product_id = fields.Many2one("product.product", string='Product')
    lot_id = fields.Many2one('stock.production.lot', string='Lots/Serial Number')
    product_uom_qty = fields.Float(string='Quantity', required=True, default=1.0)
    product_uom = fields.Many2one('uom.uom',string='UoM',required=True)
    grosswt = fields.Float(string="Gross wT", compute='_compute_amount')
    tarewt = fields.Float(string="Tare wT")
    netwt = fields.Float(string="Net wT", compute='_compute_amount')
    shortwt = fields.Float(string="Sort wT")
    price_unit  = fields.Float(string="Unit wT")
    warranty = fields.Char(string="Warranty No")
    sample_qty = fields.Float(string="Sample Weight")

    @api.depends('shortwt', 'product_uom_qty', 'product_id.lst_price', 'netwt', 'tarewt')
    def _compute_amount(self):
        for rec in self:
            total  = rec.product_uom_qty * rec.product_id.lst_price
            rec.netwt = total - rec.shortwt
            rec.grosswt = total + rec.tarewt - rec.shortwt
