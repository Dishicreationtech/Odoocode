# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import timedelta, datetime


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    rfq_id = fields.Many2one('auction.request')
    sale_type = fields.Selection([('local', 'Local'), ('auction', 'Auction'), ('export', 'Export'),], default='local')

    def action_truck_request(self):
        return {
            'name': _('Truck Request'),
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'truck.request',
            'target': 'new',
            'context': {'default_reference': self.name,},
        }


class AuctionRequest(models.Model):
    _name = 'auction.request'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']
    _description = 'Request For Quote'


    name = fields.Char('Name', required=True, index=True, readonly=True, copy=False, default='New')
    state = fields.Selection([('draft','Draft'),('confirm', 'Confirm'),('done', 'Done'),('cancel','Cancel')], 
        string='Status', readonly=True, index=True, 
        copy=False, default='draft', track_visibility='onchange')
    partner_id = fields.Many2one('res.partner', string="Auction Center")
    sale_date = fields.Date(string="Sales Request Date")
    street = fields.Char(string="Auction Center Address")
    street2 = fields.Char()
    zip = fields.Char(change_default=True)
    city = fields.Char()
    state_id = fields.Many2one("res.country.state", string='State', 
        ondelete='restrict', domain="[('country_id', '=', country_id)]")
    country_id = fields.Many2one('res.country', string='Country', ondelete='restrict')
    expected_delivery = fields.Date(string="Expected Delivery Date")
    remarks = fields.Text(string="Remarks")
    note = fields.Text(string="Terms & Condition")
    line_ids = fields.One2many("auction.request.line", 'request_id', string="Lines")
    warehouse_id = fields.Many2one('stock.warehouse', string='Reqested From', required=True)
    warehouse_dest_id = fields.Many2one('stock.warehouse', string='To', required=True)
    date = fields.Date(string="Date", default=fields.Date.today(), readonly=True, help="Date")
    vehicle_id = fields.Many2one('fleet.vehicle')
    date_note_no = fields.Char(string="Date Note No")
    trailer_no = fields.Char(string="Trailer No")
    security_seal = fields.Char()
    partner_id = fields.Many2one('res.partner',string='Transporter')
    delivery_id = fields.Many2one('res.partner',string="For Delivery TO")
    driver_id = fields.Many2one('res.partner',string="Driver")

    def get_report_data(self):
        data = []
        transfer_ids = self.env['stock.transfer'].search([('auction_request_id', '=', self.id)])
        picking_ids = self.env['stock.picking'].search([('transfer_id','=',transfer_ids.id),('state','=','done'),('picking_type_code', '=', 'outgoing')])
        line_ids = picking_ids.mapped('move_line_ids')
        sample_moves = picking_ids.mapped('sample_move_ids')
        for line in line_ids:
            sample_qty = sum(sample_moves.filtered(lambda x: x.product_id.id == line.product_id.sample_product_id.id).mapped('product_uom_qty'))
            total = line.qty_done * line.product_id.uom_id.factor_inv
            data.append({
                'lot_id': line.lot_id.name if line.lot_id else '',
                'product_id':line.product_id.display_name if line.product_id else '',
                'qty_done':line.qty_done if line.qty_done else '',
                'net_wt': line.product_id.uom_id.factor_inv if line.product_id else '',
                'sample_qty': sample_qty if sample_qty else '' ,
                'total_wt' :total if total else '',
                'prod_date':line.lot_id.create_date if line.lot_id else '',
            })
        return data

    def open_transfers(self):
        return {
            'name': _('Inter Warehouse Transfer'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.transfer',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('auction_request_id', '=', self.id)],
        }

    def _prepare_order_line(self, line):
        return {
            'name' : line.product_id.display_name,
            'product_id' : line.product_id.id,
            'product_uom_qty' : line.quantity,
            'product_uom_category_id': line.product_uom_id.id,
            'price_unit' : line.product_id.list_price,
        }

    def create_sale_order(self):
        lines = [(0,0, self._prepare_order_line(line)) for line in self.line_ids]
        order_id = self.env['sale.order'].create({
                'partner_id' : self.partner_id.id,
                'date_order' : fields.Date.today(),
                'rfq_id' : self.id,
                'order_line': lines,
                'payment_term_id': self.partner_id.property_payment_term_id.id,
                'pricelist_id': self.partner_id.property_product_pricelist.id,
            })
        return True

    def _prepare_transfer_line(self, line):
        return {
            'product_id': line.product_id.id,
            # 'qty': line.quantity,
        }

    def create_inter_transfer(self):
        lines = [(0, 0, self._prepare_transfer_line(line)) for line in self.line_ids]
        self.env['stock.transfer'].create({
            'type': 'receive',
            'location_id': self.warehouse_id.lot_stock_id.id,
            'location_dest_id': self.warehouse_dest_id.lot_stock_id.id,
            'auction_request_id': self.id,
            'line_ids': lines,
        })

    def action_confirm(self):
        # self.create_sale_order()
        self.create_inter_transfer()
        self.write({'state' : 'confirm'})

    def action_done(self):
        self.write({'state' : 'done'})

    def action_cancel(self):
        self.write({'state' : 'cancel'})

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('auction.request') or '/'
        return super(AuctionRequest, self).create(vals)


class AuctionRequestLine(models.Model):
    _name = 'auction.request.line'
    _description = "Request For Quote"

    product_id = fields.Many2one('product.product', string='Product', track_visibility='onchange', required=True)
    item_code = fields.Char(string="Description")
    quantity = fields.Float(string="Quantity", default=1.0)
    ready_stock = fields.Float()
    product_uom_id = fields.Many2one('uom.uom', string='Uom',)
    expected_delivery = fields.Date(string="Expected Delivery Date")
    request_id = fields.Many2one("auction.request", string="Request ID")

    @api.onchange('product_id')
    def _onchange_product_id(self):
        if self.product_id:
            self.item_code = self.product_id.display_name
            self.product_uom_id = self.product_id.uom_id.id
