from odoo import models, fields, api, _

class TruckRequest(models.Model):
    _name = "truck.request"

    name = fields.Char(default='New',readonly=True,string="Approvel Subject")
    request_owner = fields.Many2one("res.users",string="Request Owner")
    category = fields.Char()
    date_confirm = fields.Date(string="Date Confirmed")
    date = fields.Date()
    reference = fields.Char()
    note = fields.Text()
    request_lines = fields.One2many("truck.request.lines", "request_id")
    sale_id = fields.Many2one("sale.order")

    @api.model
    def default_get(self, fields):
        res = super(TruckRequest, self).default_get(fields)
        active_id = self.env.context.get('active_id')
        if active_id:
            sale_id = self.env['sale.order'].browse(active_id)
            line_ids = sale_id.order_line
            request_lines = []
            for line in line_ids:
                request_lines.append((0, 0, {'product_id': line.product_id.id, 'quantity': line.product_uom_qty}))
            res['request_lines'] = request_lines
        return res

        
    # @api.model
    # def default_get(self, fields):
    #     res = super(TruckRequest, self).default_get(fields)
    #     active_id = self.env['sale.order'].browse(self.env.context.get('active_id'))
    #     if active_id:
    #         res.update({'partner_id': ticket.partner.id, 'name' : ticket.seq})         
    #     return res

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('truck.request') or '/'
        return super(TruckRequest, self).create(vals)



class TruckRequestLines(models.Model):
    _name="truck.request.lines"

    request_id = fields.Many2one("truck.request", string='Request ID')
    product_id = fields.Many2one("product.product", string='Product')
    quantity = fields.Float(string="Quantity",default=1)
