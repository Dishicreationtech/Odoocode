# -*- coding: utf-8 -*-
{
    "name" : "User Role Managmement",
    "version" : "14.0",
    "category" : "Sales",
    'summary': 'User Role Managmement in odoo',
    "depends" : ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/res_users.xml',
    ],
    "Application": True,
    "installable": True,
}
