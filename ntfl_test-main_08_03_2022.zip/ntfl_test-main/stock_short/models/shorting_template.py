# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class SortingTemplate(models.Model):
    _name = 'sorting.template'
    _description = 'Sorting Template'

    name = fields.Char(required=True)
    product_id = fields.Many2one('product.product', string="Product", required=True)
    sorting_line = fields.One2many('sorting.template.line', 'template_id', string="Sorting Lines")
    location_id = fields.Many2one('stock.location', string='Source', domain="[('is_collection_center', '=', False)]")
    location_dest_id = fields.Many2one('stock.location', string='Designation', domain="[('is_collection_center', '=', False)]")


class SortingTemplateLine(models.Model):
    _name = 'sorting.template.line'
    _description = 'Sorting Template Lines'

    product_id = fields.Many2one('product.product', string="Product")
    template_id = fields.Many2one('sorting.template')
