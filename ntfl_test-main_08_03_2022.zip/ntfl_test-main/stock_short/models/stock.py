# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    code = fields.Selection(selection_add=[
        ('sorting', 'Sorting')
    ], ondelete={'sorting': 'cascade'})

class StockLocation(models.Model):
    _inherit = 'stock.location'

    usage = fields.Selection(selection_add=[
        ('sorting', 'Sorting')
    ], ondelete={'sorting': 'cascade'})


class StockWarehouse(models.Model):
    _inherit = 'stock.warehouse'

    sorting_location_id = fields.Many2one('stock.location', string='Sorting Location', domain="[('usage', '=', 'sorting')]")
    is_sorting = fields.Boolean()
    sorting_type_id = fields.Many2one(
        'stock.picking.type', 'Sorting Operation Type',
        domain="[('code', '=', 'sorting'), ('company_id', '=', company_id)]", check_company=True)

    def _get_sequence_values(self):
        values = super(StockWarehouse, self)._get_sequence_values()
        values.update({
            'sorting_type_id': {'name': self.name + ' ' + _('Sequence Sorting'), 'prefix': self.code + '/SRT/', 'padding': 5, 'company_id': self.company_id.id},
        })
        return values

    def _get_picking_type_update_values(self):
        data = super(StockWarehouse, self)._get_picking_type_update_values()
        data.update({
            'sorting_type_id': {
                'active': True,
                'default_location_src_id': self.lot_stock_id.id,
                'default_location_dest_id': self.lot_stock_id.id,
            },
        })
        return data

    def _get_picking_type_create_values(self, max_sequence):
        data, next_sequence = super(StockWarehouse, self)._get_picking_type_create_values(max_sequence)
        data.update({
            'sorting_type_id': {
                'name': _('Sorting'),
                'code': 'sorting',
                'sequence': next_sequence + 2,
                'sequence_code': 'SRT',
                'company_id': self.company_id.id,
            },
        })
        return data, max_sequence + 4

    # @api.model
    # def create(self, vals):
    #     res = super(StockWarehouse, self).create(vals)
    #     for location in self.env['stock.location'].search([]):
    #         if location.get_warehouse().id == res.id and not res.is_sorting:
    #             location.write({'active': False})
    #     return res

class StockMove(models.Model):
    _inherit = 'stock.move'

    sorting_ordder_id = fields.Many2one('sorting.order', 'Sorting Order')

    def _key_assign_picking(self):
        keys = super(StockMove, self)._key_assign_picking()
        return keys + (self.sorting_ordder_id,)

    @api.model
    def _prepare_merge_moves_distinct_fields(self):
        distinct_fields = super()._prepare_merge_moves_distinct_fields()
        distinct_fields.append('sorting_ordder_id')
        return distinct_fields

    @api.model
    def _prepare_merge_move_sort_method(self, move):
        keys_sorted = super()._prepare_merge_move_sort_method(move)
        keys_sorted.append(move.sorting_ordder_id.id)
        return keys_sorted
