# -*- coding: utf-8 -*-
from odoo import fields, models, api, tools, _
from odoo.tools import float_compare
from odoo.exceptions import UserError, ValidationError

class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    is_sort = fields.Boolean('Sort Operation')
    draft_sort_count = fields.Integer(compute='_compute_picking_count')
    confirm_sort_count = fields.Integer(compute='_compute_picking_count')
    in_progress_count = fields.Integer(compute='_compute_picking_count')

    def _compute_picking_count(self):
        super(StockPickingType, self)._compute_picking_count()
        for rec in self:
            rec.in_progress_count = self.env['sorting.order'].search_count([('picking_type_id', '=', rec.id), ('state', '=', 'in_progress')])
            rec.draft_sort_count = self.env['sorting.order'].search_count([('picking_type_id', '=', rec.id), ('state', '=', 'draft')])
            rec.confirm_sort_count = self.env['sorting.order'].search_count([('picking_type_id', '=', rec.id), ('state', '=', 'confirm')])

    def get_action_sort_tree(self):
        return self._get_action('stock_short.sorting_operation_template_action_id')

    def get_action_picking_tree_ready(self):
        if self.code == 'sorting':
            context = dict(self._context)
            return {
                'name': _('Sorting Order'),
                'domain': [('picking_type_id', '=', self.id), ('state', '=', 'in_progress')],
                'view_mode': 'tree,form',
                'res_model': 'sorting.order',
                'views': [[False, "tree"], [False, "form"]],
                'type': 'ir.actions.act_window',
                'context': context
            }
        return super(StockPickingType, self).get_action_picking_tree_ready()

    def action_open_draft_order(self):
        if self.code == 'sorting':
            context = dict(self._context)
            return {
                'name': _('Sorting Order'),
                'domain': [('picking_type_id', '=', self.id), ('state', '=', 'draft')],
                'view_mode': 'tree,form',
                'res_model': 'sorting.order',
                'views': [[False, "tree"], [False, "form"]],
                'type': 'ir.actions.act_window',
                'context': context
            }

    def action_open_confirm_order(self):
        if self.code == 'sorting':
            context = dict(self._context)
            return {
                'name': _('Sorting Order'),
                'domain': [('picking_type_id', '=', self.id), ('state', '=', 'confirm')],
                'view_mode': 'tree,form',
                'res_model': 'sorting.order',
                'views': [[False, "tree"], [False, "form"]],
                'type': 'ir.actions.act_window',
                'context': context
            }

class SortingOrder(models.Model):
    _name = 'sorting.order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Sorting Order'

    def _get_operation_type(self):
        return self.env['stock.picking.type'].search([('code', '=', 'sorting'), ('company_id', '=', self.env.company.id)], limit=1)

    name = fields.Char(required=True, copy=False, readonly=True, index=True, default=lambda self: _('New'))
    product_id = fields.Many2one('product.product', string="Product", required=True)
    template_id = fields.Many2one('sorting.template', string="Sorting Template")
    group_id = fields.Many2one('procurement.group', copy=False)
    product_qty = fields.Float(
        'Quantity',
        default=1.0, digits='Product Unit of Measure',
        readonly=True, required=True, tracking=True,
        states={'draft': [('readonly', False)]})
    product_uom_id = fields.Many2one(
        'uom.uom', 'Product Unit of Measure',
        domain="[('category_id', '=', product_uom_category_id)]",
        states={'draft': [('readonly', False)]},
        required=True)
    order_id = fields.Many2one('sorting.order', string="Sorting Order")
    schedule_date = fields.Datetime(string='Schedule Date', tracking=True)
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id')
    picking_type_id = fields.Many2one(
        'stock.picking.type', 'Operation Type',
        default=_get_operation_type,
        domain="[('code', '=', 'sorting'), ('company_id', '=', company_id)]",
        check_company=True)
    process_qty = fields.Float(compute='_compute_process_qty')
    location_id = fields.Many2one('stock.location', "Source Location", required=True)
    location_dest_id = fields.Many2one('stock.location', "Destination Location")
    company_id = fields.Many2one(
        'res.company', 'Company', default=lambda self: self.env.company,
        index=True, required=True)
    backorder_id = fields.Many2one(
        'sorting.order', 'Sort Back Order of',
        copy=False, index=True, readonly=True,
        check_company=True)
    sorted_date = fields.Datetime(string='Sorted Date')
    move_id = fields.Many2one('stock.move', copy=False)
    state = fields.Selection([
            ('draft', 'Draft'),
            ('confirm', 'Confirmed'),
            ('in_progress', 'Processing'),
            ('cancel', 'Cancelled'),
            ('done', 'Done')
        ], string='Status', copy=False, tracking=True,
        default='draft')
    order_line = fields.One2many('sorting.order.line', 'order_id', string="Operation lines")
    user_id = fields.Many2one('res.users', 'Responsible', default=lambda self: self.env.uid)
    lot_id = fields.Many2one(
        'stock.production.lot', 'Lot/Serial Number',
        domain="[('product_id', '=', product_id), ('company_id', '=', company_id)]", check_company=True,
        help="Lot/Serial Number of the product to unbuild.")
    # Technical field to generate same lot name for all the finished products
    lot_name = fields.Char('Lot Name for finished product')
    available_lot_ids = fields.Many2many('stock.production.lot')
    onhand_qty = fields.Float(string="Available Qty")

    @api.onchange('product_id', 'location_id')
    def _onchange_product(self):
        if self.product_id and self.location_id:
            self.template_id = False
            quants = self.env['stock.quant'].search([('location_id', '=', self.location_id.id), ('product_id', '=', self.product_id.id), ('quantity', '>', 0)])
            self.available_lot_ids = quants.mapped('lot_id').ids
        else:
            self.available_lot_ids = [(6, 0, [])]
        self.lot_id = False

    @api.onchange('lot_id')
    def _onchange_lot_id(self):
        if self.lot_id:
            quants = self.env['stock.quant'].search([('location_id', '=', self.location_id.id), ('product_id', '=', self.product_id.id), ('lot_id', '=', self.lot_id.id)])
            self.onhand_qty = sum(quants.mapped('quantity')) - sum(quants.mapped('reserved_quantity'))
        else:
            self.onhand_qty = 0.0

    def _compute_process_qty(self):
        for order in self:
            order.process_qty = 0.0
            for line in order.order_line:
                order.process_qty += line.product_uom_id._compute_quantity(line.qty, order.product_uom_id, rounding_method='HALF-UP')

    @api.onchange('picking_type_id')
    def _onchange_picking_type_id(self):
        self.location_id = self.picking_type_id.default_location_src_id and self.picking_type_id.default_location_src_id.id
        self.location_dest_id = self.picking_type_id.default_location_dest_id and self.picking_type_id.default_location_dest_id.id

    def action_draft(self):
        self.state = 'draft'
        return True

    def _prepare_moves_lines(self):
        return [(0,0,{
                'lot_id': self.lot_id.id,
                'qty_done': self.product_qty,
                'product_id': self.product_id.id,
                'product_uom_id': self.product_uom_id.id,
                'location_id': self.location_id.id,
                'location_dest_id': self.location_dest_id.id,
            })]

    def action_confirm(self):
        if self.process_qty > self.product_qty:
            raise ValidationError(_('You cannot process more than initial quantity'))
        move_id = self.env['stock.move']
        warehouse_id = self.location_id.get_warehouse()
        sorting_location_id = warehouse_id.sorting_location_id
        if not sorting_location_id:
            raise ValidationError(_('Please set sorting location on warehouse'))
        group = self.env['procurement.group'].create({
            'name': self.name,
        })
        move_line_ids = self._prepare_moves_lines()
        stock_to_virtual = self.env['stock.move'].create({
            'name': self.product_id.name,
            'product_id': self.product_id.id,
            'product_uom': self.product_uom_id.id,
            'origin': self.name,
            'group_id': group.id,
            'picking_type_id': self.picking_type_id.id,
            'location_id': self.location_id.id,
            'location_dest_id': sorting_location_id.id,
            'procure_method': 'make_to_stock',
            'product_uom_qty': self.product_qty,
            'move_line_ids' : move_line_ids,
        })
        stock_to_virtual._action_confirm()
        stock_to_virtual._action_assign()
        self.write({'state': 'confirm', 'move_id': stock_to_virtual.id})
        return True

    def action_processing(self):
        self.state = 'in_progress'
        self.move_id._action_assign()
        if self.move_id.state != 'assigned':
            raise ValidationError(_('Product is not Available {}'.format(self.move_id.product_id.name)))
        # check if avaialble the process 
        return True

    def action_done(self):
        today = fields.Date.today()
        for order in self:
            if order.process_qty > order.product_qty:
                raise ValidationError(_('You cannot process more than initial quantity'))
            todo_qty = order.product_qty - order.process_qty
            if todo_qty > 0:
                new_wizard = self.env['sorting.backorder.wizard'].create({})
                view_id = self.env.ref('stock_short.view_sorting_backorder_form').id

                return {
                    'type': 'ir.actions.act_window',
                    'name': _('Create Backorder'),
                    'view_mode': 'form',
                    'res_model': 'sorting.backorder.wizard',
                    'target': 'new',
                    'res_id': new_wizard.id,
                    'views': [[view_id, 'form']],
                }
            else:
                stock_move = self.env['stock.move']
                for line in self.order_line.filtered(lambda x: x.qty > 0):
                    move_id = self.env['stock.move'].create(line.prepare_moves())
                    stock_move = move_id._action_confirm()
                    stock_move._action_done()
                    line.write({'move_id': stock_move})
                order.move_id.write({'quantity_done': self.product_qty})
                order.move_id._action_done()
            order.sorted_date = today
        self.state = 'done'

    def action_cancel(self):
        self.move_id._action_cancel()
        self.state = 'cancel'
        return True

    def _prepare_template_lines(self, line):
        return {
            'product_id': line.product_id and line.product_id.id or False,
            'product_uom_id': self.product_uom_id and self.product_uom_id.id,
            'location_dest_id': self.location_dest_id and self.location_dest_id.id,
        }

    @api.onchange('product_id')
    def onchange_product_id(self):
        for order in self:
            order.product_uom_id = order.product_id.uom_id and order.product_id.uom_id.id
        if self.product_id:
            template_ids = self.env['sorting.template'].search([('product_id', '=', self.product_id.id)])
            return {'domain': {'template_id': [('id', 'in', template_ids.ids)]}}

    @api.onchange('template_id', 'product_uom_id', 'location_dest_id')
    def onchange_template_id(self):
        self.order_line = [(5, 0, 0)]
        if self.template_id and self.template_id.sorting_line:
            lines = [(0, 0, self._prepare_template_lines(line)) for line in self.template_id.sorting_line]
            self.order_line = lines
            self.location_id = self.template_id.location_id.id
            self.location_dest_id = self.template_id.location_dest_id.id

    @api.model
    def create(self, vals):
        picking_type = self._get_operation_type()
        if picking_type.sequence_id:
            vals['name'] = picking_type.sequence_id.next_by_id()
        return super(SortingOrder, self).create(vals)

class SortingOrderLine(models.Model):
    _name = 'sorting.order.line'
    _description = 'sorting order lines'

    product_id = fields.Many2one('product.product', string="Product")
    qty = fields.Float('Quantity', default=0.0, digits='Product Unit of Measure')
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id')
    product_uom_id = fields.Many2one('uom.uom', 'Unit of Measure', required=True, domain="[('category_id', '=', product_uom_category_id)]",)
    order_id = fields.Many2one('sorting.order', string="Sorting Order")
    location_dest_id = fields.Many2one('stock.location', "Destination Location")
    move_id = fields.Many2one('stock.move', copy=False)
    lot_id = fields.Many2one(
        'stock.production.lot', 'Lot/Serial Number',
        domain="[('product_id', '=', product_id), ('company_id', '=', move_id.company_id)]", check_company=True,
        help="Lot/Serial Number of the product to unbuild.")

    def get_price_unit(self):
        price = self.product_id.standard_price if self.product_id else 0.0
        if self.product_id and self.product_id.categ_id and self.product_id.categ_id.property_cost_method != 'standard':
            price = self.order_id.move_id.stock_valuation_layer_ids.value
        total_cost = self.order_id.total_amount
        price_unit = (price + total_cost) / self.order_id.process_qty
        return price_unit

    def _prepare_moves_lines(self):
        warehouse_id = self.location_dest_id.get_warehouse()
        sorting_location_id = warehouse_id.sorting_location_id
        lot_name = lot_name =  self.order_id.lot_name or self.env['ir.sequence'].next_by_code('stock.production.lot')
        lot_id = self.env['stock.production.lot'].create({'product_id' : self.product_id.id, 'name' : lot_name, 'company_id' : self.order_id.company_id.id})
        if not self.order_id.lot_name:
            self.order_id.lot_name = lot_id.name
        self.lot_id = lot_id.id
        move_line_id = self.order_id.move_id.move_line_ids.ids[0] if self.order_id.move_id.move_line_ids else False

        return [(0,0,{
                'lot_id': lot_id.id,
                'qty_done':  self.qty,
                'product_id': self.product_id.id,
                'product_uom_id': self.product_uom_id.id,
                'location_id': sorting_location_id.id,
                'location_dest_id': self.location_dest_id.id or self.order_id.location_dest_id.id,
                'consume_line_ids': [(4, move_line_id, 0)]

            })]

    def prepare_moves(self):
        warehouse_id = self.location_dest_id.get_warehouse()
        sorting_location_id = warehouse_id.sorting_location_id
        price_unit = self.get_price_unit()
        values = {
            'name': self.product_id.name,
            'product_id': self.product_id.id,
            'product_uom': self.product_uom_id.id,
            'origin': self.order_id.name,
            'group_id': self.order_id.group_id.id,
            'picking_type_id': self.order_id.picking_type_id.id,
            'location_id': sorting_location_id.id,
            'location_dest_id': self.location_dest_id.id or self.order_id.location_dest_id.id,
            'procure_method': 'make_to_stock',
            'product_uom_qty': self.qty,
            'quantity_done': self.qty,
            'price_unit': price_unit,
        }
        if self.product_id.tracking == 'lot':
            move_line_ids = self._prepare_moves_lines()
            values.update({'move_line_ids' : move_line_ids})
        return values
