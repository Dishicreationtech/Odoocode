{
    'name': "Sorting Operations",
    "category": "stock",
    'summary':""" Sorting Operations """,
    'depends': ['mail', 'stock', 'mrp'],
    'data': [
        'security/ir.model.access.csv',
        'data/stock_data.xml',
        'views/stock_view.xml',
        'views/shorting_template_view.xml',
        'views/shorting_order_view.xml',
        'wizard/shorting_backorder_wizard.xml',
    ],
    'post_init_hook': '_create_warehouse_data',
    'installable' : True,
    'application' :  True,
}
