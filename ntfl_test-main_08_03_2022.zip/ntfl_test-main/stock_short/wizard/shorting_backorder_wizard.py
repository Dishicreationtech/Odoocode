# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class SortingBackorderWizard(models.TransientModel):
    _name = 'sorting.backorder.wizard'
    _description = 'Sorting Backorder Wizard'

    def action_create_backorder(self):
        active_id = self.env.context.get('active_id')
        sorting_order = self.env['sorting.order'].browse(active_id)
        todo_qty = sorting_order.product_qty - sorting_order.process_qty
        return_sort_order = sorting_order.copy({
            'product_qty': todo_qty,
            'product_id': sorting_order.product_id.id,
            'template_id': sorting_order.template_id.id,
            'backorder_id': sorting_order.id,
            'move_id': False,
        })
        for line in sorting_order.order_line.filtered(lambda x: x.qty > 0):
            move_id = self.env['stock.move'].create(line.prepare_moves())
            stock_move = move_id._action_confirm()
            stock_move._action_done()
            line.write({'move_id': stock_move})
        sorting_order.move_id.write({'quantity_done': sorting_order.process_qty})
        back_move = sorting_order.move_id._action_done(cancel_backorder=False)
        sorting_order.write({'state': 'done'})
        return_sort_order.onchange_template_id()
        return_sort_order.write({'move_id': back_move.id})
        return True

    def action_no_create_backorder(self):
        stock_move = self.env['stock.move']
        active_id = self.env.context.get('active_id')
        sorting_order = self.env['sorting.order'].browse(active_id)
        sorting_order.write({'product_qty': sorting_order.process_qty})
        for line in sorting_order.order_line.filtered(lambda x: x.qty > 0):
            move_id = self.env['stock.move'].create(line.prepare_moves())
            stock_move = move_id._action_confirm()
            stock_move._action_done()
            line.write({'move_id': stock_move})
        sorting_order.move_id.write({'quantity_done': sorting_order.product_qty})
        sorting_order.move_id._action_done(cancel_backorder=True)
        sorting_order.write({'state': 'done'})
        return True
