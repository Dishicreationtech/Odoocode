# -*- coding: utf-8 -*-
{
    'name': 'Outgrow Odoo SQL',
    'version': '14.0',
    'author': 'Brown Boy',
    "depends": ['out_grower', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'views/res_compnay.xml',
        'views/farmer_sync_view.xml',
        'views/fatch_quary_data.xml',
        'wizard/out_grower_sync_operation.xml',
        'data/cron.xml',
        ],
    "images":[],
    'application': True,
    'installable': True,
}
