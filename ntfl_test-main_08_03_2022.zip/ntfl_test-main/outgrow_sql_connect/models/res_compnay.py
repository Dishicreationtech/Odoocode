# -*- coding: utf-8 -*-

from odoo import fields, models
import logging
_logger = logging.getLogger(__name__)
import pymysql.cursors
no_pymysql = False
try:
    import pymysql.cursors
except ImportError:
    no_pymysql = True

class OdooPsql(models.Model):
    _inherit = "res.company"
    _description = "Odoo To Odoo"

    mysql_host_name = fields.Char(string="My HOST")
    mysql_port = fields.Char(string="Port")
    mysql_user_name = fields.Char(string="User")
    mysql_passwd = fields.Char(string="Password")
    mysql_db = fields.Char(string="Database")

    def _connect_mysql_instance(self):
        if (not self.mysql_host_name) or (not self.mysql_port) or (not self.mysql_user_name) or (not self.mysql_passwd) or (not self.mysql_db):
            _logger.info("Getting an Error set configuration Company: {0}".format(e))
        try:
            db = pymysql.connect(host=self.mysql_host_name, port=int(self.mysql_port), user=self.mysql_user_name, passwd=self.mysql_passwd, db=self.mysql_db)
            return db
        except Exception as e:
            _logger.info("Getting an Error in database connection: {0}".format(e))
            return e

    def check_pymsql_package(self):
        if no_pymysql:
            _logger.error(_('Missing required Mysql package python package : https://pypi.org/project/PyMySQL/'))
        return True

    def execute_odoo_mysql(self, quary, data):
        self.check_pymsql_package()
        mysql_instance = self._connect_mysql_instance()
        mycursor = mysql_instance.cursor()
        print("rewer", quary, data)
        try:
            mycursor.executemany(quary, data)
            mysql_instance.commit()
            return True
        except Exception as e:
            _logger.info("Getting an Error MYSQL: {0}".format(e))
            return e