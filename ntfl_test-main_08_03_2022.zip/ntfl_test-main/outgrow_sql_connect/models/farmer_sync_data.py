# -*- coding: utf-8 -*-

from odoo import models,fields,api,_
import datetime
import logging
_logger = logging.getLogger(__name__)
import pymysql.cursors
no_pymysql = False
try:
    import pymysql.cursors
except ImportError:
    no_pymysql = True

class Partner(models.Model):
    _inherit = 'res.partner'

    odoo_mysql = fields.Boolean(string="Mysql")

class FarmerRegistration(models.Model):
    _inherit = 'farmer.registration'

    odoo_mysql = fields.Boolean(string="Mysql")

    def _prepare_farmer_info(self):
        farmer_info = []
        farmer_ids = self.env['res.partner'].sudo().search([('supplier_rank', '>', 0), ('odoo_mysql', '=', False)])
        for farmer in farmer_ids:
            farmer.odoo_mysql = True
            farmer_info.append((str(farmer.id), farmer.name))
        return farmer_info  

    def sync_farmer_data(self):
        company_id = self.env.company
        data = self._prepare_farmer_info()
        if data:
            quary = "INSERT INTO farmer_info (farmer_id, name) VALUES(%s, %s)"
            company_id.execute_odoo_mysql(quary, data)
        return True

class Trip(models.Model):
    _inherit = "fleet.vehicle"

    odoo_mysql = fields.Boolean(string="Mysql")

    def _prepare_vehicle_info(self):
        vehicle_info = []
        for record in self.search([('odoo_mysql', '=', False)]):
            record.odoo_mysql = True
            vehicle_license = record.license_plate if record.license_plate else ""
            vehicle_info.append((str(record.id), vehicle_license))
        return vehicle_info  

    def sync_vehicle_data(self):
        company_id = self.env.company
        data = self._prepare_vehicle_info()
        if data:
            quary = "INSERT INTO vehicle_info (vehicle_id, vehicle_no) VALUES(%s, %s)"
            company_id.execute_odoo_mysql(quary, data)
        return True

class Routes(models.Model):
    _inherit = 'routes.routes'
    
    odoo_mysql = fields.Boolean(string="Mysql")

    def _prepare_route_info(self):
        route_info = []
        for record in self.search([('odoo_mysql', '=', False)]):
            record.odoo_mysql = True
            route_info.append((str(record.id), record.name))
        return route_info  

    def route_sync_data(self):
        company_id = self.env.company
        data = self._prepare_route_info()
        if data:
            quary = "INSERT INTO route_info (route_id, route_name) VALUES(%s, %s)"
            company_id.execute_odoo_mysql(quary, data)
        return True

class Gateweighment(models.Model):
    _inherit = 'gate.weighment'

    boiler_cubic = fields.Char(string="Boiler Cubic")
    delvnote_no = fields.Char(string="Delvnote")
    delvnote_date = fields.Date(string="Delvnote Date")