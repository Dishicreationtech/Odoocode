# -*- coding: utf-8 -*-
from odoo import models,fields

class SyncOperation(models.TransientModel):
    _name = 'out.grower.sync.operation'
    _description = "Sync Operation"

    farmer_sync_data = fields.Boolean(string="Farmer Sync")
    vehicle_sync_data = fields.Boolean(string="Vehicle Sync")
    route_id_sync_data = fields.Boolean(string="Route Sync")
    trip_sync_data = fields.Boolean(string="Trip Sync")

    def perform_operation(self):
        if self.farmer_sync_data:
            self.env['farmer.registration'].sync_farmer_data()
        if self.vehicle_sync_data:
            self.env['fleet.vehicle'].sync_vehicle_data()
        if self.route_id_sync_data:
            self.env['routes.routes'].route_sync_data()
        return {
            'effect': {
                'fadeout': 'slow',
                'message': "Process Completed Successfully! {}".format(""),
                'img_url': '/web/static/src/img/smile.svg',
                'type': 'rainbow_man',
            }
        }