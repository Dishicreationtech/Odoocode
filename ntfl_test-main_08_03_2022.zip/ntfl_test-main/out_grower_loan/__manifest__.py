# -*- coding: utf-8 -*-
{
    'name': "Out Growers Loan",
    'summary': """Out Growers Loan""",
    'description': """ Out Growers Loan""",
    'author': "Jignesh Rathod",
    'website': "",
    'version': '14.0',
    'depends': ['out_grower_extended'],
    'data': [
        'security/ir.model.access.csv',
        'data/ir_sequence.xml',
        'views/out_grower_loan.xml',
        ],
}
