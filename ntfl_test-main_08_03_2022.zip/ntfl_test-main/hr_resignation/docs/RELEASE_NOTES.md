## Module hr_resignation

#### 07.04.2018
#### Version 11.0.1.0.0
##### ADD
- Initial Commit

#### 20.10.2018
#### Version 11.0.1.0.1
##### UPDT
- Field label change

#### 20.10.2018
#### Version 11.0.2.0.0
##### ADD
- Resignation Field in Employee Master
