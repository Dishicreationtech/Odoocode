# -*- coding: utf-8 -*-
{
    'name' : 'Indent Request',
    'summary': 'Indent Request',
    'sequence': 1,
    'description': """ Indent Request """,
    'depends': ['hr', 'stock', 'purchase', 'purchase_requisition_stock'],
    'data': [
        'data/indent_request_data.xml',
        'security/res_groups.xml',
        'security/ir.model.access.csv',
        'views/indent_request_view.xml',
        'views/hr_department_view.xml',
        'views/purchase_order_view.xml',
        'report/indent_request_report.xml',
        'wizard/indent_request_wizard.xml',
        'wizard/merge_tender_view.xml',
    ],
    'installable': True,
    'application': True,
}