# -*- coding: utf-8 -*-
from . import private_details
from . import hr_job
from . import hr_applicant_parameters
from . import casual_labour
from . import medical_report
