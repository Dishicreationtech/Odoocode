# -*- coding: utf-8 -*-
from odoo import fields, models, api

class HRApplicant(models.Model):
    _name = 'hr.applicant.parameters'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Name")
    

class HRApplicant(models.Model):
    _inherit = 'hr.applicant'

    parameters_id = fields.Many2one('hr.applicant.parameters', string="Parameter")
    job_number = fields.Char(string="Job Number")
    first_app  = fields.Boolean("First Approval")
    second_app = fields.Boolean("Second Approval")
    # # stage_id = fields.Many2one('hr.recruitment.stage')

    def first_approval(self):
        self.ensure_one()
        first = self.env.ref('out_grower_employee.stage_job6')
        self.first_app = True
        self.stage_id = first and first.id


    def second_approval(self):
        self.ensure_one()
        second = self.env.ref('out_grower_employee.stage_job7')
        self.second_app = True
        self.stage_id = second and second.id

class Department(models.Model):
    _inherit = "hr.department"

    kpi_parameter_ids = fields.Many2many('hr.applicant.parameters', string="KPI")
    job_id = fields.Many2one('hr.job',string="Job Position")