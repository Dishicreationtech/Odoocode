from odoo import api, fields, models, _
from odoo.exceptions import UserError

class CasualPaymentWizard(models.TransientModel):
    _name = "casual.payment.wizard"
    _description = "Casual Payment"

    casual_id = fields.Many2one('casual.labour', string="Casual")
    journal_id = fields.Many2one('account.journal', string='Journal', required=True)
    date = fields.Date(string="Date", default=fields.Date.today(), required=True)

    @api.model
    def default_get(self, fields):
        vals = super(CasualPaymentWizard, self).default_get(fields)
        active_ids = self.env.context.get('active_id', False)
        vals['casual_id'] = active_ids
        return vals

    def create_payment_entry(self):
        company_id = self.env.company
        for employee in self.casual_id.attendances_ids.mapped('employee_id'):
            total_employes_ids = self.casual_id.attendances_ids.filtered(lambda x : x.employee_id == employee)
            total_worked = sum(total_employes_ids.mapped('worked_hours'))
            payment_dict = {
                'payment_type': 'outbound',
                'partner_type': 'supplier',
                'ref': _("Casual") + " - " + self.casual_id.name,
                'partner_id': employee.emp_partner_id and employee.emp_partner_id.id,
                'journal_id': self.journal_id and self.journal_id.id,
                'company_id': company_id and company_id.id,
                'date': self.date,
                'amount': employee.hourly_rate * total_worked,
                'casual_id' : self.casual_id.id
                }
            payment_id = self.env['account.payment'].create(payment_dict)
        return True

    def create_payment(self):
        self.create_payment_entry()
        return True