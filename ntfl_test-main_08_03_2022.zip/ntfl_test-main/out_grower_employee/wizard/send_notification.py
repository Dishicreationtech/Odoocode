# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class SendMedicalNotification(models.TransientModel):
    _name = "send.medical.notification"

    employee_ids  = fields.Many2many('hr.employee')

    @api.model
    def default_get(self, fields_list):
        res = super(SendMedicalNotification, self).default_get(fields_list)
        active_ids = self.env.context.get('active_ids', False)
        if active_ids:
            report_lines = self.env['medical.report.line'].browse(active_ids)
            res.update({'employee_ids': [(6, 0, report_lines.mapped('employee_id').ids)]})
        return res

    def send_notification(self):
        active_ids = self.env.context.get('active_ids', False)
        for rec in self.env['medical.report.line'].browse(active_ids):
            if rec.employee_id:
                template_id = self.env.ref('out_grower_employee.employee_medical_mail_template')
                if template_id:
                    template_id.send_mail(rec.id, force_send=True)
                    rec.process = True
        return True


