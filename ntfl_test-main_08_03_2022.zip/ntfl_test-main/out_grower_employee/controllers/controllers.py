from odoo import http
from odoo.addons.sale.controllers.portal import CustomerPortal
from odoo.http import request


