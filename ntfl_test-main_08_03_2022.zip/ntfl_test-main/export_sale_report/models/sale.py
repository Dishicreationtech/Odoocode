from odoo import api,fields,models

class SaleOrder(models.Model):
	_inherit = "sale.order"

	def _prepare_invoice(self):
		res = super(SaleOrder,self)._prepare_invoice()
		print("PPPPIIIII", res)
		res.update({
			'container_no' : self.container_no,
			'mark' : self.mark,
			'contract': self.contract,
			'packages': self.packages,
			'shippers': self.shippers,
			'shipped_per': self.shipped_per,
			'vessel': self.vessel,
			'port_of_loading': self.port_of_loading,
			'port_of_discharge': self.port_of_discharge,
		})		
		return res

	container_no = fields.Char(string="Container No")
	mark = fields.Char()
	contract = fields.Char() 
	packages = fields.Float(string="Packages")
	shippers = fields.Char(string="Shippers Seal")
	shipped_per = fields.Char(string="Shipped Per")
	vessel = fields.Char()
	port_of_loading = fields.Char(string="Port of Loading")
	port_of_discharge = fields.Char(string="Port of Discharge")

			
class StockMove(models.Model):
	_inherit = "stock.move"

	pkgs = fields.Float()
	net_weight = fields.Float(string="Net Weight/Bag")
	tare = fields.Float(string="Tare(Kgs)")
	gross  = fields.Float()
	date_of_manufacture = fields.Date(string="DATE OF MANUFACTURE")
	expiry_date = fields.Date(string="EXPIRY DATE")
	container_no = fields.Char(string="Container No")
	mark = fields.Char()
	contract = fields.Char() 
	packages = fields.Float(string="Packages")
	shippers = fields.Char(string="Shippers Seal")
	shipped_per = fields.Char(string="Shipped Per")
	vessel = fields.Char()
	port_of_loading = fields.Char(string="Port of Loading")
	port_of_discharge = fields.Char(string="Port of Discharge")

	def _get_new_picking_values(self):
		res = super(StockMove,self)._get_new_picking_values()
		if self.sale_line_id:
			sale_order = self.sale_line_id.order_id
			res.update({
				'container_no' : sale_order.container_no,
				'mark' : sale_order.mark,
				'contract': sale_order.contract,
				'packages': sale_order.packages,
				'shippers': sale_order.shippers,
				'shipped_per': sale_order.shipped_per,
				'vessel': sale_order.vessel,
				'port_of_loading': sale_order.port_of_loading,
				'port_of_discharge': sale_order.port_of_discharge,
			})		
		return res

class StockPicking(models.Model):
	_inherit = "stock.picking"

	container_no = fields.Char(string="Container No")
	mark = fields.Char()
	contract = fields.Char() 
	packages = fields.Float(string="Packages")
	shippers = fields.Char(string="Shippers Seal")
	shipped_per = fields.Char(string="Shipped Per")
	vessel = fields.Char()
	port_of_loading = fields.Char(string="Port of Loading")
	port_of_discharge = fields.Char(string="Port of Discharge")
	sale_type = fields.Selection(related="sale_id.sale_type",store="True")


class AccountMove(models.Model):
	_inherit = "account.move"

	container_no = fields.Char(string="Container No")
	mark = fields.Char()
	contract = fields.Char() 
	packages = fields.Float(string="Packages")
	shippers = fields.Char(string="Shippers Seal")
	shipped_per = fields.Char(string="Shipped Per")
	vessel = fields.Char()
	port_of_loading = fields.Char(string="Port of Loading")
	port_of_discharge = fields.Char(string="Port of Discharge")

class AccountMoveLine(models.Model):
	_inherit = "account.move.line"

	pkgs = fields.Float()
	net_weight = fields.Float(string="Net Weight/Bag")
	tare = fields.Float(string="Tare(Kgs)")
	gross  = fields.Float()
