# -*- coding: utf-8 -*-
{
    'name': "Export Sale Report",
    'summary': """Export sale report for ntfl""",
    'description': """Export sales report""",
    'version': '14.0',
    'depends': ['sale_stock','auction_sale'],
    'data': [

        'reports/report.xml',
        'reports/report_template.xml',
        'reports/export_summary_template.xml',
        'reports/commercial_invoice_template.xml',
        'views/sale_order_view.xml',    
        'views/stock_move_view.xml',    
        'views/account_move.xml',    
    ],
}
