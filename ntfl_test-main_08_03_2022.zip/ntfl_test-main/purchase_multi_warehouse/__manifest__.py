# -*- coding: utf-8 -*-
{
    "name": "Purchase Multi Warehouse",
    "version":"14.0",
    "category": "Purchase",
    "depends": ['purchase', 'sale_stock', 'purchase_stock'],
    "data": [
        'views/purchase_order_view.xml',
    ],
    "installable": True,
    "application": True,
}
