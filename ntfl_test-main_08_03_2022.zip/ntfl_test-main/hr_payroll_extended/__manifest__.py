# -*- coding: utf-8 -*-
{
    'name': "HrPayslip Extended",
    'summary':'Hr Payslip Extended',
    'description': 'HrPayslip Extended',
    'category': 'HR',
    'version': '14.0.1',
    'depends': ['hr_payroll', 'hr_holidays', 'hr_contract', 'hr_attendance'],
    'data': [
        'views/hr_payslip_view.xml'
    ],
}
