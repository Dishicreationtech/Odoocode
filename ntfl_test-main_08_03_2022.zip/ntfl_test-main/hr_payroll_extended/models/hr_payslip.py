# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    def get_attendance_days_time(self):
        attendance_ids = self.env['hr.attendance'].search([('check_in', '>=', self.date_from), ('check_out', '<=', self.date_to), ('employee_id', '=', self.employee_id.id)])
        leave_ids = self.env['hr.leave'].search([('date_from', '>=', self.date_from), ('date_to', '<=', self.date_to), ('employee_id', '=', self.employee_id.id)])
        min_time = self.contract_id.min_time or 0.0
        max_time = self.contract_id.max_time or 0.0
        worked_hours = 0.0
        number_of_days = 0.0
        for record in attendance_ids:
            if min_time <= record.worked_hours and max_time >= record.worked_hours:
                worked_hours+=record.worked_hours
                number_of_days+=0.5
            if max_time < record.worked_hours:
                worked_hours+=record.worked_hours
                number_of_days+=1
        leave_ids = leave_ids.filtered(lambda x: x.holiday_status_id and x.holiday_status_id.is_paid)
        for leave in leave_ids:
            if leave.holiday_status_id.request_unit == 'day':
                number_of_days+=leave.number_of_days
            if leave.holiday_status_id.request_unit == 'half_day':
                number_of_days+=0.5
            if leave.holiday_status_id.request_unit == 'hours':
                if min_time <= leave.number_of_hours_display and max_time >= leave.number_of_hours_display:
                    number_of_days+=0.5
                if max_time < leave.number_of_hours_display:
                    worked_hours+=record.number_of_hours_display
                    number_of_days+=1
        return number_of_days, worked_hours
    
    def _get_new_worked_days_lines(self):
        if self.struct_id.use_worked_day_lines:
            # computation of the salary worked days
            worked_days_line_values = self._get_worked_day_lines()
            if not self.contract_id.min_time and not self.contract_id.max_time:
                raise ValidationError(_('''Please define max time and min time in contract'''))
            number_of_days, worked_hours = self.get_attendance_days_time()
            worked_days_lines = self.worked_days_line_ids.browse([])
            for r in worked_days_line_values:
                r['number_of_days'] = number_of_days
                r['number_of_hours'] = worked_hours
                r['payslip_id'] = self.id
                worked_days_lines |= worked_days_lines.new(r)
            print("WOOOOOO", worked_days_lines)
            return worked_days_lines

class HrContract(models.Model):
    _inherit = "hr.contract"

    min_time = fields.Float(string="Min Time")
    max_time = fields.Float(string="Max Time")

class HrLeaveType(models.Model):
    _inherit = 'hr.leave.type'

    is_paid = fields.Boolean(string="Paid")