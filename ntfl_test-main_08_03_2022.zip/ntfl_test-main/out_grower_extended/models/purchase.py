# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class Purchase(models.Model):
    _inherit = "purchase.order"

    is_firewood = fields.Boolean(string="Firewood Product")
    purchase_type = fields.Selection([
        ('firewood', 'Firewood'),
        ('general_purchase', 'General Purchase'),
    ], required=True, default='firewood',
        help="The 'purchase_type Type' is used for features available on "\
        "different types of purchase order")

    @api.onchange('purchase_type')
    def _onchange_purchase_type(self):
        self.is_firewood = True if self.purchase_type == 'firewood' else False

    def _prepare_invoice(self):
        bill_vals = super(Purchase, self)._prepare_invoice()
        if self.purchase_type:
            ntfl_type = 'firewood' if self.purchase_type == 'firewood' else 'general'
            bill_vals.update({'ntfl_type': ntfl_type})
        return bill_vals

    @api.model
    def _prepare_picking(self):
        res = super(Purchase, self)._prepare_picking()
        if self.purchase_type:
            ntfl_type = 'firewood' if self.purchase_type == 'firewood' else 'general'
            res.update({'ntfl_type': ntfl_type})
        return res


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    crate_ok = fields.Boolean(
        string="Can be Crate",
        help="Allow Crate of this product.")
    green_leaf_ok = fields.Boolean(
        string="Can be Green Leaf",
        help="Allow Green Leaf of this product.")
    fertilizer_ok = fields.Boolean(
        string="Can be Fertilizer",
        help="Allow fertilizer of this product.")
    firewood_ok = fields.Boolean(
        string="Can be Firewood",
        help="Allow Firewood of this product.")

class AccountMove(models.Model):
    _inherit = "account.move"

    ntfl_type = fields.Selection([('farmer', 'Farmer'), ('firewood', 'Firewood'), ('general', 'General')], string="Ntfl Types", default="general")