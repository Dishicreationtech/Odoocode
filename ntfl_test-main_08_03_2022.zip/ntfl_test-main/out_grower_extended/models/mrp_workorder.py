# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class MrpWorkorder(models.Model):
    _inherit = "mrp.workorder"

    pause_reason_ids = fields.One2many('mrp.pause.reason', 'workorder_id')

    def button_pending(self):
        view_id = self.env.ref('out_grower_extended.mrp_pause_wizard_form_view').id
        return {
            'type': 'ir.actions.act_window',
            'name': _('Pause Reason'),
            'res_model': 'mrp.pause.wizard',
            'target': 'new',
            'view_mode': 'form',
            'context': {'default_workorder_id': self.id},
            'views': [[view_id, 'form']],
        }
