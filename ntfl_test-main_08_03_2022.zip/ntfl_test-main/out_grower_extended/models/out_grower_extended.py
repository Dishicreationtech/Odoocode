# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class RaCertified(models.Model):
    _inherit = "res.racertified"
    _description = "Ra Certified"

    farmer_registration_id = fields.Many2one('farmer.registration', string="Registration")

    @api.model
    def default_get(self, fields):
        vals = super(RaCertified, self).default_get(fields)
        farmer_registration_id = self.env.context.get('search_default_farmer_regi')
        if farmer_registration_id:
            farmer_registration_id = self.env['farmer.registration'].browse(farmer_registration_id)
            vals['farmer_regis_no'] = farmer_registration_id.uuid_random
            vals['farmer_registration_id'] = farmer_registration_id
        return vals

class FarmerRegistration(models.Model):
    _inherit = "farmer.registration"

    racertified_count = fields.Integer(compute='_racertified_count', string='#Racertified')

    @api.constrains('code')
    def check_code_constraint(self):
        for rec in self:
            registration_id = self.env['farmer.registration'].search([('code', '=', rec.code), ('id', '!=', rec.id)])
            if registration_id:
                raise ValidationError(_("Farmer Code must be unique"))

    @api.constrains('national_id')
    def check_national_constraint(self):
        for rec in self:
            registration_id = self.env['farmer.registration'].search([('national_id', '=', rec.national_id), ('id', '!=', rec.id)])
            if registration_id:
                raise ValidationError(_("National Id must be unique"))


    def view_racertified(self):
        racertified_ids = self.env['res.racertified'].search([('farmer_registration_id', '=', self.id)])
        return {
            'name': _('Ra-Certified'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'res.racertified',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', racertified_ids.ids)],
        }

    def _racertified_count(self):
        for rec in self:
            racertified_count_ids = self.env['res.racertified'].search([('farmer_registration_id', '=', rec.id)])
            rec.racertified_count = len(racertified_count_ids.ids)

class OutGrowerMobile(models.Model):
    _name = "mobile.device.maste"
    _inherit = ['format.address.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Mobile Device Maste"
    _rec_name = 'name'

    name = fields.Char(string="Mobile Name")
    mobile_imei_number = fields.Char(string="IMEI Number")
    active = fields.Boolean(default=True, help="Set active to false to hide")

class Trip(models.Model):
    _inherit = "trip.trip"

    mobile_device_id = fields.Many2one('mobile.device.maste', string="Mobile Device")
    vehicle_capacity = fields.Char(string="Vehicle Capacity", copy=False)
    on_hand_qty = fields.Float(string="On Hand Qty", related="crates_product_id.qty_available")
    farmer_count = fields.Integer("Farmer Count", compute='_compute_farmer_count')

    @api.depends('picking_ids', 'picking_ids.partner_id')
    def _compute_farmer_count(self):
        for rec in self:
            farmer_count = len(rec.weighment_lines.mapped('farmer_id'))
            rec.farmer_count = farmer_count


    @api.onchange('mobile_device_id')
    def _onchange_mobile_id(self):
        if self.mobile_device_id:
            self.phone_imei = self.mobile_device_id.mobile_imei_number

    @api.onchange('crates_quantity')
    def _onchange_crates_quantity(self):
        if self.crates_quantity and self.on_hand_qty:
            if self.crates_quantity > self.on_hand_qty:
                raise ValidationError(_('Product Quantity limit Over!!!'))

    def action_in_progress(self):
        for rec in self:
            trip_ids = self.env['trip.trip'].search(['|', '|', ('mobile_device_id', '=', rec.mobile_device_id.id),
                 ('vehicle_id', '=', rec.vehicle_id.id), ('clerk_id', '=', rec.clerk_id.id), ('id', '!=', self.id)])
            if trip_ids.filtered(lambda x: x.state == 'in_progress'):
                raise ValidationError(_("Trip is in already in progress with Same Vehicle, Clerk or Mobile Device!"))
        return super(Trip, self).action_in_progress()

    def action_done(self):
        for rec in self:
            if not rec.gate_weighment_id:
                raise ValidationError(_("Please define get weighment then after done!"))
        return super(Trip, self).action_done()

    @api.onchange('vehicle_id')
    def _onchange_vehicle_id(self):
        if self.vehicle_id:
            self.vehicle_capacity = self.vehicle_id.vehicle_capacity

class GateWeighment(models.Model):
    _inherit = "gate.weighment"

    remark = fields.Text(string="Remarks", copy=False)

    @api.constrains('weighment_no')
    def check_weighment_constraint(self):
        for rec in self:
            get_weighment_id = self.env['gate.weighment'].search([('weighment_no', '=', rec.weighment_no), ('id', '!=', rec.id)])
            if get_weighment_id:
                raise ValidationError(_("Weighment Number must be unique"))

    @api.onchange('trip_id')
    def _onchange_mobile_id(self):
        if self.trip_id:
            self.vehicle_id = self.trip_id.vehicle_id.id if self.trip_id.vehicle_id else False
            self.vehicle_no = self.trip_id.vehicle_id.license_plate if self.trip_id.vehicle_id else ''

    def unlink(self):
        if self.trip_id.state == "done":
            raise ValidationError(_('You cannot delete gate weighment'))
        return super().unlink()

class Weighment(models.Model):
    _inherit = "grower.weighment"

    bill_count = fields.Integer(string="#Bill Count", compute="_tota_bill_count")

    def get_report_data(self):
        data = []
        weighment_id = self.search([('id', '=', self.id),('state', '=', 'draft')])
        for line in weighment_id:
            data.append({
                'farmer_ref': line.farmer_id.uuid_random ,
                'farmer_code':line.farmer_id.code ,
                'farmer_name':line.farmer_id.display_name ,
                'id_no': line.farmer_id.national_id,
                'contact_no': line.farmer_id.phone if line.farmer_id else '',
                'account' :line.farmer_id.bank_ac_no,
                'bank_name':line.farmer_id.farmer_id.farm_info_ids.farem_bank_ids.bank_id.name,
                'branch':line.farmer_id.farmer_id.farm_info_ids.farem_bank_ids.branch_id,
                'bank_code':line.farmer_id.farmer_id.farm_info_ids.farem_bank_ids.bank_id.bic,
                'branch_code':'',
                'net_wt':line.total_net,
                'product_price':line.product_id.standard_price,
            })
        return data

    def _tota_bill_count(self):
        for rec in self:
            picking_ids = self.env['stock.picking'].search([('weighment_id', '=', rec.id)])
            move_ids = self.env['account.move'].search([('picking_id', 'in', picking_ids.ids)])
            rec.bill_count = len(move_ids.ids)

    def action_view_bill_piking(self):
        picking_ids = self.env['stock.picking'].search([('weighment_id', '=', self.id)])
        move_ids = self.env['account.move'].search([('picking_id', 'in', picking_ids.ids)])
        return {
            'name': _('Bill'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', move_ids.ids)]
        }

    def _create_invoice(self, picking_ids):
        is_purchase_auto_bill = self.env['ir.config_parameter'].sudo().get_param('stock_move_invoice.is_purchase_auto_bill') or False
        is_purchase_auto_refund = self.env['ir.config_parameter'].sudo().get_param('stock_move_invoice.is_purchase_auto_refund') or False
        print("picking_ids:::::", picking_ids)
        for picking in picking_ids:
            if not picking.is_return and  is_purchase_auto_bill and picking.picking_type_id.code == 'incoming':
                picking.create_bill_weighment()
        return True

    def action_post(self):
        move_ids = False
        for record in self:
            move_lines = record._prepare_moves()
            move_ids = self.env['stock.move'].create(move_lines)
            stock_move = move_ids._action_confirm()
            if stock_move.picking_id:
                stock_move.picking_id.write({'trip_id' : record.trip_id.id})
            move_ids._action_done()
            record.state = 'post'
            if move_ids:
                picking_ids = move_ids.mapped('picking_id')
                picking_ids.write({'weighment_id' : record.id})
                if picking_ids:
                    self._create_invoice(picking_ids)
        return True

