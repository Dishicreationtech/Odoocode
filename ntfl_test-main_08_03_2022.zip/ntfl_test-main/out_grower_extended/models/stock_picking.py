# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class StockLocation(models.Model):
    _inherit = "stock.location"

    transport_rate = fields.Float(string="Transport Rate")

class StockPicking(models.Model):
    _inherit = "stock.picking"

    weighment_id = fields.Many2one('grower.weighment', string="Weighment")
    ntfl_type = fields.Selection([('farmer', 'Farmer'), ('firewood', 'Firewood'), ('general', 'General')], string="Ntfl Types", default="general")

    def create_bill(self):
        bill_id = super(StockPicking, self).create_bill()
        if self.purchase_id and self.purchase_id.purchase_type and bill_id:
            ntfl_type = 'firewood' if self.purchase_id.purchase_type == 'firewood' else 'general'
            bill_id.ntfl_type = ntfl_type
        return bill_id

    def prepaire_transpore_rate_line(self):
        product_id = self.env.ref('ntfl_fleet.transport_rate_product')
        lines = []
        location_ids = self.weighment_id.weighment_line_ids.mapped('location_id')
        for location_id in location_ids:
            total_quantity = 0.0
            for line in self.weighment_id.weighment_line_ids.filtered(lambda x: x.location_id.id == location_id.id):
                total_quantity = total_quantity + line.net
            lines.append((0, 0, {
                'name': '{}-{}'.format(product_id.name, location_id.name),
                'product_id': product_id.id,
                'price_unit': - float(location_id.transport_rate),
                'account_id': product_id.property_account_income_id.id if product_id.property_account_income_id
                else product_id.categ_id.property_account_income_categ_id.id,
                'tax_ids': [(6, 0, [])],
                'quantity': total_quantity,
            }))
        return lines

    def create_bill_weighment(self):
        for picking_id in self:
            invoice_line_list = []
            current_user = self.env.uid
            vendor_journal_id = picking_id.env['ir.config_parameter'].sudo().get_param('stock_move_invoice.vendor_journal_id') or False
            if not vendor_journal_id:
                raise UserError(_("Please configure journal in account settings."))
            for move_ids_without_package in picking_id.move_ids_without_package:
                tax_ids = self._get_purchase_tax(move_ids_without_package) or []
                vals = (0, 0, {
                    'name': move_ids_without_package.description_picking,
                    'product_id': move_ids_without_package.product_id.id,
                    'price_unit': move_ids_without_package.product_id.standard_price,
                    'account_id': move_ids_without_package.product_id.property_account_income_id.id if move_ids_without_package.product_id.property_account_income_id
                    else move_ids_without_package.product_id.categ_id.property_account_income_categ_id.id,
                    'tax_ids': [(6, 0, tax_ids)],
                    'quantity': move_ids_without_package.quantity_done,
                })
                invoice_line_list.append(vals)
            lines = self.prepaire_transpore_rate_line()
            invoice_line_list.extend(lines)
            invoice = picking_id.env['account.move'].create({
                'move_type': 'in_invoice',
                'invoice_date': picking_id.weighment_id.weighment_date if picking_id.weighment_id else False,
                'invoice_origin': picking_id.name,
                'invoice_user_id': current_user,
                'narration': picking_id.name,
                'partner_id': picking_id.partner_id.id,
                'currency_id': picking_id.env.user.company_id.currency_id.id,
                'journal_id': int(vendor_journal_id),
                'payment_reference': picking_id.name,
                'picking_id': picking_id.id,
                'invoice_line_ids': invoice_line_list
            })
            return invoice