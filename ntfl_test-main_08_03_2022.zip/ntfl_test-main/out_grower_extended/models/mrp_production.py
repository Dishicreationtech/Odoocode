# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class MrpProduction(models.Model):
    _inherit = "mrp.production"

    out_turn = fields.Float(string='Out Turn(%)', compute='_compute_out_turn')

    def _compute_out_turn(self):
        for production in self:
            total_leaf = sum(production.move_raw_ids.filtered(lambda x: x.product_id.green_leaf_ok).mapped('quantity_done'))
            if total_leaf:
               total_leaf = (production.product_qty / total_leaf) * 100
            production.out_turn = total_leaf

