# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class MrpPauseWizard(models.TransientModel):
    _name = "mrp.pause.wizard"

    workorder_id = fields.Many2one('mrp.workorder')
    reason = fields.Text('Reason', required=True)

    def action_pause(self):
        self.env['mrp.pause.reason'].sudo().create({
            'workorder_id': self.workorder_id.id,
            'name': self.reason,
        })
        self.workorder_id.end_previous()
        return True
