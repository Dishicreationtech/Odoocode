# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class TripCancelReason(models.TransientModel):
    _name = 'trip.cancel.reason.wizard'
    _description = 'trip.cancel.reason'

    trip_reason_id = fields.Many2one('trip.cancel.reason', 'Trip Cancel Reason')

    def action_cancel_reason_apply(self):
        active_id = self.env.context.get('active_id')
        trip_id = self.env['trip.trip'].browse(active_id)
        message = _("<strong>Trip Cancel Reason : </strong> %s") % (self.trip_reason_id.name,)
        trip_id.write({'state' : 'cancel'})
        trip_id.message_post(body=message)
        return True
