# -*- coding: utf-8 -*-

from . import res_partner
from . import handover
from . import fleet
from . import maintance
from . import vehicle_tyre_details
from . import vehicle_fuel_log
from . import trip