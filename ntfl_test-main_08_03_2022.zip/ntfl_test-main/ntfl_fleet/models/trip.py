# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class Product(models.Model):
    _inherit = "product.template"

    is_fuel_product = fields.Boolean(
        string="Is Fuel Product",
        help="Allow Crate Fuel Product")

class Move(models.Model):
    _inherit = "account.move"

    trip_id = fields.Many2one('trip.trip', string="Trip")
    log_fuel_id = fields.Many2one('fleet.vehicle.log.fuel', string="Fleet Vehicle Log Fuel")

class Trip(models.Model):
    _inherit = "trip.trip"

    def _create_prepaire_bill_line(self):
        transport_rate = 0.0
        if self.vehicle_id and self.vehicle_id.log_contracts:
            contract_ids = self.vehicle_id.log_contracts.filtered(lambda x: x.expiration_date > self.trip_date)
            transport_rate = sum(contract_ids.mapped('transport_rate'))
        quantity = self.gate_weighment_id.net_weight or 1.0
        product_id = self.env.ref('ntfl_fleet.transport_rate_product')
        return [(0, 0, {
                'product_id' : product_id.id,
                'name': product_id.name,
                'quantity': quantity,
                'price_unit': transport_rate,
                'tax_ids': [(6, 0, [])],
            })]

    def create_bill(self):
        move_obj = self.env['account.move']
        log_contract_id = False
        lines = self._create_prepaire_bill_line()
        if self.vehicle_id and self.vehicle_id.log_contracts:
            log_contract_id = self.vehicle_id and self.vehicle_id.log_contracts[0]
        if self.gate_weighment_id and log_contract_id:
            vals = {'move_type': 'in_invoice', 
                    'partner_id': log_contract_id.insurer_id.id if log_contract_id else False, 
                    'invoice_date': self.trip_date,
                    'trip_id' : self.id,
                    'ntfl_type' : 'farmer',
                    'invoice_line_ids' : lines,}
            move_obj.create(vals)
        return True

    def action_done(self):
        res = super(Trip, self).action_done()
        if self.vehicle_id and self.gate_weighment_id:
            invoice_line = self.create_bill()
        return res

class GateWeighment(models.Model):
    _inherit = "gate.weighment"

    bill_count = fields.Integer(string="#Bill Count", compute="_tota_bill_count")

    def _tota_bill_count(self):
        for rec in self:
            move_ids = self.env['account.move'].search([('trip_id', '=', self.trip_id.id)])
            rec.bill_count = len(move_ids.ids)

    def open_bill_weighment(self):
        gate_move_ids = self.env['account.move'].search([('trip_id', '=', self.trip_id.id)])
        return {
            'name': _('Bill'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', gate_move_ids.ids)]
        }