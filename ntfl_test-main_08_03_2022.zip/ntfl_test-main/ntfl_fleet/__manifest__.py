# -*- coding: utf-8 -*-
{
    'name': "NTFL Fleet",
    'summary':'Fleet changes related to fleet master',
    'description': 'This module modify fleet',
    'author': "rohitsrivastava99@gmail.com",
    'category': 'fleet',
    'version': '14.0.1',
    'depends': ['fleet','hr','repair', 'out_grower'],
    'data': [
    'security/ir.model.access.csv',
    'data/sequence.xml',
    'views/fleet_view.xml',
    'views/res_partner.xml',
    'views/handover.xml',
    'views/maintance.xml',
    'views/vehicle_tyre_details.xml',
    'views/vehicle_fuel_log.xml',
    'views/out_grower_view.xml',
        
    ],
}
