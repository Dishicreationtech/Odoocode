# -*- coding: utf-8 -*-
{
    'name': "Sale Customer Location",
    'summary': """Sale Customer Location""",
    'description': """Sale Customer Location""",
    'author': "Preciseways",
    'website': "http://www.preciseways.com",
    'version': '14.0',
    'depends': ['sale_management','stock', 'sale_stock', 'auction_sale'],
    'data': [
        'views/sale_order_view.xml',       
    ],
}
