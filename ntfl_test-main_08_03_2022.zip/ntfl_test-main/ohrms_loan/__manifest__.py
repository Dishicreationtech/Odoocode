# -*- coding: utf-8 -*-
{
    'name': 'Loan Management',
    'version': '14.0.1.0.0',
    'summary': 'Manage Loan Requests',
    'description': """Helps you to manage Loan Requests of your company's staff.""",
    'category': 'Generic Modules/Human Resources',
    'depends': ['hr_payroll', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'data/salary_rule_loan.xml',
        'views/hr_loan.xml',
        'views/hr_payroll.xml',
    ],
}
