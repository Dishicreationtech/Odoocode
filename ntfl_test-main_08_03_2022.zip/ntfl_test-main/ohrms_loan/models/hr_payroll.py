# -*- coding: utf-8 -*-
import time
import babel
from odoo import models, fields, api, tools, _
from datetime import datetime
from odoo.exceptions import UserError, ValidationError

class HrPayslipInput(models.Model):
    _inherit = 'hr.payslip.input'

    loan_line_id = fields.Many2one('hr.loan.line', string="Loan Installment", help="Loan installment")

class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    def _prepare_hr_loan_data(self):
        loan_rule_id = self.env['hr.salary.rule'].search([('code', '=', 'Loan')], limit=1)
        if not loan_rule_id:
            raise ValidationError(_("Please create salary rule and enter code 'Loan' "))
        input_type_input_type = self.env.ref('ohrms_loan.hr_payslip_loan_input')
        compnay_id = self.env.company
        loan_ids = self.env['hr.loan'].search([('employee_id', '=', self.employee_id.id), ('date', '>=', self.date_from), ('date', '<=', self.date_to), ('state', '=', 'approve'), ('types', '=', 'loan')])
        line_id = loan_ids.mapped('loan_lines').filtered(lambda x : self.date_from <= x.date <= self.date_to and not x.paid)
        payslip_lon = {
            'name': loan_rule_id.name,
            'code': loan_rule_id.code,
            'payslip_id' : self.id,
            'contract_id': self.contract_id.id if self.contract_id else False,
            'input_type_id' : input_type_input_type.id,
            'amount' : line_id.amount if line_id.amount else 0.0,
            'amount' : line_id.amount if line_id else 0.0,
            'loan_line_id' : line_id.id if line_id else False
        }
        return payslip_lon

    def _prepare_hr_advance_salary_data(self):
        salary_rule_id = self.env['hr.salary.rule'].search([('code', '=', 'Salary')], limit=1)
        if not salary_rule_id:
            raise ValidationError(_("Please create salary rule and enter code 'Salary' "))
        payslip_salary_input_type = self.env.ref('ohrms_loan.hr_payslip_salary_advance_input')
        compnay_id = self.env.company
        loan_ids = self.env['hr.loan'].search([('employee_id', '=', self.employee_id.id), ('date', '>=', self.date_from), ('date', '<=', self.date_to), ('state', '=', 'approve'), ('types', '=', 'salary_advance')])
        line_id = loan_ids.mapped('loan_lines').filtered(lambda x : self.date_from <= x.date <= self.date_to and not x.paid)
        payslip_sal = {
            'name': salary_rule_id.name,
            'code': salary_rule_id.code, 
            'payslip_id' : self.id, 
            'contract_id': self.contract_id.id if self.contract_id else False, 
            'input_type_id' : payslip_salary_input_type.id,
            'amount' : line_id.amount if line_id else 0.0,
            'loan_line_id' : line_id.id if line_id else False}
        return payslip_sal

    def compute_sheet(self):
        payslip_input_users = []
        hr_loan_line = self._prepare_hr_loan_data()
        hr_advance_salary_line = self._prepare_hr_advance_salary_data()
        payslip_input_users.append(hr_loan_line)
        payslip_input_users.append(hr_advance_salary_line)
        if payslip_input_users:
            self.env['hr.payslip.input'].create(payslip_input_users)
            payslip_input_users = []
        return super(HrPayslip, self).compute_sheet()


    def action_payslip_done(self):
        for line in self.input_line_ids.filtered(lambda x: x.loan_line_id):
            line.loan_line_id.paid = True
            line.loan_line_id.loan_id._compute_loan_amount()
        return super(HrPayslip, self).action_payslip_done()