# -*- coding: utf-8 -*-
{
    'name': 'Import outgrowe XLS File',
    'version': '14.0',
    'summary': 'Import Outgrowe XLS File',
    'description': """ Import Outgrowe """,
    'depends': ['out_grower'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/import_out_grower_wizard.xml',
        ],
    'installable': True,
    'auto_install': False,
}
