{
    'name': "Packaging Operations",
    "category": "stock",
    'summary':""" Packaging Operations """,
    'depends': ['mail', 'stock', 'mrp'],
    'data': [
        'security/ir.model.access.csv',
        'data/stock_data.xml',
        'views/stock_view.xml',
        'views/packing_template_view.xml',
        'views/packing_order_view.xml',
        'wizard/packing_backorder_wizard.xml',
    ],
    'post_init_hook': '_create_warehouse_packing_data',
    'installable' : True,
    'application' :  True,
}
