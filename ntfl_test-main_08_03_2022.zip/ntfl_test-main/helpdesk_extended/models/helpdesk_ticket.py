# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError

class WeighmentLine(models.Model):
    _inherit = "grower.weighment.line"
    _rec_name = "transaction_no"

    ticket_id = fields.Many2one('helpdesk.ticket', string="Ticket")

class AccountMove(models.Model):
    _inherit = "account.move"

    ticket_id = fields.Many2one('helpdesk.ticket', string="Ticket")

class StockPicking(models.Model):
    _inherit = "stock.picking"

    helpdesk_id = fields.Many2one('helpdesk.ticket', string="Helpdesk Ticket")

class HelpdeskTicket(models.Model):
    _inherit = "helpdesk.ticket"

    purpose_type = fields.Selection([('delete', 'Delete'), ('transfer', 'Transfer'),], default='transfer', string="Purpose Type")
    to_farmer_id = fields.Many2one('res.partner', string="To Farmer")
    transaction_no = fields.Char(string="Transaction No")
    total_net_weight = fields.Float(string="Total Net", compute="_total_net_weight")
    refund_count = fields.Integer(string="Refund Bill", compute="_refund_count")
    bill_count = fields.Integer(string="Bill",  compute="_bill_count")
    trip_id = fields.Many2one("trip.trip", string="Trip Id", compute="_total_net_weight", store=True)
    is_solved = fields.Boolean(string="Is solved")
    picking_count = fields.Integer(string="#Delivery Count", compute="_picking_count")
    upload_document = fields.Binary('Upload File')

    def open_picking(self):
        picking_ids = self.env['stock.picking'].search([('helpdesk_id', '=', self.id), ('picking_type_id.code', '=', 'outgoing')])
        return {
            'name': _('Picking'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', picking_ids.ids)]
        }

    def _picking_count(self):
        for rec in self:
            picking_ids = self.env['stock.picking'].search([('helpdesk_id', '=', rec.id), ('picking_type_id.code', '=', 'outgoing')])
            rec.picking_count = len(picking_ids.ids)

    @api.depends('transaction_no')
    def _total_net_weight(self):
        for rec in self:
            weighment_line_ids = self.env['grower.weighment.line'].search([('transaction_no', '=', rec.transaction_no)])
            if weighment_line_ids:
                rec.total_net_weight = sum(weighment_line_ids.mapped('net'))
                trip_id = weighment_line_ids.mapped('weighment_id')[0].trip_id.id if weighment_line_ids and weighment_line_ids.mapped('weighment_id') and weighment_line_ids.mapped('weighment_id')[0].trip_id else False
                rec.trip_id = trip_id
            else:
                rec.total_net_weight = 0.0

    def _refund_count(self):
        for rec in self:
            move_ids = self.env['account.move'].search([('ticket_id', '=', rec.id), ('move_type', '=', 'in_refund')])
            rec.refund_count = len(move_ids.ids)

    def open_credit(self):
        move_ids = self.env['account.move'].search([('ticket_id', '=', self.id), ('move_type', '=', 'in_refund')])
        return {
            'name': _('Credit Bill'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', move_ids.ids)],
        }

    def _bill_count(self):
        for rec in self:
            move_ids = self.env['account.move'].search([('ticket_id', '=', rec.id), ('move_type', '=', 'in_invoice')])
            rec.bill_count = len(move_ids.ids)

    def open_bill(self):
        bill_ids = self.env['account.move'].search([('ticket_id', '=', self.id), ('move_type', '=', 'in_invoice')])
        return {
            'name': _('Bills'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', bill_ids.ids)],
        }


    def _prepare_invoice_lines(self, line):
        return {
            'name': line.product_id.display_name,
            'product_id': line.product_id.id,
            'price_unit': line.price_unit,
            'account_id': line.product_id.property_account_income_id.id if line.product_id.property_account_income_id
            else line.product_id.categ_id.property_account_income_categ_id.id,
            'tax_ids': [(6, 0, [])],
            'quantity': self.total_net_weight,
        }

    def _purpose_transfer(self, picking_id):
        move_id = self.env['account.move'].search([('picking_id', '=', picking_id.id)], limit=1)
        if move_id:
            invoice_line_list = [(0, 0, self._prepare_invoice_lines(line)) for line in move_id.invoice_line_ids]
            refund_invoice_id = self.env['account.move'].create({
            'move_type': 'in_refund',
            'partner_id' : self.partner_id.id,
            'invoice_origin': self.transaction_no,
            'partner_id': self.partner_id.id,
            'currency_id': self.env.user.company_id.currency_id.id,
            'journal_id': move_id.journal_id.id,
            'payment_reference': self.transaction_no,
            'ticket_id' : self.id,
            'invoice_line_ids': invoice_line_list
            })
            bill_id = self.env['account.move'].create({
            'move_type': 'in_invoice',
            'partner_id' : self.to_farmer_id.id,
            'ticket_id' : self.id,
            'invoice_origin': self.transaction_no,
            'partner_id': self.to_farmer_id.id,
            'currency_id': self.env.user.company_id.currency_id.id,
            'journal_id': move_id.journal_id.id,
            'payment_reference': self.transaction_no,
            'invoice_line_ids': invoice_line_list
            })
            weighment_line_ids = self.env['grower.weighment.line'].search([('transaction_no', '=', self.transaction_no)])
            weighment_line_ids.write({'ticket_id' : self.id})

    def _purpose_delete(self, picking_id):
        quantity = self.total_net_weight
        for picking in picking_id:
            vals = {'picking_id': picking.id, 'location_id' : picking.location_id.id}
            return_picking_wizard = self.env['stock.return.picking'].with_context(active_id=picking.id).create(vals)
            return_lines = []
            for line in picking.move_lines:
                return_line = self.env['stock.return.picking.line'].create({   
                        'product_id': line.product_id.id, 
                        'quantity': quantity, 
                        'wizard_id': return_picking_wizard.id,
                        'move_id': line.id})
                return_lines.append(return_line.id)
            return_picking_wizard.write({'product_return_moves': [(6, 0, return_lines)]})
            new_picking_id, pick_type_id = return_picking_wizard._create_returns()
            new_picking_ids = self.env['stock.picking'].browse(new_picking_id)
            new_picking_ids.write({'helpdesk_id' : self.id})
            new_picking_ids.action_assign()

    def _create_bill_from_farmer(self, picking_id):
        move_id = self.env['account.move'].search([('picking_id', '=', picking_id.id)], limit=1)
        invoice_line_list = [(0, 0, self._prepare_invoice_lines(line)) for line in move_id.invoice_line_ids]
        bill_id = self.env['account.move'].create({
            'move_type': 'in_invoice',
            'partner_id' : self.partner_id.id,
            'ticket_id' : self.id,
            'invoice_origin': self.transaction_no,
            'partner_id': self.partner_id.id,
            'currency_id': self.env.user.company_id.currency_id.id,
            'journal_id': move_id.journal_id.id,
            'payment_reference': self.transaction_no,
            'invoice_line_ids': invoice_line_list
            })
        return bill_id

    def done_transection(self):
        for rec in self:
            picking_id = self.env['stock.picking'].search([('trip_id', '=', rec.trip_id.id), ('picking_type_id.code', '=', 'incoming'), ('state', '=', 'done'), ('partner_id', '=', rec.partner_id.id)], limit=1)
            if not rec.total_net_weight:
                raise UserError(_("Transaction not found"))
            if rec.purpose_type == 'transfer':
                rec._purpose_transfer(picking_id)
                rec.is_solved = True
                stage_solved_id = self.env.ref('helpdesk.stage_solved')
                rec.stage_id = stage_solved_id
            if rec.purpose_type == 'delete':
                rec._create_bill_from_farmer(picking_id)
                stage_solved_id = self.env.ref('helpdesk.stage_solved')
                rec.stage_id = stage_solved_id
                rec.is_solved = True
        return True
