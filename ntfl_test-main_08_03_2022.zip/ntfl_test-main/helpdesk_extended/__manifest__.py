# -*- coding: utf-8 -*-
{
    'name': "Helpdesk Extended",
    'summary': """Out Growers""",
    'description': """ Out Growers """,
    'author': "Jignesh Rathod",
    'website': "",
    'version': '14.0',
    'depends': ['out_grower_extended', 'helpdesk'],
    'data': [
        'views/helpdesk_ticket_view.xml',
        ],
}
