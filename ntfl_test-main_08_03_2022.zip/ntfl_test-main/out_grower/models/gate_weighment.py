# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class GateWeighment(models.Model):
    _name = "gate.weighment"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Gate Weighment"
    _rec_name = "weighment_no"

    name = fields.Char("Name")
    in_date = fields.Datetime(string="Date & In Time")
    out_date = fields.Datetime(string="Out Date & Time")
    weighment_no = fields.Char(string="Weighment No")
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle")
    moisture = fields.Integer(string='Moisture')
    gross_weight = fields.Float(string='Gross Weight')
    tare_weight = fields.Float(string='Tare Weight')
    net_weight = fields.Float(string='Net Weight', compute='_compute_net_weight',)
    vehicle_no = fields.Char(string='Vehicle No')
    reduction = fields.Float(string='Reduction (%)')
    trip_id = fields.Many2one("trip.trip", string="Trip")
    partner_id = fields.Many2one('res.partner', string="Partner")
    product_id = fields.Many2one('product.product', string="Product")
    origin = fields.Char(string="Origin")

    @api.depends('gross_weight', 'tare_weight')
    def _compute_net_weight(self):
        net_weight = 0.0
        for record in self:
            net_weight = record.gross_weight - record.tare_weight
            record.net_weight = net_weight


class OdooInsert(models.Model):
    _name = "outgrower.odoo.quary"
    _description = "Insert Quary"
    _rec_name = "weighment_no"

    weighment_no = fields.Char(string="Weighment No")
    gwe_date = fields.Date(string="Gwe Date")
    gwe_in_time = fields.Datetime(string="Gwe In Time")
    gwe_out_time = fields.Datetime(string="Gwe Out Time")
    grosswt = fields.Float(string="Gwe Gross Wt")
    tare_wt = fields.Float(string="Gwe Tare Wt")
    net_wt = fields.Float(string="Gwe Net Wt")
    reduction_wt = fields.Float(string="Reduction Wt")
    rm_id = fields.Float(string="RM ID")
    trip_no_of_days = fields.Float(string="Trip No of Days")
    delvnoteno = fields.Char(string="Delvnoteno")
    delvnote_date = fields.Char(string="Delvnote Date")
    unit_id = fields.Char(string="Unit ID")
    user_idcr = fields.Char(string="User Idcr")
    date_cr = fields.Char(string="Date Cr")
    gwe_id = fields.Char(string="Gwe Id")
    vm_id = fields.Char(string="VM Id")
    fm_id = fields.Char(string="FM Id")
    vehicle_number = fields.Char(string="Vehicle Number")
    moisture = fields.Char(string="Moisture")
    boilercubic = fields.Char(string="Boilercubic")
