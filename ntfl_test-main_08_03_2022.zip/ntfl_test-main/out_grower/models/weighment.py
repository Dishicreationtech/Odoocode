# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class Weighment(models.Model):
    _name = "grower.weighment"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Grower Weighment"

    @api.depends('weighment_line_ids')
    def _compute_weight(self):
        self.weight = sum(line.weight for line in self.weighment_line_ids)
        self.tare_weight = sum(line.tare for line in self.weighment_line_ids)
        self.moisture_weight = sum(line.moisture for line in self.weighment_line_ids)
        self.total_net = sum(line.net for line in self.weighment_line_ids)
        self.no_of_package = len(self.weighment_line_ids.ids)

    def _default_product_id(self):
        return self.env.ref('out_grower.product_product_green_leaves', raise_if_not_found=False)

    name = fields.Char(string="Weighment", readonly=True, copy=False,
         default=lambda self: self.env['ir.sequence'].next_by_code('grower.weighment'))
    weighment_date = fields.Date(string="Date")
    vehicle_id = fields.Many2one("fleet.vehicle", string="Vehicle")
    farmer_id = fields.Many2one("res.partner", string="Farmer")
    national_id = fields.Char(related='farmer_id.national_id', string="National ID")
    image_128 = fields.Binary(related='farmer_id.image_128', string="Image 128", readonly=False)
    image_1920 = fields.Binary(related='farmer_id.image_1920', string="Image 1920", readonly=False)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('post', 'Post'),
        ('cancel', 'Cancel')], string='Status', readonly=True, copy=False, index=True, tracking=3, default='draft')
    trip_id = fields.Many2one('trip.trip', string="Trip", required=True)
    product_id = fields.Many2one("product.product", string="Product", default=_default_product_id)
    weighment_line_ids = fields.One2many('grower.weighment.line', 'weighment_id', string="Weighment Line ids")
    weight = fields.Float(string="Total Weight (Kg)", compute="_compute_weight", store=True)
    tare_weight = fields.Float(string="Tare Weight (Kg)", compute="_compute_weight", store=True)
    moisture_weight = fields.Float(string="Moisture", compute="_compute_weight", store=True)
    total_net = fields.Float(string="Total Net (Kg)", compute="_compute_weight", store=True)
    no_of_package = fields.Float(string="No of Bags", compute="_compute_weight", store=True)
    clerk_id = fields.Many2one('res.partner', string="Clerk")
    route_id = fields.Many2one('routes.routes', string="Routes")
    mobile_id = fields.Char(string="Mobile ID", copy=False)
    device_id = fields.Char(string="Device ID", copy=False)

    @api.onchange('trip_id')
    def _onchange_user_type_id(self):
        if self.trip_id:
            self.vehicle_id = self.trip_id.vehicle_id.id
            self.route_id = self.trip_id.route_id.id
            self.clerk_id =  self.trip_id.clerk_id.id

    def action_draft(self):
        self.state = 'draft'

    # def _prepare_procurement_id(self):
    #     procurement = self.env["procurement.group"].create({'name' : self.name})
    #     return procurement

    def _prepare_moves(self):
        picking_type_id = self.trip_id.picking_type_id
        # picking_type_id = self.env['stock.picking.type'].search([('code', '=', 'incoming')])
        procurement_id = self.trip_id.group_id
        locations = self.weighment_line_ids.mapped('location_id')
        moves = []
        for location in locations:
            weight = sum(self.weighment_line_ids.filtered(lambda x: x.location_id == location).mapped('net'))
            moves.append({
                'partner_id' : self.farmer_id.id,
                'group_id' : procurement_id.id,
                'name': self.product_id.name,
                'product_id': self.product_id.id,
                'product_uom': self.product_id.uom_id.id,
                'origin': self.name,
                'picking_type_id': picking_type_id.id,
                'location_id': location.id or False,
                'location_dest_id': picking_type_id.default_location_dest_id.id or False,
                'procure_method': 'make_to_stock',
                'product_uom_qty': weight,
                'quantity_done': weight})
        return moves

    def action_post(self):
        for record in self:
            move_lines = record._prepare_moves()
            move_ids = self.env['stock.move'].create(move_lines)
            stock_move = move_ids._action_confirm()
            if stock_move.picking_id:
                stock_move.picking_id.write({'trip_id' : record.trip_id.id})
            move_ids._action_done()
            record.state = 'post'
        
        return True

    # Show related pickings 

    def action_cancel(self):
        self.state = 'cancel'

class WeighmentLine(models.Model):
    _name = "grower.weighment.line"
    _description = "Weighment Lines"

    @api.depends('weighment_id.weighment_line_ids')
    def _compute_weight(self):
        for line in self:
            total_weight = 0.0
            for rec in line.weighment_id.weighment_line_ids:
                total_weight += rec.net
                rec.total = total_weight

    @api.depends('weight', 'tare')
    def _compute_net_amount(self):
        net_amount = 0.0
        for line in self:
            net_amount = line.weight - (line.tare + line.moisture)
            line.net = net_amount  

    transaction_no = fields.Char("Transaction No")
    location_id = fields.Many2one("stock.location", string="Collection Center", required=True)
    weight = fields.Float(string="Gross Weight")
    tare = fields.Float(string="Tare") # TODO : moisture per kg 
    moisture = fields.Float(string="Moisture") # Moisture
    net = fields.Float(string="Net Weight", compute="_compute_net_amount", store=True)
    total = fields.Float(string="Total Weight", compute="_compute_weight")
    weighment_id = fields.Many2one('grower.weighment')
    latitude = fields.Char(string="Latitude", copy=False)
    logititude = fields.Char(string="Logititude", copy=False)
    weighment_start_date = fields.Datetime(string="Weighment Start Time")
    weighment_end_date = fields.Datetime(string="Weighment End Time")


class Trip(models.Model):
    _name = "trip.trip"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Out Grow Trip"

    def _default_picking_type_id(self):
        return self.env['stock.picking.type'].search([('code', '=', 'incoming')], limit=1)


    name = fields.Char(string='Name', index=True, copy=False, default='New', readonly=True)
    vehicle_id = fields.Many2one("fleet.vehicle", string="Vehicle Registration No", required=True)
    image_128 = fields.Binary(related='clerk_id.image_128', string="Avatar", readonly=False)
    trip_date = fields.Date(string="Date")
    tare_value = fields.Float(string="Tare Value")
    moisture_value = fields.Float(string="Moisture Value")
    clerk_id = fields.Many2one("res.partner", string="Clerk", required=True)
    extenstion_officer = fields.Many2one("res.partner", string="Extenstion Officer")
    no_of_assignment = fields.Integer(string="No of Bags")
    is_weighing_scale = fields.Boolean(string="Weighing Scale")
    weighing_scale = fields.Char(string="Weighing Scale No")
    is_phone = fields.Boolean(string="Mobile")
    crates_product_id = fields.Many2one("product.product", string="Crates Product")
    crates_quantity = fields.Float(string="Crates Quantity")
    weighment_allow_in_kg = fields.Float(string="Weighing Allow (kg)")
    phone_imei = fields.Char(string="Mobile Imei")
    is_scale_calibration = fields.Boolean(string="Scale Calibration")
    scale_unique_number = fields.Char(string="Scale Calibration")
    route_id = fields.Many2one('routes.routes', sting="Route", required=True)
    collection_ids = fields.Many2many('stock.location', string="Collection Center")
    picking_ids = fields.One2many('stock.picking', 'trip_id', string="Pickings")
    weighment_lines = fields.One2many("grower.weighment", "trip_id", string="Weighments")
    state = fields.Selection([('draft', 'Draft'), ('in_progress', 'in Progress'), 
        ('done', 'Done'), ('cancel', 'Cancel')], 
        default='draft', copy=False, track_visibility="onchange")

    picking_count = fields.Integer(compute='_picking_count', string='# Outgoin Picking')
    incoming_picking_count = fields.Integer(compute='_picking_count', string='# Incoming Picking')
    picking_type_id = fields.Many2one(
        'stock.picking.type',
        string='Operation Type',
        default=_default_picking_type_id,
        required=True,
        ondelete='restrict')
    group_id = fields.Many2one('procurement.group', copy=False)
    gate_weighment_id = fields.Many2one("gate.weighment", string="Gate Weighment")
    weight = fields.Float(string="Total Weight (Kg)", compute="_compute_weight", store=True)
    tare_weight = fields.Float(string="Tare Weight (Kg)", compute="_compute_weight", store=True)
    moisture_weight = fields.Float(string="Moisture", compute="_compute_weight", store=True)
    total_net = fields.Float(string="Total Net (Kg)", compute="_compute_weight", store=True)
    quality_sheet_ids = fields.One2many('quality.sheet', 'trip_id')
    show_quality_check = fields.Boolean(compute='_compute_show_quality_check')

    def _compute_show_quality_check(self):
        for trip in self:
            trip.show_quality_check = not bool(trip.quality_sheet_ids)

    @api.depends('weighment_lines', 'weighment_lines.weight')
    def _compute_weight(self):
        for trip in self:
            trip.weight = sum(line.weight for line in trip.weighment_lines)
            trip.tare_weight = sum(line.tare_weight for line in trip.weighment_lines)
            trip.moisture_weight = sum(line.moisture_weight for line in trip.weighment_lines)
            trip.total_net = sum(line.total_net for line in trip.weighment_lines)

    def _prepare_procurement_id(self):
        procurement = self.env["procurement.group"].create({'name' : self.name})
        return procurement.id

    def _picking_count(self):
        for rec in self:
            picking_ids = self.env['stock.picking'].search([('trip_id', '=', rec.id), ('picking_type_id.code', '=', 'outgoing')])
            incoming_ids = self.env['stock.picking'].search([('trip_id', '=', rec.id), ('picking_type_id.code', '=', 'incoming')])
            rec.picking_count = len(picking_ids.ids)
            rec.incoming_picking_count = len(incoming_ids.ids)

    def open_outgoing_picking(self):
        picking_ids = self.env['stock.picking'].search([('trip_id', '=', self.id), ('picking_type_id.code', '=', 'outgoing')])
        return {
            'name': _('Outgoing Picking'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', picking_ids.ids)],
        }

    def open_incoming_picking(self):
        picking_ids = self.env['stock.picking'].search([('trip_id', '=', self.id), ('picking_type_id.code', '=', 'incoming')])
        return {
            'name': _('Incoming Picking'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', picking_ids.ids)],
        }

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('trip.trip') or '/'
        return super(Trip, self).create(vals)

    @api.onchange('route_id')
    def onchange_journal_id(self):
        if self.route_id:
            location_ids = self.env['stock.location'].search([('route_id', '=', self.route_id.id)])
            self.collection_ids = location_ids.ids

    def action_in_progress(self):
        self.group_id = self._prepare_procurement_id()
        self.create_outgoin_picking()
        return True

    def action_done(self):
        self.create_incoming_picking()
        self.weighment_lines.action_post()
        self.write({'state' : 'done'})

    def action_cancel(self):
        self.write({'state' : 'cancel'})


    def _prepare_move_outgoing(self):
        company_id = self.env.company
        picking_type_id = self.env['stock.picking.type'].search([('code', '=', 'outgoing')], limit=1)
        stock_location = self.env.ref('stock.stock_location_locations', raise_if_not_found=False)
        location_id = self.env.ref('out_grower.stock_location_virtual_locatio')
        # procurement_id = self.with_context(outgoing=True)._prepare_procurement_id()
        return {
            'name' : self.name,
            'product_id': self.crates_product_id.id,
            'product_uom': self.crates_product_id.uom_id.id,
            'location_id': picking_type_id.default_location_src_id.id or False,
            'location_dest_id':location_id.id,
            'company_id': company_id.id,
            'product_uom_qty': self.crates_quantity,
            'origin': self.name,
            'group_id' : self.group_id.id,
            'picking_type_id': picking_type_id.id,
            'quantity_done' : self.crates_quantity
        }

    def _prepare_move_incoming(self):
        company_id = self.env.company
        stock_location = self.env.ref('stock.stock_location_locations', raise_if_not_found=False)
        picking_type_id = self.env['stock.picking.type'].search([('code', '=', 'incoming')], limit=1)
        location_dest_id = self.env.ref('out_grower.stock_location_virtual_locatio')
        # procurement_id = self.with_context(incoming=True)._prepare_procurement_id()
        return {
            'name' : self.name,
            'product_id': self.crates_product_id.id,
            'product_uom': self.crates_product_id.uom_id.id,
            'location_id': location_dest_id.id,
            'location_dest_id': picking_type_id.default_location_dest_id.id or False,
            'company_id': company_id.id,
            'product_uom_qty': self.crates_quantity,
            'origin': self.name,
            'group_id' : self.group_id.id,
            'picking_type_id': picking_type_id.id,
            'quantity_done' : self.crates_quantity
        }

    def create_outgoin_picking(self):
        move_line_vals = self._prepare_move_outgoing()
        stock_move = self.env['stock.move'].create(move_line_vals)
        stock_move._action_confirm()
        # Might be manuall Intervals 
        stock_move._action_done()
        stock_move.picking_id.trip_id = self.id
        self.state = 'in_progress'
        return True

    def create_incoming_picking(self):
        """ This method is created for crates incoming"""
        move_line_vals = self._prepare_move_incoming()
        stock_move = self.env['stock.move'].create(move_line_vals)
        stock_move._action_confirm()
        stock_move._action_done()
        stock_move.picking_id.trip_id = self.id
        self.state = 'done'
        return True

    def action_quality_sheet(self):
        return {
            'name': _('Generate Quantity Sheet'),
            'res_model': 'quality.sheet.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref('out_grower.quality_sheet_wizard_form').id,
            'context': self.env.context,
            'target': 'new',
            'type': 'ir.actions.act_window',
        }

class StockPicking(models.Model):
    _inherit = "stock.picking"

    trip_id = fields.Many2one('trip.trip', string="Trip")
    gate_weighment_id = fields.Many2one('gate.weighment', string="Gate Weighment")
    sequence = fields.Integer(string='Sequence', default=10)

class StockMove(models.Model):
    _inherit = "stock.move"

    wooden_kg = fields.Float(string="Wood in Kg")
    rasio = fields.Float(string="Ratio", compute="_get_rasio")

    @api.depends('product_uom_qty', 'wooden_kg')
    def _get_rasio(self):
        for rec in self:
            rasio = 0.0
            if rec.product_uom_qty and rec.wooden_kg:
                rasio = rec.product_uom_qty / rec.wooden_kg
            rec.rasio = rasio

class QualitySheet(models.Model):
    _name = 'quality.sheet'

    trip_id = fields.Many2one('trip.trip')
    location_id = fields.Many2one('stock.location', string='Collection Center')
    daily_collection = fields.Float(string='Daily Collection')
    a_bud = fields.Float(string='A BUD')
    leaf_1 = fields.Float(string='1 LEAF A BUD')
    leaf_2 = fields.Float(string='2 LEAF A BUD')
    soft_bhanji = fields.Float(string='SOFT BHANJI')
    leaf_3 = fields.Float(string='3 LEAF A BUD')
    hard_bhanji = fields.Float(string='HARD BHANJI')
    looses = fields.Float(string='LOOSES')
    damage_leaf = fields.Float(string='DAMAGE LEAF')
