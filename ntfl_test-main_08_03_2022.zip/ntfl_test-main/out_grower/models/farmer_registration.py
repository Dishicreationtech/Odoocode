# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
import uuid
from odoo.exceptions import ValidationError

@api.model
def _lang_get(self):
    return self.env['res.lang'].get_installed()

class FarmerRegistration(models.Model):
    _name = "farmer.registration"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Farmer Registration"

    @api.model
    def default_get(self, default_fields):
        values = super().default_get(default_fields)
        parent = self.env["farmer.registration"]
        if 'parent_id' in default_fields and values.get('parent_id'):
            parent = self.browse(values.get('parent_id'))
            values['company_id'] = parent.company_id.id
        if 'lang' in default_fields:
            values['lang'] = values.get('lang') or parent.lang or self.env.lang
        return values

    name = fields.Char(string="Registration", default="New")
    uuid_random = fields.Char('Registration Code', readonly=True, copy=False,)
    code = fields.Char(string="Farmer Code")
    national_id = fields.Char(string="National ID", copy=False)
    national_id_document = fields.Binary(attachment=True)
    bank_ac_no = fields.Char()
    bank_ac_document = fields.Binary(attachment=True)
    lr_no = fields.Char("LR no")
    title = fields.Many2one('res.partner.title')
    type = fields.Selection(
        [('contact', 'Contact'),
         ('invoice', 'Invoice Address'),
         ('delivery', 'Delivery Address'),
         ('other', 'Other Address'),
         ("private", "Private Address"),
         ("primary", "Primary Address"),
        ], string='Address Type',
        default='contact',
        help="Invoice & Delivery addresses are used in sales orders. Private addresses are only visible by authorized users.")
    street = fields.Char()
    street2 = fields.Char()
    zip = fields.Char(change_default=True)
    city = fields.Char()
    state_id = fields.Many2one("res.country.state", string='State', 
        ondelete='restrict', domain="[('country_id', '=?', country_id)]")
    country_id = fields.Many2one('res.country', string='Country', ondelete='restrict')
    email = fields.Char()
    email_formatted = fields.Char('Formatted Email', compute='_compute_email_formatted',
        help='Format email address "Name <email@domain>"')
    phone = fields.Char()
    mobile = fields.Char()
    company_type = fields.Selection(string='Company Type',
        selection=[('person', 'Individual'), ('company', 'Company')],
        compute='_compute_company_type', inverse='_write_company_type')
    is_company = fields.Boolean(string='Is a Company', default=False,
        help="Check if the contact is a company, otherwise it is a person")
    parent_id = fields.Many2one('farmer.registration', string='Related Company', index=True)
    company_name = fields.Char('Company Name')
    child_ids = fields.One2many('farmer.registration', 'parent_id', string='Contact')
    company_id = fields.Many2one('res.company', 'Company', index=True)
    color = fields.Integer(string='Color Index', default=0)
    lang = fields.Selection(_lang_get, string='Language',
        help="All the emails and documents sent to this contact will be translated in this language.")
    user_id = fields.Many2one('res.users', string='Salesperson', 
        help='The internal user in charge of this contact.')
    stage_id = fields.Many2one(
        'farmer.stage', string='Stage', index=True, tracking=True, readonly=False, store=True,
        copy=False, ondelete='restrict')
    contract_period = fields.Char(string="Contract Period", copy=False)
    contract_status = fields.Selection([('active', 'Active'), ('inactive', 'Inactive')], 
        string="Contract Status", copy=False, tracking=3, default='active')
    contract_sign_date = fields.Date(string="Contract Sign Date", copy=False)
    transport_rate = fields.Char(string="Transport Rate", copy=False)
    farm_info_ids = fields.One2many('farm.info', 'farmer_regist_id', string='Farm Details')
    farmer_sub_country_id = fields.Many2one('res.country', string='Farmer Sub County', ondelete='restrict')
    gender = fields.Selection([('male', 'Male'),('female', 'Female')], string="Gender")
    farmer_type = fields.Selection([('out_grower', 'Out Grower'),('nucleus', 'Nucleus')], string="Farmer Type")
    clerk_id = fields.Many2one('res.partner', string="Clerk", domain=[('is_clerk', '=', True)])
    partner_id = fields.Many2one('res.partner', string="Farmer")
    devise_id = fields.Char(string="Devise Id")
    note = fields.Text(string="Note")
    lead_id = fields.Many2one('crm.lead', string="Lead")
    contact_name = fields.Char(string="Contact Name")
    farm_count = fields.Integer(compute='_farm_count', string='# Farm')
    is_conform = fields.Boolean(string="Confirm")
    is_approvel = fields.Boolean(string="Approvel")


    def _farm_count(self):
        for rec in self:
            farm_ids = self.env['farm.info'].search([('farmer_regist_id', '=', rec.id)])
            rec.farm_count = len(farm_ids.ids)

    def open_farm(self):
        farm_ids = self.env['farm.info'].search([('farmer_regist_id', '=', self.id)])
        return {
            'name': _('Farm Details'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'farm.info',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', farm_ids.ids)],
        }

    @api.depends('name', 'email')
    def _compute_email_formatted(self):
        for farmer in self:
            if farmer.email:
                farmer.email_formatted = tools.formataddr((farmer.name or u"False", farmer.email or u"False"))
            else:
                farmer.email_formatted = ''

    @api.depends('is_company')
    def _compute_company_type(self):
        for farmer in self:
            farmer.company_type = 'company' if farmer.is_company else 'person'

    def _write_company_type(self):
        for farmer in self:
            farmer.is_company = farmer.company_type == 'company'

    @api.onchange('company_type')
    def onchange_company_type(self):
        self.is_company = (self.company_type == 'company')

    def prepaire_partner_data(self):
        return {
            'name' : self.lead_id.contact_name if self.lead_id and self.lead_id.contact_name else self.contact_name,
            'type' : self.type,
            'title' : self.title.id if self.title else False,
            'street' : self.street,
            'street2' : self.street2,
            'zip' : self.zip,
            'city' : self.city,
            'state_id' : self.state_id.id if self.state_id else False,
            'country_id' : self.country_id.id if self.country_id else False,
            'email' : self.email,
            'phone' : self.phone,
            'mobile' : self.mobile,
            'company_type' : self.company_type,
            'is_company' : self.is_company,
            'company_id' : self.company_id.id or False,
            'farmer_id' : self.id,
            'bank_ac_no' : self.bank_ac_no,
            'clark_id': self.clerk_id.id,
            'is_farmer' : True
        }

    def prepaire_chaild_data(self, child):
        return {
            'name' : child.name,
            'type' : child.type,
            'title' : child.title.id if child.title else False,
            'street' : child.street,
            'street2' : child.street2,
            'zip' : child.zip,
            'city' : child.city,
            'state_id' : child.state_id.id if child.state_id else False,
            'country_id' : child.country_id.id if child.country_id else False,
            'email' : child.email,
            'phone' : child.phone,
            'mobile' : child.mobile,
            'company_type' : child.company_type,
            'is_company' : child.is_company,
            'company_id' : child.company_id.id or False,
        }

    def get_random_uuid(self):
        return uuid.uuid4().hex[:10].upper()

    def button_registered(self):
        if not self.farm_info_ids:
            raise ValidationError(_('Please add farm.'))
        code = self.env['ir.sequence'].next_by_code('farmer.farmer_code')
        code = self.code or code
        values = self.prepaire_partner_data()
        uuid_random = self.get_random_uuid()
        lines = [(0, 0, self.prepaire_chaild_data(partner)) for partner in self.child_ids]
        #bank_ids = self.mapped('farm_info_ids').mapped('bank_ids')
        values.update({'child_ids' : lines,})
        partner_id = self.env['res.partner'].create(values)
        partner_id.code = code
        self.farm_info_ids.write({'farm_partner_id' : partner_id.id})
        self.write({'partner_id' : partner_id.id, 'code':code, 'uuid_random' : uuid_random, 'stage_id' : 5})
        if self.farm_info_ids.mapped('farem_bank_ids') and self.partner_id:
            bank_details = []
            for bank in self.farm_info_ids.mapped('farem_bank_ids'):
                partner_accounts = self.env['res.partner.bank'].search([('acc_number', '=', bank.acc_holder_number)])
                if not partner_accounts:
                    self.env['res.partner.bank'].create({'bank_id': bank.bank_id.id, 'partner_id':partner_id.id, 'acc_number': bank.acc_holder_number})


    def button_confirm(self):
        under_approval_id = self.env.ref('out_grower.stage_under_approval')
        self.stage_id = under_approval_id
        self.is_conform = True

    def button_approved(self):
        self.is_approvel = True
        bank_detail_verification = self.env.ref('out_grower.stage_bank_details_veri')
        self.stage_id = bank_detail_verification

    @api.model
    def create(self, vals):
        code = self.env['ir.sequence'].next_by_code('farmer.reg')
        vals['name'] = code
        registration_id =  super(FarmerRegistration, self).create(vals)
        return registration_id

    def open_farm_details(self):
        return {
            'name': _('Farm Details'),
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'farm.info',
            'target': 'new',
            'context': {'farmer_regist_id' : self.id, 'farm_partner_id' : self.partner_id.id},
        }





class FarmInfo(models.Model):
    _name = 'farm.info'
    _inherit = ['format.address.mixin', 'image.mixin']
    _description = "Farmer Information"
    _rec_name = "registration"

    @api.model
    def default_get(self, fields):
        vals = super(FarmInfo, self).default_get(fields)
        if self.env.context.get('farmer_regist_id'):
            vals['farmer_regist_id'] = self.env.context.get('farmer_regist_id')
        if self.env.context.get('farm_partner_id'):
            vals['farm_partner_id'] = self.env.context.get('farm_partner_id')
        return vals

    registration = fields.Char(string="Farm", required=True, index=True, readonly=True, copy=False, default='New')
    plot_size = fields.Char(string="Plot Size")
    plot_number = fields.Char(string="Plot Number")
    area_under_tea = fields.Float(string="Area Under Tea(Acre)")
    par_year_kg = fields.Float(string="Per Year KG")
    ndarawetta_factory_acres = fields.Float(stirng="Ndarawetta Factory Acres")
    parcel_number = fields.Float(stirng="Parcel Number")
    farmer_latitude = fields.Float(string='Latitude', digits=(16, 5))
    farmer_longitude = fields.Float(string='Longitude', digits=(16, 5))
    plot_forest_cover = fields.Char(string="Plot Forest Cover")
    extension_contact = fields.Selection([('yes', 'Yes'), ('no', 'No')], 
        string="Extension Contract",default="yes")
    farmer_regist_id = fields.Many2one("farmer.registration", string="Registration")
    color = fields.Integer(string='Color Index', default=0)
    route_id = fields.Many2one('routes.routes', string="Route")
    location_id = fields.Many2one('stock.location', string="Collection Center")
    farm_code = fields.Char(string="Farm Code", default="New")
    #bank_ids = fields.One2many('res.partner.bank', 'farm_id', string='Banks')
    remark = fields.Text(string="Remark")
    farm_image_ids = fields.One2many('farm.image', 'farm_id', string="Extra Farm Images")
    farm_partner_id = fields.Many2one('res.partner', string="Farmer")
    farem_bank_ids = fields.One2many('farmer.bank', 'farm_id', string="Banks")

    @api.model
    def create(self, vals):
        if vals.get('registration', 'New') == 'New':
            vals['registration'] = self.env['ir.sequence'].next_by_code('farm.info') or '/'
        if vals.get('farm_code', 'New') == 'New':
            vals['farm_code'] = self.env['ir.sequence'].next_by_code('farm.farm_code')
        return super(FarmInfo, self).create(vals)

    def action_farm_generate(self):
        farm_info_ids = self.env['farm.info'].search([])
        for farm in farm_info_ids:
            registration = self.env['farmer.registration'].search([('code', '=', farm.farm_code)])
            if registration:
                farm.farmer_regist_id = registration.id
                old_partner_id = farm.farm_partner_id
                farm.farm_partner_id = registration.partner_id.id
                if old_partner_id and old_partner_id.bank_ids and old_partner_id != registration.partner_id:
                    farm_bank_id = farm.farem_bank_ids[0]
                    bank_account = old_partner_id.bank_ids.filtered(lambda x: x.acc_holder_number == farm_bank_id.acc_holder_number)
                    bank_account.partner_id = registration.partner_id.id
        return True

# class FarmerBank(models.Model):
#     _inherit = 'res.partner.bank'
#     _description = "Multiple Farmer Bank Details"

#     farm_id = fields.Many2one('farm.info', string="Farm")

class FarmerBank(models.Model):
    _name = 'farmer.bank'

    acc_holder_number = fields.Char(string="Account Number")
    acc_holder_name = fields.Char(string="Account Holder Name")
    bank_id = fields.Many2one('res.bank', string="Bank")
    branch_id = fields.Char(string="Branch Name")
    farm_id = fields.Many2one('farm.info', string="Farm")


class FarmImages(models.Model):
    _name = 'farm.image'
    _description = "Multiple Farmer Images"
    _inherit = ['image.mixin']
    _order = 'sequence, id'

    farm_id = fields.Many2one('farm.info', string="Farm")
    sequence = fields.Integer(default=10, index=True)
    image_1920 = fields.Image(required=True)