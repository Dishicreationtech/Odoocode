# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Routes(models.Model):
    _name = 'routes.routes'
    _inherit = ['format.address.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Routes"

    name = fields.Char(string="Route Name", copy=False)
    location_ids = fields.Many2many('stock.location', relation='routes_routes_location_rel', string="Locations")

class StockLocation(models.Model):
    _inherit = "stock.location"

    is_collection_center = fields.Boolean(string="Collection Center")
    route_id = fields.Many2many('routes.routes', relation="routes_routes_location_rel", string="Routes")
    is_shade = fields.Boolean(string="Shade")
    is_table = fields.Boolean(string="Table")
    is_noticeboard = fields.Boolean(string="Noticeboard")
    is_pit_latrine = fields.Boolean(string="Pit latrine")
    is_sops = fields.Boolean(string="SOPs")
    is_dustbin = fields.Boolean(string="Dustbin")
    lead_farmer_id = fields.Many2one('res.partner', string="Lead Farmer")
    chemical_handler_id = fields.Many2one('res.partner', string="Chemical handler")
