# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

class FarmerStatementWizard(models.TransientModel):
    _name = 'farmer.statement.wizard'
    _description = "Trip Details Wizard"

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle")
    trip_id = fields.Many2one('trip.trip', 'Trip')
    farmer_id = fields.Many2one('res.partner', string="Farmer", domain=[('is_farmer', '=', True)])

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'vehicle_id' : self.vehicle_id.id,
            'trip_id' : self.trip_id.id,
            'vehicle_id' : self.vehicle_id.id,
            'farmer_id' : self.farmer_id.id,
        }
        return self.env.ref('out_grower.farmer_statement_report').report_action(self, data=data)

class FarmerStatementReport(models.AbstractModel):
    _name = 'report.out_grower.farmer_statement_template'

    def _prepare_report_lines(self, weighment_ids):
        lines = []
        for record in weighment_ids.mapped('weighment_line_ids'):
            lines.append({
                    'farmer_name': record.weighment_id.farmer_id.name,
                    'farmer_code': record.weighment_id.farmer_id.code or '',
                    'national_id': record.weighment_id.farmer_id.national_id or '',
                    'collection_center' :  record.location_id.name or '',
                    'trip_name': record.weighment_id.trip_id.name,
                    'transaction_no' : record.transaction_no or '',
                    'vehcile_no' : record.weighment_id.vehicle_id.license_plate or '',
                    'gross_weight' : round(record.weight, 2) or 0.0,
                    'tare_weight' : round(record.tare, 2) or 0.0,
                    'moisture' : round(record.moisture, 2) or 0.0,
                    'net_weight' : round(record.net, 2) or 0.0, 
                })
        return lines

    def get_domain(self, data):
        domain = []
        vehicle_id = self.env['fleet.vehicle'].browse(data.get('vehicle_id'))
        farmer_id = self.env['res.partner'].browse(data.get('farmer_id'))
        trip_id = self.env['trip.trip'].browse(data.get('trip_id'))
        if data.get('date_from') and data.get('date_to'):
             domain += [('weighment_date', '>=', data.get('date_from')), ('weighment_date', '<=', data.get('date_to'))]
        if vehicle_id:
            domain += [('vehicle_id', '=', vehicle_id.id)]
        if farmer_id:
            domain += [('farmer_id', '=', farmer_id.id)]
        if trip_id:
            domain += [('trip_id', '=', trip_id.id)]
        return domain
        
    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        domain = self.get_domain(data)
        vehicle_id = self.env['fleet.vehicle'].browse(data.get('vehicle_id'))
        trip_id = self.env['trip.trip'].browse(data.get('trip_id'))
        farmer_id = self.env['res.partner'].browse(data.get('farmer_id'))
        weighment_ids = self.env['grower.weighment'].search(domain)
        lines = self._prepare_report_lines(weighment_ids)
        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'from_date' :  data.get('date_from'),
            'date_to' :  data.get('date_to'),
            'vehicle_name' : vehicle_id.model_id.display_name if vehicle_id.model_id else '',
            'farmer_name' : farmer_id.name if farmer_id else '',
            'trip_name' : trip_id.name if trip_id else '',
            'docs' : docs,
            'lines' : lines
        }
