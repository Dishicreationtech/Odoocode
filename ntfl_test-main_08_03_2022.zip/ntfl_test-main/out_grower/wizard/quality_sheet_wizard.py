# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError

class QualitySheetWizard(models.TransientModel):
    _name = "quality.sheet.wizard"

    a_bud = fields.Float(string='A BUD')
    leaf_1 = fields.Float(string='1 LEAF A BUD')
    leaf_2 = fields.Float(string='2 LEAF A BUD')
    soft_bhanji = fields.Float(string='SOFT BHANJI')
    leaf_3 = fields.Float(string='3 LEAF A BUD')
    hard_bhanji = fields.Float(string='HARD BHANJI')
    looses = fields.Float(string='LOOSES')
    damage_leaf = fields.Float(string='DAMAGE LEAF')


    def generate_sheet(self):
        if (self.a_bud + self.leaf_1 + self.leaf_2 + self.soft_bhanji + self.leaf_3 + self.hard_bhanji + self.looses + self.damage_leaf) != 100:
            raise UserError(_('Percentage not equal to 100'))
        trip = self.env['trip.trip'].browse(self.env.context.get('active_id', False))
        weighment_line_ids = trip.weighment_lines.mapped('weighment_line_ids')

        group_by_location = {}
        for line in weighment_line_ids:
            if line.location_id.id in group_by_location:
                group_by_location[line.location_id.id] |= line
            else:
              group_by_location[line.location_id.id] = line
        
        vals = []
        for location_id, lines in group_by_location.items():
            net_weight = sum(lines.mapped('net'))
            vals.append((0, 0, {
                'daily_collection': net_weight,
                'trip_id': trip.id,
                'location_id': location_id,
                'a_bud': (net_weight * self.a_bud) / 100.0 if self.a_bud > 0 else 0.0,
                'leaf_1': (net_weight * self.leaf_1) / 100.0 if self.leaf_1 > 0 else 0.0,
                'leaf_2': (net_weight * self.leaf_2) / 100.0 if self.leaf_2 > 0 else 0.0,
                'soft_bhanji': (net_weight * self.soft_bhanji) / 100.0 if self.soft_bhanji > 0 else 0.0,
                'leaf_3': (net_weight * self.leaf_3) / 100.0 if self.leaf_3 > 0 else 0.0,
                'hard_bhanji': (net_weight * self.hard_bhanji) / 100.0 if self.hard_bhanji > 0 else 0.0,
                'looses': (net_weight * self.looses) / 100.0 if self.looses > 0 else 0.0,
                'damage_leaf': (net_weight * self.damage_leaf) / 100.0 if self.damage_leaf > 0 else 0.0,
            }))
        trip.write({'quality_sheet_ids': vals})
        return {'type': 'ir.actions.act_window_close'}
