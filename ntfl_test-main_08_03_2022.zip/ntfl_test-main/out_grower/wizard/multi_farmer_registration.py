from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class FarmerRegistration(models.TransientModel):
	_name = "farmer.wizard"


	def action_register(self):
		active_ids = self.env.context.get('active_ids')
		res = self.env['farmer.registration'].browse(active_ids)
		if any(farmer.uuid_random for farmer in res):
			raise ValidationError(_('Please select only unregisterd farmers!'))
		for farmer in res:
			farmer.button_registered()
