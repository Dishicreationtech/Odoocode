# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError

class QualityReportWizard(models.TransientModel):
    _name = "quality.report.wizard"

    date_from = fields.Date(string='Date from', required=True)
    date_to = fields.Date(string='Date to', required=True)

    def action_print_report(self):
        data = {
            'date_from': self.date_from,
            'date_to': self.date_to,
        }
        return self.env.ref('out_grower.quality_sheet_report').report_action(self, data=data)

class QualitySheetReport(models.AbstractModel):
    _name = 'report.out_grower.quality_sheet_report_template'

    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        date_from = data['date_from']
        date_to = data['date_to']

        sheet_ids = self.env['quality.sheet'].search([('trip_id.trip_date', '>=', date_from), ('trip_id.trip_date', '<=', date_to)])

        sheet_by_center = {}
        for sheet in sheet_ids:
            if sheet.location_id.id in sheet_by_center:
                sheet_by_center[sheet.location_id.id] |= sheet
            else:
                sheet_by_center[sheet.location_id.id] = sheet
        report_lines = []
        for location_id, lines in sheet_by_center.items():
            location = self.env['stock.location'].browse(location_id)
            daily_collection = sum(lines.mapped('daily_collection'))
            a_bud = sum(lines.mapped('a_bud'))
            leaf_1 = sum(lines.mapped('leaf_1'))
            leaf_2 = sum(lines.mapped('leaf_2'))
            soft_bhanji = sum(lines.mapped('soft_bhanji'))
            leaf_3 = sum(lines.mapped('leaf_3'))
            hard_bhanji = sum(lines.mapped('hard_bhanji'))
            looses = sum(lines.mapped('looses'))
            damage_leaf = sum(lines.mapped('damage_leaf'))
            total_good = a_bud + leaf_1 + leaf_2 + soft_bhanji
            total_bad = leaf_3 + hard_bhanji + looses + damage_leaf
            good_per = (100 / daily_collection) * total_good
            bad_per = (100 / daily_collection) * total_bad

            report_lines.append({
                'collection_center': location.name,
                'daily_collection': sum(lines.mapped('daily_collection')),
                'a_bud': a_bud,
                'leaf_1': leaf_1,
                'leaf_2': leaf_2,
                'soft_bhanji': soft_bhanji,
                'total_good': round(total_good, 2),
                'good_per': round(good_per, 2),
                'leaf_3': leaf_3,
                'hard_bhanji': hard_bhanji,
                'looses': looses,
                'damage_leaf': damage_leaf,
                'total_bad': round(total_bad, 2),
                'bad_per': round(bad_per, 2),
            })
        return {
            'docs': docs,
            'lines': report_lines,
        }
