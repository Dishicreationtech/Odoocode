# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta
from odoo.tools import float_repr


class TripDetailsWizard(models.TransientModel):
    _name = 'trip.details.wizard'
    _description = "Trip Details Wizard"

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle")
    trip_id = fields.Many2one('trip.trip', 'Trip')
    clark_id = fields.Many2one("res.partner", domain=[('is_clerk', '=', True)])

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'vehicle_id' : self.vehicle_id.id,
            'trip_id' : self.trip_id.id,
            'vehicle_id' : self.vehicle_id.id,
            'clark_id' : self.clark_id.id,
        }
        return self.env.ref('out_grower.trip_details_report').report_action(self, data=data)

class TripDetailsWizardReport(models.AbstractModel):
    _name = 'report.out_grower.trip_details_template'

    def _prepare_trip_lines(self, trip_ids):
        lines = []
        for record in trip_ids:
            variance = 0.0
            variance_per = 0.0
            if record.total_net and record.gate_weighment_id and record.gate_weighment_id.net_weight:
                variance = record.gate_weighment_id.net_weight - record.total_net
                variance_per = (variance / record.total_net) * 100
            lines.append({
                    'trip_date': record.trip_date,
                    'name': record.name,
                    'clerk': record.clerk_id.name if record.clerk_id else '',
                    'vehcile_no': record.vehicle_id.license_plate if record.vehicle_id and record.vehicle_id.license_plate else '',
                    'moisture': record.moisture_weight if record.moisture_weight else 0.0,
                    'trip_gross_wt': 0.0,
                    'trip_tare_wt': round(record.tare_weight,2) if record.tare_weight else 0.0,
                    'trip_net_wt':round(record.total_net,2) if record.total_net else 0.0,
                    'weighment_no' : record.gate_weighment_id.weighment_no if record.gate_weighment_id else '',
                    'weighment_gross_wt' : round(record.gate_weighment_id.gross_weight, 2) if record.gate_weighment_id else 0.0,
                    'weighment_tare_wt' : round(record.gate_weighment_id.tare_weight,2) if record.gate_weighment_id else 0.0,
                    'weighment_net_wt' : round(record.gate_weighment_id.net_weight,2) if record.gate_weighment_id else 0.0,
                    'variance' : round(variance, 2),
                    'variance_per' :  round(variance_per, 2) 
                })
        return lines

    def get_domain(self, data):
        domain = []
        vehicle_id = self.env['fleet.vehicle'].browse(data.get('vehicle_id'))
        clerk_id = self.env['res.partner'].browse(data.get('clerk_id'))
        trip_id = self.env['trip.trip'].browse(data.get('trip_id'))
        if data.get('date_from') and data.get('date_to'):
             domain += [('trip_date', '>=', data.get('date_from')), ('trip_date', '<=', data.get('date_to'))]
        if vehicle_id:
            domain += [('vehicle_id', '=', vehicle_id.id)] 
        if clerk_id:
            domain += [('clerk_id', '=', clerk_id)]
        if trip_id:
            domain += [('id', '=', trip_id.id)]
        return domain
        
    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        domain = self.get_domain(data)
        vehicle_id = self.env['fleet.vehicle'].browse(data.get('vehicle_id'))
        clerk_id = self.env['res.partner'].browse(data.get('clerk_id'))
        trip_id = self.env['trip.trip'].browse(data.get('trip_id'))
        trip_ids = self.env['trip.trip'].search(domain)
        lines = self._prepare_trip_lines(trip_ids)
        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'from_date' :  data.get('date_from'),
            'date_to' :  data.get('date_to'),
            'vehicle_name' : vehicle_id.model_id.display_name if vehicle_id.model_id else '',
            'clark_name' : clerk_id.name if clerk_id else '',
            'trip_name' : trip_id.name if trip_id else '',
            'docs' : docs,
            'lines' : lines
        }
