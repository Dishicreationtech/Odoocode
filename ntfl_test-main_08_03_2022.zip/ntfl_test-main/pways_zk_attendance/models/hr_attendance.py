# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class HrAttendance(models.Model):
    _inherit = 'hr.attendance'

    att_type = fields.Selection([('campus', 'Campus'), ('factory', 'Factory')], string='Type', required=True, default='campus')
