# -*- coding: utf-8 -*-
import pytz
import sys
import datetime
import logging
import binascii

from odoo import api, fields, models
from odoo import _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError
_logger = logging.getLogger(__name__)
try:
    from zk import ZK, const
except ImportError:
    _logger.error("Please Install pyzk library.")

_logger = logging.getLogger(__name__)



class OperationType(models.Model):
    _name = 'operation.type'

    name = fields.Char(required=True, string='Name')
    device_ids = fields.One2many('device.line', 'operation_id')
    type = fields.Selection([('campus', 'Campus'), ('factory', 'Factory')], string='Type', required=True, default='campus')

class DeviceLine(models.Model):
    _name = 'device.line'
    _rec_name = "operation_id"

    operation_id = fields.Many2one('operation.type', string="Device Name")
    device_ip = fields.Char('IP', required=True)
    device_port = fields.Integer('Port', default='4370', required=True)
    device_serial = fields.Char('Serial', required=True)
    last_sync_time = fields.Datetime()
    status = fields.Selection([('success', 'Success'), ('failed', 'failed')], string='Type')

    def device_connect(self, zk):
        try:
            conn = zk.connect()
            return conn
        except:
            return False

    def _get_client_time(self, sync_time):
        from datetime import datetime
        date = sync_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(pytz.utc.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date

    def cron_get_machine_data(self):
        """Multiple Device called"""
        for rec in self.env['device.line'].search([]):
            machine_ip = rec.device_ip
            zk_port = rec.device_port
            timeout = 1500
            try:
                zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=0, ommit_ping=1)
            except NameError:
                raise UserError(_("Please install it with 'pip3 install pyzk'."))
            conn = rec.device_connect(zk)
            if conn:
                try:
                    attendance_lines = conn.get_attendance()
                except:
                    attendance_lines = False
                last_sync_time = False
                rec.status = 'success'
                for line in attendance_lines:
                    employee_id = self.env['hr.employee'].search([('device_id', '=', line.user_id)])
                    atten_time = line.timestamp
                    atten_time = datetime.datetime.strptime(atten_time.strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')
                    local_tz = pytz.timezone(self.env.user.partner_id.tz or 'GMT')
                    local_dt = local_tz.localize(atten_time, is_dst=None)
                    utc_dt = local_dt.astimezone(pytz.utc)
                    utc_dt = utc_dt.strftime("%Y-%m-%d %H:%M:%S")
                    atten_time = datetime.datetime.strptime(utc_dt, "%Y-%m-%d %H:%M:%S")
                    if employee_id:
                        if rec._get_client_time(rec.last_sync_time) < rec._get_client_time(atten_time): 
                            att_rec = self.env['hr.attendance'].search([
                                ('att_type', '=', rec.operation_id.type),
                                ('employee_id', '=', employee_id.id),
                                ('check_in', '<', atten_time),
                                ('check_out', '=', False)
                            ])
                            if att_rec:
                                att_rec.write({'check_out': fields.Datetime.to_string(atten_time)})
                            else:
                                self.env['hr.attendance'].create({
                                    'att_type': rec.operation_id.type,
                                    'employee_id': employee_id.id,
                                    'check_in': fields.Datetime.to_string(atten_time),
                                })
                            last_sync_time = atten_time
                    else:
                        _logger.error("Employee not found with ID : "+ str(line.user_id))
                if last_sync_time:
                    rec.write({'last_sync_time': last_sync_time})
            else:
                rec.status = 'failed'
                _logger.error("Unable to connect, please check the parameters and network connections.")