# -*- coding: utf-8 -*-
{
    'name': 'Pways ZK Biometric Device Integration',
    'version': '14.0',
    'summary': """Integrating Biometric Device (Model: ZKteco uFace 202) With HR Attendance (Thumb)""",
    'description': """This module integrates Odoo with the biometric device(Model: ZKteco uFace 202),odoo13,odd,hr,attendance""",
    'category': 'Generic Modules/Human Resources',
    'author': "Preciseways",
    'website': "http://www.preciseways.com",
    'depends': ['base_setup', 'hr_attendance'],
    'data': [
        'security/ir.model.access.csv',
        'data/cron.xml',
        'views/operation_type_view.xml',
        'views/device_view.xml',
        'views/zk_attendance_logs.xml',
        'wizard/zk_attendance_wizard.xml',
    ],
    'demo': [],
    'installable': True,
    'auto_install': False,
    'application': False,
}
