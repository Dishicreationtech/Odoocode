# -*- coding: utf-8 -*-
from odoo import models,fields,api,_
import pickle
import base64
import io
import pytz
import sys
import datetime
import logging
import binascii
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError
_logger = logging.getLogger(__name__)
try:
    from zk import ZK, const
except ImportError:
    _logger.error("Please Install pyzk library.")

_logger = logging.getLogger(__name__)


class ZkAttendanceWizard(models.TransientModel):
    _name = 'zk.attendance.wizard'

    type = fields.Selection([('campus', 'Campus'), ('factory', 'Factory')], string='Type', required=True, default='factory')
    input_file = fields.Binary('Select File')
    date_time = fields.Date('Date')
    device_id = fields.Many2one("device.line", string="Device")

    def get_data(self, data):
        data_values = []
        values = data.replace(b'\t', b',')
        split_value = values.split(b'\r\n')
        for rec in split_value:
            data_values.append(str(rec.strip(), 'utf-8').split(','))
        return data_values

    def _get_client_time(self, sync_time):
        from datetime import datetime
        date = sync_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(pytz.utc.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date


    def import_attendance(self, attendance_lines):
        for line in attendance_lines:
            if line[0] != '':
                employee_id = self.env['hr.employee'].search([('device_id', '=', line[0])])
                atten_time = datetime.datetime.strptime(fields.Datetime.from_string(line[1]).strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')
                local_tz = pytz.timezone(self.env.user.partner_id.tz or 'GMT')
                local_dt = local_tz.localize(atten_time, is_dst=None)
                utc_dt = local_dt.astimezone(pytz.utc)
                utc_dt = utc_dt.strftime("%Y-%m-%d %H:%M:%S")
                atten_time = datetime.datetime.strptime(utc_dt, "%Y-%m-%d %H:%M:%S")
                if employee_id:
                    if self._get_client_time(self.date_time) < self._get_client_time(atten_time):
                        att_rec = self.env['hr.attendance'].search([
                            ('att_type', '=', self.type),
                            ('employee_id', '=', employee_id.id),
                            ('check_in', '<', atten_time),
                            ('check_out', '=', False)
                        ])
                        if att_rec:
                            att_rec.write({'check_out': fields.Datetime.to_string(atten_time)})
                        else:
                            self.env['hr.attendance'].create({
                                'att_type': self.type,
                                'employee_id': employee_id.id,
                                'check_in': fields.Datetime.to_string(atten_time),
                            })
                    else:
                        _logger.error("Employee not found with ID : ")
                else:
                    _logger.error("Employee not found with ID : ")

    def get_attenance(self):
        if not self.input_file:
            raise Warning(_('Please select a file.'))
        data = base64.b64decode(self.input_file)
        values = self.get_data(data)
        self.import_attendance(values)
        return True