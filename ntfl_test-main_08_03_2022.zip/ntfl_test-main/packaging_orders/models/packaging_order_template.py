# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class PackagingTemplate(models.Model):
    _name = 'packaging.order.template'
    _description = 'Packaging Order Template'

    name = fields.Char(required=True)
    product_id = fields.Many2one('product.product', string="Product", required=True)
    packaging_order_line = fields.One2many('packaging.order.template.line', 'template_id', string="Packaging Lines")
    location_id = fields.Many2one('stock.location', string='Source', domain="[('is_collection_center', '=', False)]")
    location_dest_id = fields.Many2one('stock.location', string='Designation', domain="[('is_collection_center', '=', False)]")
    packing_type = fields.Selection([('pos', 'POS'), ('auction', 'Auction'), ('export', 'Export'), ('local', 'Local'), ('other', 'Other')], string='Packing Type', default='local')


class PackagingTemplateLine(models.Model):
    _name = 'packaging.order.template.line'
    _description = 'Packaging Order Template Lines'

    product_id = fields.Many2one('product.product', string="Product")
    template_id = fields.Many2one('packaging.order.template')
