# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import models
from . import wizard

from odoo import api, SUPERUSER_ID


def _create_warehouse_data(cr, registry):
    """ This hook is used to add a default manufacture_pull_id, manufacture
    picking_type on every warehouse. It is necessary if the mrp module is
    installed after some warehouses were already created.
    """
    env = api.Environment(cr, SUPERUSER_ID, {})
    shoprting_type = env['stock.picking.type'].search([('code', '=', 'packaging_order')])
    warehouse_id = env['stock.warehouse'].search([('company_id', '=', env.user.company_id.id)], limit=1)
    shoprting_type.write({'warehouse_id': warehouse_id.id})
