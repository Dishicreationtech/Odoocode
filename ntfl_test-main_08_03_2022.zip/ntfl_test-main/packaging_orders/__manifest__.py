{
    'name': "Packaging Orders Operations",
    "category": "stock",
    'summary':""" Packaging Orders Operations """,
    'depends': ['mail', 'stock', 'mrp'],
    'data': [
        'security/ir.model.access.csv',
        'data/stock_data.xml',
        'views/stock_view.xml',
        'views/packaging_order_template.xml',
        'views/packaging_order_view.xml',
        'wizard/pack_backorder_wizard.xml',
    ],
    'post_init_hook': '_create_warehouse_data',
    'installable' : True,
    'application' :  True,
}
