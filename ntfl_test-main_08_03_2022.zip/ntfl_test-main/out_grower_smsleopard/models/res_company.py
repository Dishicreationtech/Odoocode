# -*- coding: utf-8 -*-
from odoo import fields, models
from datetime import datetime, timedelta

class Mobireach(models.Model):
    _inherit = "res.company"
    _description = "Out Grower Smsleopard"

    account_id = fields.Char(string="Account Id", copy=False)
    secret = fields.Char(string="Secret Key")
    source = fields.Char(string="Source")
    