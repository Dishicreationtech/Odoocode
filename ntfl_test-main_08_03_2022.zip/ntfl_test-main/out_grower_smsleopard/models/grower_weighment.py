# -*- coding: utf-8 -*-
from odoo import fields, models, api, tools, _
import requests
import json
import logging
from datetime import datetime, timedelta
from odoo.exceptions import ValidationError
_logger = logging.getLogger(__name__)

class InheriteWeighment(models.Model):
    _inherit = "grower.weighment"
    _description = "Inherite Grower Weighment"

    def _get_message(self, farmer, total_net, weighment_ids):
        message = " "
        template = self.env.ref('out_grower_smsleopard.sms_template_weighment', raise_if_not_found=False)
        if template:
            template.write({
                "body_html" : "<p>Dear,</br>{}</br> Your Total Net Amount Is {}</br></br> Thank You,</p>".format(farmer, str(total_net))
            })
            template_body = template._render_template(template.body_html, 'grower.weighment', weighment_ids.ids)
            message = tools.html2plaintext(template_body.get(weighment_ids.ids[0])).replace("*", "")
        return message

    def _prepare_url(self, farmer, total_net, weighment_ids):
        smsleopard_url = 'https://api.smsleopard.com/v1/sms/send?'
        company_id = self.env.company
        get_message = self._get_message(farmer, total_net, weighment_ids)
        if not company_id.source:
            raise ValidationError(_("Please set smsleopard configureration in compnay then after send sms...!"))
        if not farmer.mobile:
            raise ValidationError(_("Please set mobile number in farmer...!"))
        full_url = smsleopard_url+'message='+get_message+'&destination='+farmer.mobile+'&source='+company_id.source
        return full_url

    def send_message(self, farmer, total_net, weighment_ids):
        url = self._prepare_url(farmer, total_net, weighment_ids)
        company_id = self.env.company
        response = requests.get(url, auth=(company_id.account_id, company_id.secret))
        try:
            if response.status_code not in [200, 201]:
                _logger.info("Wrong Data Found {0}".format(response.text))
            else:
                _logger.info("Message Has Been Send {0}".format(response.text))
        except Exception as e:
            _logger.info("RESPONCE IS: {0}".format(e))
        return True

    def grower_weigment_cron(self):
        total_net = 0.0
        farmer = []
        registration_ids = self.env['res.partner'].search([('is_farmer', '!=' , False )])
        for farmer in registration_ids:
            weighment_ids = self.env['grower.weighment'].search([('farmer_id', '=', farmer.id), ('weighment_date' , '=', fields.Date.today())])
            if weighment_ids:
                total_net = sum(rec.total_net for rec in weighment_ids)
                self.send_message(farmer, total_net, weighment_ids)
        return True