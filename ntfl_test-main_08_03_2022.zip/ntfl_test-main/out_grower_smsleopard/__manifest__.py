# -*- coding: utf-8 -*-
{
    'name': "Out Grower Smsleopard",
    'version': '14.0',
    'summary': 'This module are used smsleopard',
    'description': 'This module are used smsleopard',
    'depends': ['out_grower',],
    'data': [
        'security/ir.model.access.csv',
        'views/res_company_view.xml',
        'wizard/out_grower_smsleport.xml',
        'data/ir_crone.xml',
        'data/sms_template.xml',
    ],
    'application': True,
    'installable': True,
}
