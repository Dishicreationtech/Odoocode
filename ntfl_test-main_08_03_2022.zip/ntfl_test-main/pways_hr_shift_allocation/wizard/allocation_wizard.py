from odoo import models, fields, api, _
from datetime import datetime, timedelta

class AllocationWizard(models.TransientModel):
	_name = "allocation.wizard"
	_description = "allocation.wizard"

	description = fields.Text()
	date_from = fields.Date()
	date_to  = fields.Date()
	shift_id = fields.Many2one("hr.shift",required=True)
	employee_ids = fields.Many2many("hr.employee",required=True)
	week_ids = fields.Many2many('week.week', string="Weeks")
	
	@api.model
	def default_get(self, fields):
		vals = super(AllocationWizard, self).default_get(fields)
		active_ids = self.env.context.get('active_ids')
		vals['employee_ids'] = active_ids
		return vals

	def _prepaire_days_of_week_lines(self, employee_id):
		days_of_week_lines = []
		if self.date_from and self.date_to:
			date_array = (self.date_from + timedelta(days=x) for x in range(0, (self.date_to-self.date_from).days))
			for date_object in date_array:
				for week in self.week_ids:
					if str(date_object.weekday()) == week.code:
						days_of_week_lines.append((0,0,{
							'date' : date_object,
							'week_id' : week.id,
							'employee_id' : employee_id.id
							}))
		return days_of_week_lines

	def bulk_allocation(self):
		vals = {
			'date_from': self.date_from,
			'date_to': self.date_to,
			'shift_id': self.shift_id.id,
			'shift_type_id': self.shift_id.shift_type_id and self.shift_id.shift_type_id.id,
			'description': self.description,
			'state': 'in_progress',
		}
		for emp in self.employee_ids:
			vals['employee_id'] = emp.id
			lines = self._prepaire_days_of_week_lines(emp)
			vals['dayofweek_ids'] = lines
			self.env['shift.allocation'].create(vals)
		# link with emp
		# self.employee_ids.write({
		# 	'resource_calendar_id': self.shift_id.calender_id and self.shift_id.calender_id.id
		# })

