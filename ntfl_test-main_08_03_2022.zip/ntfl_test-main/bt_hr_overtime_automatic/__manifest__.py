# -*- coding: utf-8 -*-

{
    'name': 'Automatic Overtime',
    'summary': 'Automatic Overtime',
    'description': """Management of overtime taken by the employees.""",
    'depends':['hr_contract','hr_attendance', 'hr', 'hr_payroll'],
    'data': [
        'security/ir.model.access.csv',
        'views/bt_hr_overtime_view.xml',
        'views/hr_ot_rule_view.xml',
        'views/universal_holidays.xml',
        'data/bt_hr_overtime_data.xml'
    ],
    'installable': True,
    'application': True,
}

