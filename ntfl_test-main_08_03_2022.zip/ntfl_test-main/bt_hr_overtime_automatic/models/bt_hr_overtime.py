# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from datetime import date,datetime,timedelta
from ast import literal_eval
import datetime
import time
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError

class Company(models.Model):
    _inherit = "res.company"

    min_overtime = fields.Float(string="Min Overtime")
    max_overtime = fields.Float(string="Max Overtime")
    types = fields.Selection([('daily', 'Daily'), ('weekly', 'Weekly'), ('monthly', 'Monthly')])


class BtHrOvertime(models.Model):   
    _name = "bt.hr.overtime"
    _description = "Bt Hr Overtime" 
    _rec_name = 'employee_id'
    _order = 'id desc'
    
    employee_id = fields.Many2one('hr.employee', string="Employee")
    manager_id = fields.Many2one('hr.employee', string='Manager')
    start_date = fields.Datetime('Date')
    overtime_hours = fields.Float('Overtime Hours')
    notes = fields.Text(string='Notes')
    state = fields.Selection([('draft', 'Draft'), ('confirm', 'Waiting Approval'), ('refuse', 'Refused'), 
           ('validate', 'Approved'), ('cancel', 'Cancelled')], default='draft', copy=False)
    attendance_id = fields.Many2one('hr.attendance', string='Attendance')
    rate = fields.Float(string="Rate")
    ot_type_id = fields.Many2one('hr.ot.type', string="OT Types")
    is_payslip_create = fields.Boolean(string="Payslip Created")
    
    def _find_universal(self, check_in):
        date = datetime.datetime.strptime(fields.Date.to_string(check_in.date()), DEFAULT_SERVER_DATE_FORMAT)
        universal_holidays_id = self.env['universal.holidays'].search([('date', '=', date)], limit=1)
        if universal_holidays_id:
            return 'SPHD' if universal_holidays_id.special_holidays else 'HDS'
        return False

    def _get_overtime_type(self, check_in):
        universal_days = self._find_universal(check_in)
        if universal_days:
            return universal_days
        return 'WDS' if check_in.weekday() > 4 else 'NOD'

    @api.model
    def run_overtime_scheduler(self):
        """ This Function is called by scheduler. """
        current_date = date.today()
        working_hours_empl = self.env['hr.contract']
        attend_signin_ids = self.env['hr.attendance'].search([('overtime_created', '=', False)])
        for obj in attend_signin_ids:
            if obj.check_in and obj.check_out:            
                start_date = datetime.datetime.strptime(obj.check_in.strftime('%Y-%m-%d %H:%M:%S'), DEFAULT_SERVER_DATETIME_FORMAT)                
                end_date = datetime.datetime.strptime(obj.check_out.strftime('%Y-%m-%d %H:%M:%S'), DEFAULT_SERVER_DATETIME_FORMAT)                 
                difference = end_date - start_date
                #To calculate hour difference of an employee. It will calculate hour difference even if employee work more than 24 hours 
                hour_diff =int((difference.days) * 24 + (difference.seconds) / 3600)  
                min_diff = str(difference).split(':')[1]
                tot_diff = str(hour_diff) + '.' + min_diff
                actual_working_hours = float(tot_diff)
                contract_obj = self.env['hr.contract'].search([('employee_id', '=', obj.employee_id.id),('work_hours','!=',0)])
                for contract in contract_obj:
                    working_hours = contract.work_hours
                    if actual_working_hours > working_hours:
                        overtime_hours = actual_working_hours - working_hours
                        overtime_type = self._get_overtime_type(obj.check_in)
                        ot_type_id = self.env['hr.ot.type'].search([('code', '=', overtime_type)], limit=1)
                        vals = {
                            'employee_id': obj.employee_id and obj.employee_id.id or False,
                            'manager_id' : obj.employee_id and obj.employee_id.parent_id and obj.employee_id.parent_id.id or False,
                            'start_date' : obj.check_in,
                            'overtime_hours': round(overtime_hours,2),
                            'attendance_id': obj.id,
                            'ot_type_id' : ot_type_id.id if ot_type_id else False,
                            }
                        self.env['bt.hr.overtime'].create(vals)
                        obj.overtime_created = True
                        
                        
    def action_submit(self):
        return self.write({'state':'confirm'})
            
    def action_cancel(self):
        return self.write({'state':'cancel'})
            
    def action_approve(self):
        return self.write({'state':'validate'})
        
    def action_refuse(self):
        return self.write({'state':'refuse'})
            
    def action_view_attendance(self):
        attendances = self.mapped('attendance_id')
        action = self.env.ref('hr_attendance.hr_attendance_action').read()[0]
        if len(attendances) > 1:
            action['domain'] = [('id', 'in', attendances.ids)]
        elif len(attendances) == 1:
            action['views'] = [(self.env.ref('hr_attendance.hr_attendance_view_form').id, 'form')]
            action['res_id'] = self.attendance_id.id
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action
        

class Contract(models.Model):
    _inherit = 'hr.contract'
    
    work_hours = fields.Float(string='Working Hours')
    type_of_contract = fields.Selection([('normal_days', 'Normal Days'), ('weekday_days', 'Week Days'), ('holidays', 'Holidays'), ('special_holidays', 'Special Holidays')], string="Typs of Contract")
    normal_days_rate = fields.Float(string="Normal Days")
    weekday_days_rate = fields.Float(string="Weekday Days")
    holidays_rate = fields.Float(string="Holidays Rate")
    special_holidays = fields.Float(string="Special Holidays")
    contract_type = fields.Many2one('hr.contract.type', string="Contract Type")
    
class HrAttendance(models.Model):
    _inherit = "hr.attendance" 
    
    overtime_created = fields.Boolean(string = 'Overtime Created', default=False, copy=False)

class HrPayslipInput(models.Model):
    _inherit = 'hr.payslip.input'

    ot_description = fields.Char(string="Overtime")

class PayslipOverTime(models.Model):
    _inherit = 'hr.payslip'

    overtime_ids = fields.Many2many('hr.overtime')

    def get_overtime_data(self, overtime_ids):
        ot_dict = {}
        vals = []
        for line in overtime_ids:
            if line.ot_type_id in ot_dict:
                ot_dict[line.ot_type_id] += line
            else:
                ot_dict[line.ot_type_id] = line
        return ot_dict

    def compute_sheet(self):
        """
        function used for writing overtime record in payslip
        input tree.

        """
        overtime_type = self.env['hr.salary.rule'].search([('code', '=', 'OT100')], limit=1)
        if not overtime_type:
            raise ValidationError(_("Rule for over time with code OT100 not found"))
        input_type_input_type = self.env.ref('bt_hr_overtime_automatic.hr_payslip_input_type_input')
        input_ids = self.env['hr.payslip.input'].browse(input_type_input_type)
        compnay_id = self.env.company
        contract_id = self.contract_id
        overtime_ids = self.env['bt.hr.overtime'].search([('employee_id', '=', self.employee_id.id), ('start_date', '>=', self.date_from), ('start_date', '<=', self.date_to)])
        rate_amount = sum(overtime_ids.mapped('overtime_hours'))
        overtime_lines = self.get_overtime_data(overtime_ids)
        input_data = {
            'name': overtime_type.name,
            'code': overtime_type.code,
            'payslip_id' : self.id,
            'contract_id': contract_id.id,
            'input_type_id' : input_type_input_type.id,
            'sequence' : 1,
            'amount' : 0.0
        }
        self.env['hr.payslip.input'].create(input_data)
        res = super(PayslipOverTime, self).compute_sheet()
        rec = self._get_worked_day_lines_values(domain=[])
        total_hours = rec[0].get('number_of_hours') if rec and rec[0] else 0.0
        self.input_line_ids = [(5, 0, 0)]
        out_worked_days_line_ids = self.worked_days_line_ids.filtered(lambda x : x.work_entry_type_id and x.work_entry_type_id.code == 'WORK100')
        number_of_hours = sum(out_worked_days_line_ids.mapped('number_of_hours'))
        if contract_id.rule_line_ids and overtime_lines:
            for ot_type_id, overtime_ids in overtime_lines.items():
                overtime_hours = sum(overtime_ids.mapped('overtime_hours'))
                rule_line_id = contract_id.rule_line_ids.filtered(lambda x: x.ot_rule_id and x.ot_rule_id.ot_type_id.id ==  ot_type_id.id)
                if rule_line_id.ot_type == 'fix':
                    input_data.update({
                        'amount': overtime_hours * rule_line_id.fix_amount,
                        'ot_description' : "{}".format(ot_type_id.name,)
                    })
                    input_line_id = self.env['hr.payslip.input'].create(input_data)
                if rule_line_id.ot_type == 'percentage':
                    line_id = self.line_ids.filtered(lambda x : x.code == rule_line_id.per_based_on)
                    if line_id and total_hours:
                        amount = line_id.amount / total_hours
                        per_amount = (amount * rule_line_id.per_amount) / 100
                        input_data.update({
                            'amount': per_amount * overtime_hours,
                            'ot_description' : "{}-{}".format(ot_type_id.name, rule_line_id.per_based_on)
                        })
                        input_line_id = self.env['hr.payslip.input'].create(input_data)
                if input_line_id:
                    overtime_ids.write({'is_payslip_create' : True})
        return res

