# -*- coding: utf-8 -*-
from odoo import fields, api, models, _

class UniversalHolidays(models.Model):
	_name = "universal.holidays"
	_description = "Universal  Holidays"

	name = fields.Char(string="Name")
	date = fields.Date(string="Date")
	special_holidays = fields.Boolean(string="Special Holidays")
	