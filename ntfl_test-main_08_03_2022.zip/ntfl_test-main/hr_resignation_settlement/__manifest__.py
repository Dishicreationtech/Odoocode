{
    'name': 'Employee Settlement',
    'summary': """Employee Settlement During Resignation """,
    'depends': ['hr_resignation'],
    'data': [
    		 'data/data.xml',
             'views/other_settlements.xml',
             'security/ir.model.access.csv'],
    'demo': [],
    'installable': True,
    'application': False,
}
