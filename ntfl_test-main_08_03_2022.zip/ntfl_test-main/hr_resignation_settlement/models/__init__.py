from . import other_settlements
