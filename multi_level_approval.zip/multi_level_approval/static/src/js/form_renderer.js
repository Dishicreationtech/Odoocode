/** @odoo-module **/

import ActivityMenu from '@mail/js/systray/systray_activity_menu';
import session  from 'web.session';

ActivityMenu.include({
    //-----------------------------------------
    // Handlers
    //-----------------------------------------

    /**
     * @private
     * @override
     */
    _onActivityFilterClick: function (event) {
        // fetch the data from the button otherwise fetch the ones from the parent (.o_mail_preview).
        var data = _.extend({}, $(event.currentTarget).data(), $(event.target).data());
        var context = {};
        if (data.filter === 'my') {
            context['search_default_activities_overdue'] = 1;
            context['search_default_activities_today'] = 1;
        } else {
            context['search_default_activities_' + data.filter] = 1;
        }
        // Necessary because activity_ids of mail.activity.mixin has auto_join
        // So, duplicates are faking the count and "Load more" doesn't show up
        context['force_search_count'] = 1;

        var domain = [['activity_ids.user_id', '=', session.uid]]
        if (data.domain) {
            domain = domain.concat(data.domain)
        }
        if (data.approval_domain && data.filter === 'approval') {
            domain = domain.concat(data.approval_domain)
        }
        this.do_action({
            type: 'ir.actions.act_window',
            name: data.model_name,
            res_model:  data.res_model,
            views: this._getViewsList(data.res_model),
            search_view_id: [false],
            domain: domain,
            context:context,
        }, {
            clear_breadcrumbs: true,
        });
    },
});

odoo.define('record_approval.form_renderer', function (require) {
"use strict";

var core = require('web.core');
const FormRenderer = require('web.FormRenderer');
var rpc = require('web.rpc');
var _t = core._t;

    FormRenderer.include({
        _renderTagHeader: function (node) {
            var self = this;
            var $statusbar = this._super(node);
            var def = this._rpc({
                model: 'record.approval',
                method: 'get_approval',
                args: [this.state.model, this.state.res_id],
            });
            def.then(function (result) {

                var buttons = $statusbar.find(".o_statusbar_buttons");
                var for_hide = ['pways_action_approve', 'pways_action_reject', 'pways_action_pending', 'pways_action_send_approval']
                var approval = ['pways_action_approve', 'pways_action_reject', 'pways_action_pending']
                if (!result['show_approval'] && !result['show_all']) {
                    // ----------Hide All buttons------------
                    _.each(buttons.children(), function (button) {
                        $(button).css({display: 'none'});
                    });
                }
                else if (result['show_approval']) {
                    //----------Hide Other buttons------------
                    _.each(buttons.children(), function (button) {
                        if (!approval.includes($(button).attr("name"))) {
                            $(button).css({display: 'none'});
                        }
                    });
                }
                else if (result['show_all']) {
                    //----------Hide approval buttons---------
                    _.each(buttons.children(), function (button) {
                        if (for_hide.includes($(button).attr("name"))) {
                            $(button).css({display: 'none'});
                        }
                    });
                }
                if (!result['show_all'] && !result['to_approve']) {
                    //----------Show approval status wizard---------
                    _.each(buttons.children(), function (button) {
                        if ($(button).attr("name") === 'pways_action_pending') {
                            $(button).css("display","");
                        }
                    });
                }
                if (result['to_approve']) {
                    _.each(buttons.children(), function (button) {
                        if ($(button).attr("name") === 'pways_action_send_approval') {
                            $(button).css("display","");
                        }
                    });
                }

            });
            return $statusbar;
        },

        _renderHeaderButtons: function (node) {
            var is_approve = false;
            var is_reject = false;
            var is_pending = false;
            var for_approve = false;
            _.each(node.children, function (child) {
                if (child.attrs.name === 'pways_action_approve') {
                    is_approve = true;
                }
                if (child.attrs.name === 'pways_action_reject') {
                    is_reject = true;
                }
                if (child.attrs.name === 'pways_action_pending') {
                    is_pending = true;
                }
                if (child.attrs.name === 'pways_action_send_approval') {
                    for_approve = true;
                }
            });
            if (!is_approve) {
                node.children.push({
                    tag: "button",
                    attrs: {
                        name: "pways_action_approve",
                        type: "object",
                        string: "Approve",
                        class: "btn-primary",
                    }
                });
            }
            if (!for_approve) {
                node.children.push({
                    tag: "button",
                    attrs: {
                        name: "pways_action_send_approval",
                        type: "object",
                        string: "Send For Approval",
                        class: "btn-primary",
                    }
                });
            }
            if (!is_reject) {
                node.children.push({
                    tag: "button",
                    attrs: {
                        name: "pways_action_reject",
                        type: "object",
                        string: "Reject",
                    }
                });
            }
            if (!is_reject) {
                node.children.push({
                    tag: "button",
                    attrs: {
                        name: "pways_action_pending",
                        type: "object",
                        string: "Approval Status",
                    }
                });
            }
            return this._super.apply(this, arguments);
        },
    });
});
