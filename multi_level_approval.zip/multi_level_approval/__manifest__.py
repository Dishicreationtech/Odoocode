# -*- coding: utf-8 -*-
{
    'name': 'Multi Level Approval',
    'version': '16.0.0',
    'author': 'Dishi Creation.',
    'website': "www.dishicreation.com",
    'summary': 'Multi Level User Approval',
    'depends': ['base', 'web', 'sale'],
    'data': [
        'data/activity_data.xml',
        'security/ir.model.access.csv',
        'views/record_approval_view.xml',
        'wizard/pending_details_wizard.xml',
        'wizard/reject_reason_wizard.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'record_approval/static/src/**/*',
        ],
        'web.assets_qweb': [
            'record_approval/static/src/xml/systray.xml',
        ],
    },
    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}
