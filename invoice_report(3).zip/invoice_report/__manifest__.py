# -*- coding: utf-8 -*-
{
    'name': "Invoice Report",
    'summary': "Invoice Report",
    'description': "Invoice Report",
    'category': 'account',
    "author": "Dishi Creation",
    "website": "www.dishicreation.com",
    'version': '15.0.0',
    'depends': ['account', 'purchase', 'stock'],
    'data': [
        'wizard/product_sold_views.xml',
    ],
    'license': 'LGPL-3',
}
