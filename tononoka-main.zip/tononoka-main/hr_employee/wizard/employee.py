# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date, timedelta
from odoo.tools import date_utils
import time
import json
import datetime
import io
from odoo import fields, models, _
from odoo.exceptions import ValidationError
from odoo.tools import date_utils

import calendar
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

class EmployeeReport(models.TransientModel):
    _name = 'employee.report'
    _description = 'Employee Reports'

    def get_report(self):
        data = {
            'ids': self.ids,
            'model': self._name,
        }
        return self.env.ref('hr_employee.employee_report').report_action(self, data=data)

class EmployeeReportTemplate(models.AbstractModel):
    _name = 'report.hr_employee.employee_report_template'
    _description = 'Employee Reports Template'

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
                'doc_ids': data.get('ids'),
                'doc_model': data.get('model'),
                'employee_ids': self.env['hr.employee'].search([]),
                }
