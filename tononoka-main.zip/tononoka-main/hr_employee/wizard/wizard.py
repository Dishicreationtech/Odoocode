# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date, timedelta
from odoo.tools import date_utils
import time
import json
import datetime
import io
from odoo import fields, models, _
from odoo.exceptions import ValidationError
from odoo.tools import date_utils

import dateutil

try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    import xlsxwriter

import calendar
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

class ResourceCalendarLeaves(models.Model):
    _inherit = 'resource.calendar.leaves'

    duration = fields.Float('Duration', compute='_compute_duration', store=True, readonly=False)

    def _get_duration(self, start, stop):
        """ Get the duration value between the 2 given dates. """
        if not start or not stop:
            return 0
        # import pdb;pdb.set_trace(); 
        duration = (stop - start).days
        return duration

    @api.depends('date_from', 'date_to')
    def _compute_duration(self):
        for event in self:
            event.duration = self._get_duration(event.date_from, event.date_to)

class Payroll(models.TransientModel):
    _name = 'import.payroll'
    _description = 'Import Payroll'


    date_start = fields.Date(string="Start Date", required=True)
    date_end = fields.Date(string="End Date", required=True)


    @api.constrains('date_start', 'date_end')
    def check_dates(self):
        if self.filtered(lambda leave: leave.date_start > leave.date_end):
            raise ValidationError(_('The start date must be earlier than the end date.'))

    def rounding_interval(self, duration):
        hour, minute = divmod(duration, 1)
        minute *= 60
        if int(minute):
            if int(minute) < 8:
                minute = 0
            if int(minute) < 23 and int(minute) >= 8 :
                minute = 15
            if int(minute) < 38 and int(minute) >= 23:
                minute = 30
            if int(minute) < 52 and int(minute) >= 38:
                minute = 45
            if int(minute) >= 52:
                minute = 0
                hour = int(hour) + 1
        return '{}:{}'.format(int(hour), int(minute))


    def get_report(self):
        data = {}
        ICP = self.env['ir.config_parameter'].sudo()
        WORKING_HOURS = int(ICP.get_param('hr_employee.working_hours')) or 0
        WORKING_HOURS_SATURDAY = int(ICP.get_param('hr_employee.working_hours_saturday')) or 0
        NIGHT_ALLOWANCE = int(ICP.get_param('hr_employee.night_allowance')) or 0
        MAX_TOLEARANCE = int(ICP.get_param('hr_employee.max_tolearance')) or 0
        MAX_TOLEARANCE_SATURDAY = int(ICP.get_param('hr_employee.max_tolearance_saturday')) or 0
        NIGHT_SHIFT = int(ICP.get_param('hr_employee.night_shift')) or False
        start_date  = datetime.datetime.combine(self.date_start, datetime.time(0, 0))
        end_date  = datetime.datetime.combine(self.date_end, datetime.time(0, 0))
        employees = self.env['hr.employee'].search([])
        if employees:
            for employee in employees:
                leave = self.env['hr.leave'].search([('request_date_from','>=',start_date),('request_date_to','<=', end_date),('employee_id','=',employee.id),('state','=','validate')])
                # if employee.id == 2275:
                #     import pdb;pdb.set_trace();
                global_leave = employee.resource_calendar_id.global_leave_ids
                #leave management 
                attendance_ids = employee.attendance_ids.filtered(lambda att: att.check_in >= start_date and att.check_in  <= end_date and att.approved_type == 'approved')
                absent = 0
                global_search = global_leave.search([('date_to','>=',start_date),('date_from','<=',end_date)])
                # print (global_search.mapped('date_from'))
                # print (global_search.mapped('date_to'))
                # gs = len(global_search)
                gs = sum(global_search.mapped('duration'))
                print (gs)
                if gs:
                    absent = (gs * -1)
                print ("================gs",employee.name,global_search)
                # import pdb;pdb.set_trace();
                for dt in dateutil.rrule.rrule(dateutil.rrule.DAILY, dtstart=start_date, until=end_date):
                    if not dt.weekday() in  range(0,6) :
                        continue
                    if not attendance_ids.filtered(lambda att: fields.Date.from_string(att.check_in) == dt.date() and fields.Date.from_string(att.check_out) == dt.date()):
                        absent +=1
                if leave:
                    absent = absent - sum(leave.mapped('number_of_days'))
                attendances = employee.attendance_ids.filtered(lambda att: att.check_in >= start_date and att.check_in <= end_date and att.approved_type == 'approved')
                if employee.shift_id.sub_category_id.category_type == 'Factory':
                    attendances = attendances.filtered(lambda att: att.att_type == 'factory')
                else:
                    attendances = attendances.filtered(lambda att: att.att_type == 'campus')
                ot1_hours = 0
                # OT 1 is calculated as any hours worked more then 8 on Monday to Friday or more then 5 on Saturday.
                ot2_hours = 0
                # OT 2 is calculated as all hours worked on a Sunday or Public Holiday.
                # absent = 0
                night_allowance = 0
                # Night allowance is 2 per hour worked during Night Shift.
                date_check_in = {}
                theoritical_hours = 0
                night_check_in = {}
                for attendance in attendances:
                    if attendance.check_in and attendance.check_out and attendance.date_check_in:
                        if date_check_in.get(attendance.date_check_in):
                            theoritical_hours = date_check_in.get(attendance.date_check_in)
                            date_check_in.update({attendance.date_check_in: attendance.theoritical_hours + theoritical_hours})             
                        else:
                            date_check_in[attendance.date_check_in] =  attendance.theoritical_hours

                night_theoritical_hours = 0
                for attendance in attendances:
                    if attendance.check_in and attendance.check_out and attendance.date_check_in and attendance.night_shift_id.id == NIGHT_SHIFT: 
                        if night_check_in.get(attendance.date_check_in):
                            night_theoritical_hours = night_check_in.get(attendance.date_check_in)
                            night_check_in.update({attendance.date_check_in: attendance.theoritical_hours + night_theoritical_hours})             
                        else:
                            night_check_in[attendance.date_check_in] =  attendance.theoritical_hours
                
                
                for key in  night_check_in:
                    na = night_check_in[key]
                    night_allowance += round(na,2)

                night_allowance *= NIGHT_ALLOWANCE
                for key in  date_check_in:
                    global_search = global_leave.search([('date_to','>=',key),('date_from','<=',key),('resource_id','=',False)])
                    if not global_search:
                        if key.weekday() in  range(0,5):
                            if date_check_in[key] > WORKING_HOURS:
                                overtime_hours = date_check_in[key] - WORKING_HOURS
                                if overtime_hours >= MAX_TOLEARANCE:
                                    overtime_hours = MAX_TOLEARANCE
                                ot1_hours += round(overtime_hours,2)
                        elif key.weekday() == 5:
                            if date_check_in[key] > WORKING_HOURS_SATURDAY:
                                overtime_hours = date_check_in[key] - WORKING_HOURS_SATURDAY
                                if overtime_hours >= MAX_TOLEARANCE_SATURDAY:
                                    overtime_hours = MAX_TOLEARANCE_SATURDAY
                                ot1_hours += round(overtime_hours,2)
                        elif key.weekday() == 6:
                            overtime_hours = date_check_in[key]
                            ot2_hours += round(overtime_hours,2)
                            absent += 1
                    else:
                        overtime_hours = date_check_in[key]
                        ot2_hours += round(overtime_hours,2)

                    
                if not employee.ot1_eligible:
                    ot1_hours = 0
                if not employee.ot2_eligible:
                    ot2_hours = 0
                ot1_hrs = self.rounding_interval(ot1_hours)
                ot2_hrs = self.rounding_interval(ot2_hours)
                na_hrs = self.rounding_interval(night_allowance)
                data.update({
                    employee.id: [
                                        employee.emp_code,
                                        employee.payroll_number,
                                        employee.name,
                                        ot1_hrs,
                                        ot2_hrs,
                                        absent,
                                        na_hrs
                                        ]
                    })
        return {
            'type': 'ir.actions.report',
            'data': {'model': 'import.payroll',
                     'options': json.dumps(data, default=date_utils.json_default),
                     'output_format': 'xlsx',
                     'report_name': 'T&A to Payroll',
                     },
            'report_type': 'xlsx',
        }

    def get_xlsx_report(self, data, response):
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet('Attendance')
        # cell_format = workbook.add_format({'align': 'center', 'font_size': '12px', 'bold': True})
        head = workbook.add_format({'align': 'center', 'bold': True,'font_size':'12px','color':'red'})
        # worksheet.set_column(0, 0, None, cell_format)
        txt = workbook.add_format({'font_size': '10px'})
        # sheet.merge_range('B2:I3', 'EXCEL REPORT', head)

        sheet.write('A1', 'EMPCODE', head)
        sheet.write('B1', 'EMPNO', head)
        sheet.write('C1', 'EMPNAME', head)
        sheet.write('D1', 'OT1-HOURS', head)
        sheet.write('E1', 'OT2-HOURS', head)
        sheet.write('F1', 'ABSENT DAYS', head)
        sheet.write('G1', 'NIGHT ALLOWANCE', head)
        row = 1    
        column = 0   
        for rec in data:
            # import pdb;pdb.set_trace();
            sheet.write(row, column, data[rec][0])  
            sheet.write(row, column + 1, data[rec][1])  
            sheet.write(row, column +2, data[rec][2])  
            sheet.write(row, column +3, data[rec][3])  
            sheet.write(row, column +4, data[rec][4])  
            sheet.write(row, column +5, data[rec][5])  
            sheet.write(row, column +6, data[rec][6])  
            row = row + 1
        # sheet.merge_range('C6:D6', data['start_date'],txt)
        # sheet.merge_range('G6:H6', data['end_date'],txt)
        workbook.close()
        output.seek(0)
        response.stream.write(output.read())
        output.close()


        # import pdb;pdb.set_trace();    