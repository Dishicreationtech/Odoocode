# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date, timedelta
from odoo.tools import date_utils
import time
import json
import datetime
import io
from odoo import fields, models, _
from odoo.exceptions import ValidationError
from odoo.tools import date_utils

import calendar
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from itertools import groupby

class OfficeDailyReport(models.TransientModel):
    _name = 'office.daily.report'
    _description = 'Office Daily Report'


    date_start = fields.Date(string="Date", required=True)
    department_wise = fields.Boolean(string="Department Via", default=False)
    department_id = fields.Many2one('hr.department', 'Department')
    category_id = fields.Many2one('employee.category', string='Category')


    def get_report(self):
        data = {
            'ids': self.ids,
            'model': self._name,
            'date_start': self.date_start,
            'department_wise': self.department_wise,
            'department_id': self.department_id and self.department_id.id,
            'category_id': self.category_id.id,
        }
        return self.env.ref('hr_employee.office_daily_attendance_report').report_action(self, data=data)

class OfficeDailyAttendanceReport(models.AbstractModel):
    _name = 'report.hr_employee.office_daily_attendance_report_template'
    _description = 'Report Office'


    def rounding_interval(self, duration):
        hour, minute = divmod(duration, 1)
        minute *= 60
        if int(minute):
            if int(minute) < 8 :
                minute = 0
            if int(minute) < 23 and int(minute) >= 8 :
                minute = 15
            if int(minute) < 38 and int(minute) >= 23:
                minute = 30
            if int(minute) < 52 and int(minute) >= 38:
                minute = 45
            if int(minute) >= 52:
                minute = 0
                hour = int(hour) + 1
        return '{}:{}'.format(int(hour), int(minute))

    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        date_start = data['date_start']
        department_wise = data['department_wise']
        print ("========================",department_wise)
        department_id = data['department_id']
        category_id = self.env['employee.category'].browse(data['category_id'])
        result_dict = {}
        emp_data = []
        move_data = {}
        attendance_ids = self.env['hr.attendance']
        employees = self.env['hr.employee'].search([('shift_id.sub_category_id.category_type','=','office')])
        if department_id and department_wise:
            employees = employees.filtered(lambda employee: employee.department_id.id == department_id)
        if category_id:
            print ("category_id",category_id)
            employees = employees.filtered(lambda x: x.category_id.id == category_id.id)
        for employee in employees.sorted(key=lambda l: (l.name)):
            hr_leave = self.env['hr.leave'].search([('employee_id', '=', employee.id), ('request_date_from', '=', date_start)], limit=1)
            domain = [
                     ('date_check_in', '=', date_start),
                     ('employee_id', '=', employee.id),
                     ('att_type', '=', 'campus'),
                     ('approved_type', '=', 'approved'),
                ]
            attendance_ids = self.env['hr.attendance'].search(domain)
            # worked_hours = self.env['ir.qweb.field.float_time'].value_to_html(sum(attendance_ids.mapped('worked_hours')), {})
            worked_hours = sum(attendance_ids.mapped('worked_hours'))
            if attendance_ids:
                for line, grouped_lines in groupby(attendance_ids, lambda m: m.employee_id):
                    grouped_lines = list(grouped_lines)
                    check_in = {k['check_in']: k['in_device_id']['operation_id']['name'] for k in grouped_lines}
                    check_out = {k['check_out']: k['out_device_id']['operation_id']['name'] for k in grouped_lines}
                    if False in check_out:
                        del[check_out[False]]
                    check_in.update(check_out)
                    move_data[line] = {
                      'check_in_out': dict(sorted(check_in.items())),
                      'worked_hours': self.rounding_interval(worked_hours),
                    }
            else:
                move_data[employee] = {
                    'leave_status': hr_leave.holiday_status_id.name if hr_leave else 'Absent',
                }
        department_ids = []
        if department_id and department_wise:
            department_ids =  self.env['hr.department'].browse(department_id)
        shift_id = self.env['hr.shift'].search([('sub_category_id.category_type','=','office')], limit=1)
        return {
                'doc_ids': data.get('ids'),
                'doc_model': data.get('model'),
                'start_date': date_start,
                'attendance_ids':attendance_ids,
                'move_data':move_data,               
                'department_wise':department_wise,
                'department_ids':department_ids,
                'shift_id':shift_id,  
                'category_id': category_id,            
                }
