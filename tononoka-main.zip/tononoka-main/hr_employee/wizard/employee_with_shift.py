# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date, timedelta
from odoo.tools import date_utils
import time
import json
import datetime
import io
from odoo import fields, models, _
from odoo.exceptions import ValidationError
from odoo.tools import date_utils

import dateutil

try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    import xlsxwriter

import calendar
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

class EmployeeShift(models.TransientModel):
    _name = 'employee.shift'
    _description = 'Employee Shift'


    date_start = fields.Date(string="Start Date", required=True)
    date_end = fields.Date(string="End Date", required=True)
    department_id = fields.Many2one('hr.department', 'Department')
    category_id = fields.Many2one('employee.category', string='Type')
    shift_id = fields.Many2one('hr.shift', string="Shift")


    @api.constrains('date_start', 'date_end')
    def check_dates(self):
        if self.filtered(lambda leave: leave.date_start > leave.date_end):
            raise ValidationError(_('The start date must be earlier than the end date.'))

    def get_report(self):
        data = {}
        date_start = self.date_start
        date_end = self.date_end
        shift_allocation = self.env['shift.allocation'].search(['|',('date_from','<=', date_start), ('date_to', '>=', date_end)])
        # import pdb;pdb.set_trace();
        
        
        # shift_employee_ids = shift_allocation.mapped('employee_id')
        data['shift_ids'] = shift_allocation.ids
        data['department_id'] = self.department_id.id
        data['category_id'] = self.category_id.id
        data['shift_id'] = self.shift_id.id
        return {
            'type': 'ir.actions.report',
            'data': {'model': 'employee.shift',
                     'options': json.dumps(data, default=date_utils.json_default),
                     'output_format': 'xlsx',
                     'report_name': 'Employee Shift',
                     },
            'report_type': 'xlsx',
        }

    def get_xlsx_report(self, data, response):
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet('Employee Shift')
        # cell_format = workbook.add_format({'align': 'center', 'font_size': '12px', 'bold': True})
        head = workbook.add_format({'align': 'center', 'bold': True,'font_size':'12px','color':'red'})
        # worksheet.set_column(0, 0, None, cell_format)
        txt = workbook.add_format({'font_size': '10px'})
        
        sheet.write('A1', 'Name', head)
        sheet.write('B1', 'Payroll Nos', head)
        sheet.write('C1', 'Id nos', head)
        sheet.write('D1', 'Job Title', head)
        sheet.write('E1', 'Department', head)
        sheet.write('F1', 'Type', head)
        sheet.write('G1', 'Date From', head)
        sheet.write('H1', 'Date End', head)
        sheet.write('I1', 'Shift', head)
        sheet.write('J1', 'Sub Category', head)

        row = 1    
        column = 0
        department_id = data.get('department_id')
        category_id = data.get('category_id')
        shift_id = data.get('shift_id')
        # import pdb;pdb.set_trace();
        shift_allocation = self.env['shift.allocation'].browse(data.get('shift_ids'))
        if department_id:
            shift_allocation = shift_allocation.filtered(lambda employee: employee.employee_id.department_id.id == department_id)
        if category_id:
            shift_allocation = shift_allocation.filtered(lambda employee: employee.employee_id.category_id.id == category_id)
        if shift_id:
            shift_allocation = shift_allocation.filtered(lambda shift: shift.shift_id.id == shift_id)
        if not shift_allocation:
            raise ValidationError(_('No Employee found with this condition.'))
        for shift in shift_allocation:
            sheet.write(row, column, shift.employee_id.name)  
            sheet.write(row, column +1, shift.employee_id.payroll_number) 
            sheet.write(row, column +2, shift.employee_id.identification_id) 
            sheet.write(row, column +3, shift.employee_id.job_title) 

            sheet.write(row, column + 4,shift.employee_id.department_id.name or '')  
            sheet.write(row, column +5, shift.employee_id.category_id.name or '')
            sheet.write(row, column +6, shift.date_from.strftime("%d/%m/%Y"))  
            sheet.write(row, column +7, shift.date_to.strftime("%d/%m/%Y")) 
            sheet.write(row, column +8, shift.shift_id.name) 
            sheet.write(row, column +9, shift.sub_category_id.name) 
            row = row + 1
        workbook.close()
        output.seek(0)
        response.stream.write(output.read())
        output.close()