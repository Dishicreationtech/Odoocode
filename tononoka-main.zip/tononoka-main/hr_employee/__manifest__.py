# -*- coding: utf-8 -*-
{
    'name' : 'Employee',
    'category': 'Hr',
    'version': '14.0.1.0',
    'description': """
        This Module contain customization related to employee
    """,
    'depends' : ['hr_attendance','hr_shift_allocation','resource'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/action_manager.xml',
        'views/res_config.xml',
        'views/view_employee_form.xml',
        'wizard/wizard.xml',
        'wizard/daily_attendance.xml',
        'wizard/office_employee_attendance.xml',
        'wizard/employee.xml',
        'report/report_action.xml',
        'report/employee_report.xml',
        'report/daily_attendance_report.xml',
        'report/office_daily_attendance_report.xml',
        'wizard/employee_with_shift.xml',
    ],
    'demo': [],
    'installable': True,
    'auto_install': False,
    'application': False,
}

