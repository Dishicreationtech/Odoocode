# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, timedelta, date
from pytz import timezone, UTC
import pytz
from odoo.addons.resource.models.resource import float_to_time, HOURS_PER_DAY
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

import calendar

import datetime


class HrShift(models.Model):
    _inherit = 'hr.shift'

    max_clock_time = fields.Integer(string='Maximum clock Time', help = '14 hours from clock in time to be zeroed for factory shift, For Office shift it is 10 hours', required=True)


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    _sql_constraints = [
        ('unique_code', 'unique (payroll_number,identification_id)', 'This code already exists')
    ]

    
    # emp_nos = fields.Char('Emp Nos')
    emp_code = fields.Char('Emp Code')
    payroll_number = fields.Char('Payroll Nos', required=True)
    date_joining = fields.Date('Date of Joining')
    ot1_eligible = fields.Boolean('OT1 Eligible')
    ot2_eligible = fields.Boolean('OT2 Eligible')


    def action_toggle_ot1(self):
        for employee in self.browse(self.env.context['active_ids']):
            employee.ot1_eligible = not employee.ot1_eligible

    def action_toggle_ot2(self):
        for employee in self.browse(self.env.context['active_ids']):
            employee.ot2_eligible = not employee.ot2_eligible

class ShiftAllocation(models.Model):
    _inherit = "shift.allocation"

    identification_id = fields.Char(related='employee_id.identification_id')
    payroll_number = fields.Char(related='employee_id.payroll_number')
    


class ResourceCalender(models.Model):
    _inherit = 'resource.calendar'

    hour_from = fields.Float(string='Work from', required=True, index=True,
                             help="Start and End time of working.\n"
                                  "A specific value of 24:00 is interpreted as 23:59:59.999999.")
    hour_to = fields.Float(string='Work to', required=True)




class HrAttendance(models.Model):
    _inherit = 'hr.attendance'

    
    date_check_in = fields.Date('Date', compute='_day_calculation' , store=True)
    night_shift_id = fields.Many2one('hr.shift', 'Shift',  compute="_employee_shift" , store=True)
    theoritical_hours = fields.Float(string='Theoritical Worked Hours', compute='_compute_theoritical_worked_hours', store=True, readonly=True)
    department_id = fields.Many2one('hr.department', related='employee_id.department_id', string='Department', readonly=True, store=True)

    @api.depends('check_in')
    def _day_calculation(self):
        for record in self:
            record.date_check_in = record.check_in.date()


    @api.depends('employee_id')
    def _employee_shift(self):
        for record in self:
            record.night_shift_id = record.employee_id.shift_id

    def _get_client_time(self, sync_time):
        """ Need to configure a time in proper manners"""
        from datetime import datetime
        if not sync_time:
            return ''
        date = sync_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(pytz.utc.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date

    @api.depends('check_in', 'check_out')
    def _compute_theoritical_worked_hours(self):
        for attendance in self:
            if attendance.check_out and attendance.check_in:
                delta = attendance.check_out - attendance.check_in
                worked_hours = delta.total_seconds() / 3600.0
                MAX_CLOCK_TIME = attendance.night_shift_id.max_clock_time
                if worked_hours  <  MAX_CLOCK_TIME:
                    attendance.worked_hours = worked_hours
                else:
                    attendance.worked_hours = MAX_CLOCK_TIME
            else:
                attendance.worked_hours = False

        ICP = self.env['ir.config_parameter'].sudo()
        NIGHT_SHIFT = int(ICP.get_param('hr_employee.night_shift')) or False
        Server_zone = float(ICP.get_param('hr_employee.server_zone')) or 0
        for attendance in self:
            week_day = attendance.sudo().check_in.weekday()
            # (7 am to 7pm)
            if attendance.night_shift_id.id != NIGHT_SHIFT:
                work_schedule = attendance.night_shift_id.calender_id
                for schedule in work_schedule.sudo().attendance_ids:
                    if schedule.dayofweek == str(week_day):
                        work_from = float_to_time(work_schedule.hour_from)
                        dt = attendance.check_in.replace(hour=int(work_from.hour),minute=int(work_from.minute), second=0)
                        # new_attendance = (datetime.strptime(str(attendance.check_in), "%Y-%m-%d %H:%M:%S")+timedelta(hours=Server_zone))
                        new_attendance = self._get_client_time(attendance.check_in)
                        if new_attendance < dt:
                            new_attendance = dt
                        if attendance.check_out and new_attendance:
                            delta = attendance.check_out - new_attendance
                            theoritical_hours = (delta.total_seconds() / 3600.0) + Server_zone
                            MAX_CLOCK_TIME = attendance.night_shift_id.max_clock_time
                            if theoritical_hours >= 0:
                                if theoritical_hours  <  MAX_CLOCK_TIME:
                                    attendance.theoritical_hours = theoritical_hours
                                else:
                                    attendance.theoritical_hours = MAX_CLOCK_TIME
                            else:
                                attendance.theoritical_hours = 0
                        else:
                            attendance.theoritical_hours = False
            else:
                # (7pm to 7am)
                work_schedule = attendance.night_shift_id.calender_id
                for schedule in work_schedule.sudo().attendance_ids:
                    if schedule.dayofweek == str(week_day):
                        work_from = float_to_time(work_schedule.hour_from)
                        dt = attendance.check_in.replace(hour=int(work_from.hour),minute=int(work_from.minute), second=0)
                        # new_attendance = (datetime.strptime(str(attendance.check_in), "%Y-%m-%d %H:%M:%S")+timedelta(hours=Server_zone))
                        new_attendance = self._get_client_time(attendance.check_in)
                        # (7pm to 12 pm)
                        if new_attendance < dt:
                            new_attendance = dt
                        if attendance.check_out and new_attendance:
                            delta = attendance.check_out - new_attendance
                            ts = (delta.total_seconds()/3600)
                            if float(ts) >= 0:
                                theoritical_hours = ts + Server_zone
                                MAX_CLOCK_TIME = attendance.night_shift_id.max_clock_time
                                if theoritical_hours >= 0:
                                    if theoritical_hours  <  MAX_CLOCK_TIME:
                                        attendance.theoritical_hours = theoritical_hours
                                    else:
                                        attendance.theoritical_hours = MAX_CLOCK_TIME
                                else:
                                    attendance.theoritical_hours = 0
                            else:
                                delta = attendance.check_out - attendance.check_in
                                ts = (delta.total_seconds()/3600)
                                MAX_CLOCK_TIME = attendance.night_shift_id.max_clock_time
                                if ts  <  MAX_CLOCK_TIME:
                                    attendance.theoritical_hours = ts
                                else:
                                    attendance.theoritical_hours = MAX_CLOCK_TIME
                        else:
                            attendance.theoritical_hours = False



