
from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    working_hours = fields.Integer('Working Hrs(Mon to Friday)',  config_parameter='hr_employee.working_hours')
    working_hours_saturday = fields.Integer('Working Hrs(Saturday)', config_parameter='hr_employee.working_hours_saturday')
    night_allowance = fields.Integer('Night Allowance',  config_parameter='hr_employee.night_allowance')
    max_tolearance = fields.Integer('Tolerance(Mon to Friday)',  config_parameter='hr_employee.max_tolearance')
    max_tolearance_saturday = fields.Integer('Tolerance(Saturday)',  config_parameter='hr_employee.max_tolearance_saturday')
    night_shift_id = fields.Many2one('hr.shift', 'Night Shift',  config_parameter='hr_employee.night_shift')
    server_zone = fields.Float('server zone',  config_parameter='hr_employee.server_zone')
