# -*- coding: utf-8 -*-
##############################################################################
from . import res_config
from . import hr

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: