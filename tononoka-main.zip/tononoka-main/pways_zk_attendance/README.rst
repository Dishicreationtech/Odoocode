Biometric Device Integration v14
================================
This module integrates Odoo attendance with biometric device attendance.

Features
========
* Integrates biometric device(Face+Thumb) with HR attendance.
* Managing attendance automatically
* Keeps zk machine history in Odoo
* Option to configure multiple zk devices
* Option to clear all zk history from both device and Odoo

Technical Notes
===============
Used Libraries:

* zklib
you can install zklib library using "sudo pip install zklib"


