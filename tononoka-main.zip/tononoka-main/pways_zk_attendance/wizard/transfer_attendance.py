# -*- coding: utf-8 -*-
import logging
from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError
_logger = logging.getLogger(__name__)
try:
    from zk import ZK, const
except ImportError:
    _logger.error("Please Install pyzk library.")

_logger = logging.getLogger(__name__)

class ZkSetUserAtendance(models.TransientModel):
    _name = 'zk.user.transfer.wizard'
    _description = 'zk.user.transfer.wizard'

    employee_ids = fields.Many2many('hr.employee', string="Employee")
    device_from_id = fields.Many2one('device.line', string="From Device")
    device_to_id = fields.Many2one('device.line', string="To Device")

    @api.model
    def default_get(self, fields):
        vals = super(ZkSetUserAtendance, self).default_get(fields)
        employee_ids = self.env['hr.employee'].browse(self.env.context.get('active_ids')).filtered(lambda x: x.device_id)
        vals['employee_ids'] = employee_ids.ids
        return vals

    def device_connect(self, machine_ip, zk_port, timeout):
        try:
            zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=1)
            conn = zk.connect()
            #conn.enable_device()
            return conn
        except:
            return False


    def transfer_users(self):
        """ Trasfer user with fingure print one device to another device"""
        from_conn = self.device_connect(self.device_from_id.device_ip, self.device_from_id.device_port, self.device_from_id.set_time_out)
        to_conn = self.device_connect(self.device_to_id.device_ip, self.device_to_id.device_port, self.device_to_id.set_time_out)
        if to_conn and from_conn:
            # Get all user from device 1 to transfer device 2
            from_users = from_conn.get_users()
            # user code of all employees to transfer
            employee_device_ids = self.employee_ids.mapped('device_id')
            users = [rec.user_id for rec in to_conn.get_users()]
            fingure_templates = from_conn.get_templates()
            user_template = {}
            for tmp in fingure_templates:
                if not user_template.get(tmp.uid, False):
                    user_template[tmp.uid] = [tmp]
                else:
                    user_template[tmp.uid] = user_template[tmp.uid] + [tmp]
            for user in from_users:
                if user.user_id in employee_device_ids and user.user_id not in users:
                    templates = user_template.get(user.uid, [])
                    if templates:
                        to_conn.set_user(name=user.name, privilege=0, password='', group_id='', user_id=user.user_id, card=0)
                    for rec in templates:
                        _logger.error("Creating User : "+ str(user.user_id))
                        to_conn.save_user_template(user.user_id, fingers=rec)
                if user.user_id in employee_device_ids and user.user_id in users:
                    templates = user_template.get(user.uid, [])
                    for rec in templates:
                        _logger.error("Update User : "+ str(user.user_id))
                        to_conn.save_user_template(user.user_id, fingers=rec)
        return True
