# -*- coding: utf-8 -*-
import logging
from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError
_logger = logging.getLogger(__name__)
try:
    from zk import ZK, const
except ImportError:
    _logger.error("Please Install pyzk library.")

_logger = logging.getLogger(__name__)

class ZkSetUser(models.TransientModel):
    _name = 'zk.set.user.wizard'
    _description = 'zk.set.user.wizard'

    employee_id = fields.Many2many('hr.employee', string="Employee")
    device_id = fields.Many2one('device.line', string="Device Line")

    def device_connect(self, zk):
        try:
            conn = zk.connect()
            return conn
        except:
            return False

    @api.model
    def default_get(self, fields):
        vals = super(ZkSetUser, self).default_get(fields)
        employee_ids = self.env['hr.employee'].browse(self.env.context.get('active_ids')).filtered(lambda x: x.device_id)
        vals['employee_id'] = employee_ids.ids
        return vals

    def set_user_attendance(self):
        machine_ip = self.device_id.device_ip
        zk_port = self.device_id.device_port
        timeout = self.device_id.set_time_out
        try:
            zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=1)
        except NameError:
            raise UserError(_("Please install it with 'pip3 install pyzk'."))
        conn = self.device_connect(zk)
        if conn:
            user_list = [u.user_id for u in conn.get_users()]
            for rec in self.employee_id:
                if self.employee_id.device_id not in user_list:
                    result = conn.set_user(name=rec.name, privilege=0, password='', group_id='', user_id=rec.device_id, card=0)
                    rec.device_ids = [(4, self.device_id.id)]
                    self.device_id.employee_ids = [(4, rec.id)]
        return {'effect': {
            'fadeout': 'slow',
            'message': "Employee Sync Successfully",
            'img_url': '/web/static/src/img/smile.svg',
            'type': 'rainbow_man'}}

    def delete_user_attendance(self):
        machine_ip = self.device_id.device_ip
        zk_port = self.device_id.device_port
        timeout = self.device_id.set_time_out
        try:
            zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=1)
        except NameError:
            raise UserError(_("Please install it with 'pip3 install pyzk'."))
        conn = self.device_connect(zk)
        if conn:
            user_list = [u.user_id for u in conn.get_users()]
            for rec in self.employee_id:
                if rec.device_id in user_list:
                    result = conn.delete_user(user_id=rec.device_id)
                    rec.device_ids = [(3, self.device_id.id)]
                    self.device_id.employee_ids = [(3, rec.id)]
        return {'effect': {
            'fadeout': 'slow',
            'message': "Employee Delete user Successfully",
            'img_url': '/web/static/src/img/smile.svg',
            'type': 'rainbow_man'}}