# -*- coding: utf-8 -*-
from odoo import api, fields, models

class ZKAttendanceLogs(models.Model):
    _name = 'zk.attendance.logs'
    _description = 'zk.attendance.logs'

    operation_type_id = fields.Many2one('operation.type', string="Operation Type")
    divice_ip = fields.Char(string="Device ID")
    divice_port = fields.Char(string="Divice Port")
    divice_serial = fields.Char(string="Divice Serial")
