# -*- coding: utf-8 -*-
import pytz
import sys
import datetime
import logging
import binascii
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models
from odoo import _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError
_logger = logging.getLogger(__name__)
try:
    from zk import ZK, const
except ImportError:
    _logger.error("Please Install pyzk library.")

_logger = logging.getLogger(__name__)

class OperationType(models.Model):
    _name = 'operation.type'
    _description = 'operation.type'

    name = fields.Char(required=True, string='Name')
    device_ids = fields.One2many('device.line', 'operation_id')
    type = fields.Selection([('campus', 'Main Gate'), ('factory', 'Factory')], string='Type', required=True, default='campus')
    

class DeviceLine(models.Model):
    _name = 'device.line'
    _description = 'device.line'
    _rec_name = 'operation_id'

    operation_id = fields.Many2one('operation.type', string="Device Name")
    device_ip = fields.Char('IP', required=True)
    device_type = fields.Selection([('in', 'Sign IN'), ('out', 'Sign Out'), ('both', 'Both')], string="Device Type")
    device_port = fields.Integer('Port', default='4370', required=True)
    device_serial = fields.Char('Serial', required=True)
    last_sync_time = fields.Datetime()
    employee_ids = fields.Many2many('hr.employee', string="Employee")
    status = fields.Selection([('success', 'Success'), ('failed', 'failed')], string='Status')
    device_set_time = fields.Datetime(string="Set Device Time", default=fields.Datetime.now())
    set_time_out = fields.Integer(string="TimeOut")
    device_active = fields.Boolean(default=True, help="Set active to false to hide the device without removing it.")

    def device_connect(self, zk):
        try:
            conn = zk.connect()
            return conn
        except:
            return False

    def cron_set_status(self):
        attendances_ids = self.env['hr.attendance'].search([])
        for rec in attendances_ids:
            approved_type = self.check_validation_in_time(rec.employee_id, rec.check_in)
            start_date, end_date , shift_id = self._get_start_end_date(rec.employee_id, rec.check_in)
            rec.write({'approved_type' : approved_type, 'night_shift_id' : shift_id.id if shift_id else False})

    def check_validation_in_time(self, employee_id, check_in_date):
        start_date, end_date , shift_id = self._get_start_end_date(employee_id, check_in_date)

        if start_date and end_date and start_date <= check_in_date and end_date >= check_in_date:
            return 'approved'
        return 'to_approved'

    def _get_client_time(self, sync_time):
        """ Need to configure a time in proper manners"""
        from datetime import datetime
        date = sync_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(pytz.utc.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date

    def _get_utc_time(self, sync_time):
        """ Need to configure a time (local to server) in proper manners"""
        from datetime import datetime
        date = sync_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(local.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(pytz.utc),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date

    def _get_start_end_date(self, employee_id, atten_time):
        shift_allocation_id = self.env['shift.allocation'].search([('date_from','<=', atten_time), ('date_to', '>=', atten_time), ('employee_id', '=', employee_id.id)], limit=1)
        if shift_allocation_id and shift_allocation_id.shift_id.calender_id:
            hours_from = self.env['ir.qweb.field.float_time'].value_to_html(shift_allocation_id.shift_id.calender_id.hour_from, {})
            hours_to = self.env['ir.qweb.field.float_time'].value_to_html(shift_allocation_id.shift_id.calender_id.hour_to, {})
            end_hours = datetime.datetime.strptime(hours_to, '%H:%M') + relativedelta(hours=shift_allocation_id.shift_id.attendance_hours)
            end_hours = "{}:{}".format(end_hours.time().hour, end_hours.time().minute)
            # end_hours = hours_to + shift_allocation_id.shift_id.attendance_hours
            if shift_allocation_id.shift_id.shift_type == 'night':
                if atten_time.time().hour < 12:
                    star_atten_time = atten_time + relativedelta(days=-1)
                    start_date = datetime.datetime.strptime(fields.Date.to_string(star_atten_time.date()) + ' ' + hours_from + ':00', '%Y-%m-%d %H:%M:%S')
                    start_date = start_date + relativedelta(hours=-shift_allocation_id.shift_id.attendance_hours)
                    end_date = datetime.datetime.strptime(fields.Date.to_string(atten_time.date()) + ' ' + end_hours + ':00', '%Y-%m-%d %H:%M:%S')
                    end_date = end_date + relativedelta(hours=shift_allocation_id.shift_id.attendance_hours)
                    return self._get_utc_time(start_date), self._get_utc_time(end_date), shift_allocation_id.shift_id
                else:
                    star_atten_time = atten_time 
                    start_date = datetime.datetime.strptime(fields.Date.to_string(star_atten_time.date()) + ' ' + hours_from + ':00', '%Y-%m-%d %H:%M:%S')
                    start_date = start_date + relativedelta(hours=-shift_allocation_id.shift_id.attendance_hours)
                    end_date = datetime.datetime.strptime(fields.Date.to_string(atten_time.date()) + ' ' + end_hours + ':00', '%Y-%m-%d %H:%M:%S')
                    end_date = end_date + relativedelta(days=1, hours=shift_allocation_id.shift_id.attendance_hours)
                    return self._get_utc_time(start_date), self._get_utc_time(end_date), shift_allocation_id.shift_id
            if shift_allocation_id.shift_id.shift_type == 'day':
                start_date = datetime.datetime.strptime(fields.Date.to_string(atten_time.date()) + ' ' + hours_from + ':00', '%Y-%m-%d %H:%M:%S')
                start_date = start_date + relativedelta(hours=-shift_allocation_id.shift_id.attendance_hours)
                hours_end_time = datetime.datetime.strptime(fields.Date.to_string(atten_time.date()) + ' ' + hours_to + ':00', '%Y-%m-%d %H:%M:%S')
                hours_end_time = hours_end_time + relativedelta(hours=shift_allocation_id.shift_id.attendance_hours)
                return self._get_utc_time(start_date), self._get_utc_time(hours_end_time), shift_allocation_id.shift_id
        return False, False, False

    def entry_sign_in_out(self, employee_id, atten_time):
        date_start, end_date, shift_id  = self._get_start_end_date(employee_id, atten_time)
        if self.device_type == 'both':
            domain = [
                ('att_type', '=', self.operation_id.type),
                ('employee_id', '=', employee_id.id),
                ('check_in', '<', atten_time),
                ('in_device_id', '=', self.id),
                ('check_out', '=', False)]
            if shift_id:
                domain = domain + [('night_shift_id', '=', shift_id.id)]
            if date_start and end_date:
                domain = domain + [('check_in', '>', date_start), ('check_in', '<', end_date)]
            att_rec = self.env['hr.attendance'].search(domain, order='check_in desc', limit=1)
            if att_rec:
                att_rec.write({'check_out': fields.Datetime.to_string(atten_time), 'out_device_id': self.id})
                att_rec._compute_worked_hours()
            else:
                validation_type = self.check_validation_in_time(employee_id, atten_time)
                attandance = self.env['hr.attendance'].create({
                    'att_type': self.operation_id.type,
                    'employee_id': employee_id.id,
                    'approved_type': validation_type,
                    'night_shift_id': shift_id.id if shift_id else False,
                    'check_in': atten_time,
                    'in_device_id': self.id
                })
                attandance.night_shift_id = shift_id.id if shift_id else False
        if self.device_type == 'in':
            validation_type = self.check_validation_in_time(employee_id, atten_time)
            attandance = self.env['hr.attendance'].create({
                'att_type': self.operation_id.type,
                'employee_id': employee_id.id,
                'approved_type': validation_type,
                'night_shift_id': shift_id.id if shift_id else False,
                'check_in': fields.Datetime.to_string(atten_time),
                'in_device_id': self.id
            })
            attandance.night_shift_id = shift_id.id if shift_id else False
        if self.device_type == 'out':
            out_domain = [
                ('att_type', '=', self.operation_id.type),
                ('employee_id', '=', employee_id.id),
                ('check_in', '<', atten_time),
                ('night_shift_id', '=', shift_id.id if shift_id else False)
            ]
            if date_start and end_date:
                out_domain = out_domain + [('check_in', '>', date_start), ('check_in', '<', end_date)]
            att_rec = self.env['hr.attendance'].search(out_domain, order='check_in desc', limit=1)
            if att_rec and not att_rec.check_out:
                att_rec.write({'check_out': fields.Datetime.to_string(atten_time), 'out_device_id': self.id})
                att_rec._compute_worked_hours()
        self.write({'employee_ids' : [(4, employee_id.id)]})
        employee_id.device_ids = [(4, self.id)]
        return atten_time

    def connection_get_attendance(self):
        machine_ip = self.device_ip
        zk_port = self.device_port
        timeout = self.set_time_out
        try:
            zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=1)
        except NameError:
            raise UserError(_("Please install it with 'pip3 install pyzk'."))
        conn = self.device_connect(zk)
        if conn:
            try:
                attendance_lines = conn.get_attendance()
            except:
                attendance_lines = []
            last_sync_time = False
            self.status = 'success'
            for line in attendance_lines:
                employee_id = self.env['hr.employee'].search([('device_id', '=', line.user_id)])
                atten_time = line.timestamp
                atten_time = datetime.datetime.strptime(atten_time.strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')
                local_tz = pytz.timezone(self.env.user.partner_id.tz or 'GMT')
                local_dt = local_tz.localize(atten_time, is_dst=None)
                utc_dt = local_dt.astimezone(pytz.utc)
                utc_dt = utc_dt.strftime("%Y-%m-%d %H:%M:%S")
                atten_time = datetime.datetime.strptime(utc_dt, "%Y-%m-%d %H:%M:%S")
                if employee_id:
                    if self._get_client_time(self.last_sync_time) < self._get_client_time(atten_time):
                        last_sync_time = self.entry_sign_in_out(employee_id, atten_time)
                else:
                    _logger.error("Employee not found with ID : "+ str(line.user_id))
            if last_sync_time:
                self.write({'last_sync_time': last_sync_time})
        else:
            self.status = 'failed'
            _logger.error("Unable to connect, please check the parameters and network connections.")


    def get_attenance(self):
        for rec in self:
            rec.connection_get_attendance()
        return {'effect': {
            'fadeout': 'slow',
            'message': "Attendance Successfully Sync",
            'img_url': '/web/static/src/img/smile.svg',
            'type': 'rainbow_man'}}

    def cron_get_machine_data(self):
        for rec in self.search([('device_active', '=', True)]):
            rec.connection_get_attendance()

    def set_time_device(self):
        machine_ip = self.device_ip
        zk_port = self.device_port
        timeout = self.set_time_out
        try:
            zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=1)
        except NameError:
            raise UserError(_("Please install it with 'pip3 install pyzk'."))
        conn = self.device_connect(zk)
        conn.set_time(self._get_client_time(self.device_set_time))
        return True

    def teat_connection(self):
        machine_ip = self.device_ip
        zk_port = self.device_port
        timeout = self.set_time_out
        zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=1)
        try:
            conn = self.device_connect(zk)
            if conn:
                users = conn.get_users()
                for user in users:
                    _logger.error("User found in device with ID : "+ str(user.user_id))
                    employee_id = self.env['hr.employee'].search([('device_id', '=', user.user_id)], limit=1)
                    if employee_id:
                        _logger.error("Found employee in device: "+ str(user.user_id))
                        self.employee_ids = [(4, employee_id.id)]
                        employee_id.device_ids = [(4, self.id)]
            self.status = 'success' if conn else 'failed'
        except:
            return False

    def clear_attendance(self):
        machine_ip = self.device_ip
        zk_port = self.device_port
        timeout = self.set_time_out
        zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=1)
        try:
            conn = self.device_connect(zk)
            conn.clear_attendance()
        except:
            return False