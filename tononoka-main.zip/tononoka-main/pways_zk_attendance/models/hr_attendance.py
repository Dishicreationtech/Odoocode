# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
import datetime
from datetime import datetime, timedelta
import pytz
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT


class HrAttendance(models.Model):
    _inherit = 'hr.attendance'

    att_type = fields.Selection([('campus', 'Main Gate'), ('factory', 'Factory')], string='Type', required=True, default='campus')
    approved_type = fields.Selection([('approved', 'Approved'), ('to_approved', 'To Be Approved')], string='Approved Type')
    in_device_id = fields.Many2one("device.line", string="IN Device")
    out_device_id = fields.Many2one("device.line", string="Out Device")
    type_of_period = fields.Selection([('on_time', 'On Time'), ('erly', 'Early'), ('late', 'Late')], string='Period', compute="_compute_period_type", store=True)
    approved_id = fields.Many2one('res.users', 'Approved By', readonly=True)
    #valid_until_date = fields.Datetime(string="Valid Until", compute="_compute_until_date")

    # def _compute_until_date(self):
    #     for rec in self:
    #         shift_allocation_id = self.env['shift.allocation'].search([('date_from','<=', rec.check_in), ('date_to', '>=', rec.check_in)], limit=1)
    #         if shift_allocation_id and shift_allocation_id.shift_id.calendar_id:
    #             end_hours = shift_allocation_id.shift_id.calendar_id.hour_to + shift_allocation_id.shift_id.attendance_hours




    @api.onchange('approved_type')
    def _onchange_approved_type(self):
        for record in self:
            record.approved_id = self.env.user.id

    def apply_time_duration(self):
        attendance_ids = self.env['hr.attendance'].search([('worked_hours', '=', 0.0)])
        for attendance in attendance_ids.filtered(lambda x: x.check_in and x.check_out):
            attendance._compute_worked_hours()
            

    @api.constrains('check_in', 'check_out', 'employee_id')
    def _check_validity(self):
        """ Verifies the validity of the attendance record compared to the others from the same employee.
            For the same employee we must have :
                * maximum 1 "open" attendance record (without check_out)
                * no overlapping time slices with previous employee records
        """
        return True

    def _get_client_time(self, sync_time):
        """ Need to configure a time in proper manners"""
        from datetime import datetime
        date = sync_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(pytz.utc.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date


    @api.depends('employee_id', 'check_in')
    def _compute_period_type(self):
        for record in self:
            date_start = record.check_in.replace(hour=0, minute=0, second=0)
            date_end = record.check_in.replace(hour=23, minute=59, second=0)
            attendance_ids = self.env['hr.attendance'].search([('check_in', '>', date_start), ('check_in', '<=', date_end), ('employee_id', '=', record.employee_id.id)])
            if attendance_ids:
                min_date = max(attendance_ids.mapped('check_in'))
                get_min_date = self._get_client_time(min_date)
                if record.employee_id and record.employee_id and record.employee_id.resource_calendar_id and record.employee_id.resource_calendar_id.hour_from:
                    #week_day = record.employee_id.resource_calendar_id.attendance_ids.filtered(lambda x: x.dayofweek == str(week_day))
                    hour_from = record.employee_id.resource_calendar_id.hour_from 
                    hours_minit = float("{:d}.{:02d}".format(get_min_date.hour, get_min_date.minute))
                    given_time = datetime.strptime(str(hour_from), '%H.%M')
                    final_from_time = given_time + timedelta(minutes=-10)
                    hours_from = float("{:d}.{:02d}".format(final_from_time.hour, final_from_time.minute))
                    given_to_time = datetime.strptime(str(hour_from), '%H.%M')
                    final_to_time = given_to_time + timedelta(minutes=10)
                    hours_to = float("{:d}.{:02d}".format(final_to_time.hour, final_to_time.minute))
                    if (hours_minit < hours_from):
                        record.type_of_period = 'erly'
                        attendance_ids.write({'type_of_period': 'erly'})
                    if (hours_minit > hours_to):
                        record.type_of_period = 'late'
                        attendance_ids.write({'type_of_period': 'late'})
                    if (hours_minit > hours_from) and (hours_minit < hours_to):
                        record.type_of_period = 'on_time'
                        attendance_ids.write({'type_of_period': 'on_time'})

