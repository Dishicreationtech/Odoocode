# -*- coding: utf-8 -*-

import time
from odoo import api, models, _
from odoo.exceptions import UserError


class ReportAttendance(models.AbstractModel):
    _name = 'report.hr_attendance_report.report_attendance_ledger'

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'docids' : docids,
            'header_lines': data.get('header'),
            'employee_ids' : data.get('employee_ids')
        }