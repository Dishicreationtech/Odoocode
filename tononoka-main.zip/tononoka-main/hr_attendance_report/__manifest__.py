# -*- coding: utf-8 -*-
{
    'name': "HR Attendance Report",
    'summary': "HR Attendance Report",
    'category': 'HR',
    'version': '14.0.0',
    'depends': ['hr_attendance', 'hr_holidays'],
    'data': [
        'views/hr_attendance_report_view.xml',
        'report/report_action.xml',
    ],
    'qweb': ['static/src/xml/hr_attendance_dashboard.xml'],
    'installable': True,
    'application': True
}
