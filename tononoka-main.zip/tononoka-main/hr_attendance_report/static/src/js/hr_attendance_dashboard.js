odoo.define('hr_attendance_report.Dashboard', function (require) {
"use strict";

var AbstractAction = require('web.AbstractAction');
var ajax = require('web.ajax');
var core = require('web.core');
var rpc = require('web.rpc');
var session = require('web.session');
var web_client = require('web.web_client');
var _t = core._t;
var QWeb = core.qweb;

var HrDashboard = AbstractAction.extend({
    template: 'HrDashboard',
    events: {
        'keyup .searchInput': '_onKeypress',
        'change #report_type': 'onChangeReportType',
        'click  #pdf_button': 'download_pdf',
    },

    init: function(parent, options) {
        this._super(parent, options);
        this.attendance_ids = [];
        this.department_id = options.context.department_id;
        this.report_type = 'month';
    },
    willStart: function() {
        var self = this;
        return $.when(ajax.loadLibs(this), this._super()).then(function() {
            return self.fetch_data();
        });
    },
    fetch_data: function () {
        var self = this;
        var def1 =  this._rpc({
            model: 'hr.attendance',
            method: 'get_attenance_data',
            args: ['month', this.department_id],
        }).then(function(result) {
            self.attendance_ids = result
        });
        return $.when(def1);
    },
    start: function() {
        var self = this;
        return this._super().then(function() {
            self.render_dashboards(self.attendance_ids, self.attendance_ids.employee_ids);
        });
    },
    _onKeypress: function (ev) {
        var search_text = (this.$('.searchInput').val()).toLowerCase();
        var res = this.attendance_ids;
        var employee_ids = []
        _.each(this.attendance_ids.employee_ids, function (emp) {
            if ((emp.name.toLowerCase()).indexOf(search_text) != -1) {
                employee_ids.push(emp)
            }
        });
        this.render_dashboards(res, employee_ids);
    },

    download_pdf: function(event) {
        var self = this;
        var report_type = $('#report_type').val();
        return rpc.query({
            args: [report_type, this.department_id],
            model: 'hr.attendance',
            method: 'get_attenance_data',
        }).then(function(result) {
            var action = {
                'type': 'ir.actions.report',
                'report_type': 'qweb-pdf',
                'report_name': 'hr_attendance_report.report_attendance_ledger',
                'report_file': 'hr_attendance_report.report_attendance_ledger',
                'data': result,
                'context': {
                    'active_model': 'hr.attendance',
                    'landscape': 1,
                    'data': result
                },
                'display_name': 'Attendance Report',
            };
            return web_client.do_action(action);
        });
    },

    onChangeReportType: function(events) {
        var option = $(events.target).val();
        this.report_type = option
        var self = this;
        var def1 =  this._rpc({
            model: 'hr.attendance',
            method: 'get_attenance_data',
            args: [option, this.department_id],
        }).then(function(result) {
            self.attendance_ids = result;
            self.render_dashboards(result, result.employee_ids);
        });
        return $.when(def1);
    },
    render_dashboards: function (res, employee_ids) {
        this.$('.o_employee_dashboard').html(QWeb.render('EmpAttendance', {widget: res, 'employee_ids': employee_ids}));
    }
});

core.action_registry.add('hr_attendance_dashboard', HrDashboard);

return HrDashboard;

});
