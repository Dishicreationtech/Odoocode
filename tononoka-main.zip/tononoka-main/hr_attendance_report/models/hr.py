# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from calendar import monthrange
from datetime import date, timedelta
import datetime, calendar
import pytz

class HrLeaveType(models.Model):
    _inherit = 'hr.leave.type'

    leave_code = fields.Char(string='Leave Code', default='AA', size=2)
    color = fields.Integer(string='Color Index')

class HrAttendance(models.Model):
    _inherit = 'hr.attendance'

    date_check_in = fields.Date(compute='_day_calculation', store=True)

    def _get_server_datetime(self, check_in):
        if not check_in:
            return ''
        c_date = fields.Datetime.to_string(pytz.timezone(self.env.context.get('tz') or 'UTC').localize(fields.Datetime.from_string(check_in.strftime('%Y-%m-%d %H:%M:%S')), is_dst=None).astimezone(pytz.utc))
        return datetime.datetime.strptime(c_date, '%Y-%m-%d %H:%M:%S')

    @api.depends('check_in')
    def _day_calculation(self):
        for record in self:
            record.date_check_in = self._get_server_datetime(record.check_in)

    @api.model
    def get_attenance_data(self, report_type, department_id=None):
        data = []
        domain = []
        if department_id:
            domain.append(('department_id', '=', department_id))
        emp_ids = self.env['hr.employee'].search(domain, limit=10)
        final_data = {}
        report_type = report_type or 'month'
        today = date.today()
        dates = []

        if report_type == 'month':
            month = today.month
            year = today.year
            no_of_days = monthrange(year, month)[1]
            first_date = today.replace(day=1)
            last_date = first_date + datetime.timedelta(no_of_days-1)
            days = [day for day in range(1, no_of_days+1)]
            full_dates = [(first_date + timedelta(days=i)) for i in range(no_of_days)]
            dates = [str((first_date + timedelta(days=i)).day) +'-'+ (first_date + timedelta(days=i)).strftime("%a") for i in range(no_of_days)]
            final_data = self._get_attendance_data(first_date, last_date, days, full_dates)

        if report_type == 'week':
            days = [(today + datetime.timedelta(days=i)).day for i in range(0 - today.weekday(), 7 - today.weekday())]
            dates = [str((today + datetime.timedelta(days=i)).day) +'-'+ (today + datetime.timedelta(days=i)).strftime("%a") for i in range(0 - today.weekday(), 7 - today.weekday())]
            start = today - timedelta(days=today.weekday())
            end = start + timedelta(days=6)
            full_dates = [(today + datetime.timedelta(days=i)) for i in range(0 - today.weekday(), 7 - today.weekday())]
            final_data = self._get_attendance_data(start, end, days, full_dates)

        if report_type == '15_days':
            start_date = today + timedelta(days=-14)
            delta = today - start_date
            days = [(start_date + timedelta(days=i)).day for i in range(delta.days + 1)]
            full_dates = [(start_date + timedelta(days=i)) for i in range(delta.days + 1)]
            dates = [str((start_date + timedelta(days=i)).day) +'-'+ (start_date + timedelta(days=i)).strftime("%a") for i in range(delta.days + 1)]
            final_data = self._get_attendance_data(start_date, today, days, full_dates)

        for emp in emp_ids:
            data.append({
                'id': emp.id,
                'name': emp.name,
                'hours': final_data[emp.id],
                'position': emp.job_id.name,
            })
        return {'employee_ids': data, 'header': dates}


    def _get_attendance_data(self, start_at, stop_at, dates, full_dates):
        emp_ids = self.env['hr.employee'].search([])
        leave_ids = self.env['hr.leave'].search([('employee_id', 'in', emp_ids.ids)])
        query = """SELECT date_check_in,
                sum(worked_hours) as total_hours,
                emp.id as emp_id
                from hr_employee emp
                LEFT JOIN hr_attendance at on (at.employee_id=emp.id)
                where date_check_in >= %(start_at)s and date_check_in <= %(stop_at)s
                group by date_check_in,emp.id
                order by emp.id
                LIMIT 10
            """
        self.env.cr.execute(query , {'start_at': start_at, 'stop_at': stop_at})
        result = self.env.cr.dictfetchall()

        #{'2132': {'21': 1.5}}
        att_by_emp = {}
        for line in result:
            if line['emp_id'] in att_by_emp:
                att_by_emp[line['emp_id']][line['date_check_in'].day] = line['total_hours']
            else:
                att_by_emp[line['emp_id']] = {line['date_check_in'].day: line['total_hours']}
        final_value = {}
        for emp in emp_ids:
            emp_data = []
            for c_date in full_dates:
                day = c_date.day
                if (emp.id in att_by_emp) and (day in att_by_emp[emp.id]):
                    float_hours = att_by_emp[emp.id][day]
                    total_hours = 0
                    if float_hours > 0:
                        total_hours = self.env['ir.qweb.field.float_time'].value_to_html(float_hours, {})
                    emp_data.append({'att': 'P', 'value': total_hours})
                else:
                    leave_id = leave_ids.filtered(lambda x: (x.employee_id.id == emp.id) and (x.date_from.date() <= c_date) and (x.date_to.date() >= c_date))
                    leave_code = leave_id and leave_id[0].holiday_status_id.leave_code or 'A'
                    color_class = leave_id and 'leave_'+str(leave_id[0].holiday_status_id.color) or 'leave_0'
                    emp_data.append({'att': leave_code, 'value': 0, 'class': color_class})
            final_value[emp.id] = emp_data
        return final_value
