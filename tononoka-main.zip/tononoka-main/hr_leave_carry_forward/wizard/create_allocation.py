from odoo import models, fields, api, _
from datetime import timedelta, datetime, time
from odoo.exceptions import ValidationError

class AllocationWizard(models.TransientModel):
    _name = "carry.forward.wizard"
    _description = 'Carry Forward'

    leave_type = fields.Many2one('hr.leave.type')
    employee_ids = fields.Many2many('hr.employee')
    date_from = fields.Datetime() 
    date_to = fields.Datetime()

    @api.onchange('leave_type')
    def _onchange_leave_type(self):
        if self.leave_type:
            if not self.leave_type.validity_stop:
                raise ValidationError("Please set dates in leave type %s" % self.leave_type.name)
            self.date_from = self.leave_type.validity_stop
            self.date_to = self.leave_type.validity_stop + timedelta(days=365)
   
    def create_allocation(self):
        for emp in self.employee_ids:
            name = ''
            if self.leave_type and self.date_from and self.date_to:
                name = ('%s-%s-to-%s') % (self.leave_type.name, self.date_from, self.date_to)
            name = ('%s-%s-%s') % (emp.name, name, 'Carry-Forward')
            number_of_leave = 0.0
            number_of_allocation = 0.0
            allocation_ids = self.env['hr.leave.allocation'].search([('holiday_status_id', '=', self.leave_type.id),('employee_id', '=', emp.id),('state','=', 'validate')])
            if not allocation_ids:
                raise ValidationError(_('Allocation is not found for %s leave type or employee %s') %(self.leave_type.name,emp.name))
            number_of_allocation = sum(allocation_ids.mapped('number_of_days_display')) 
            leave_ids = self.env['hr.leave'].search([('holiday_status_id', '=', self.leave_type.id),('employee_id', '=', emp.id),('state','=', 'validate')])
            if leave_ids:
                number_of_leave = sum(leave_ids.mapped('number_of_days'))
            diff_days = abs(number_of_allocation - number_of_leave)
            if diff_days > 0:
                vals = {
                    'holiday_status_id': self.leave_type.id,
                    'employee_id': emp.id,
                    'name': name,
                    'number_of_days': diff_days,
                    'carry_forward_type': 'carry_forward',
                }
                self.env['hr.leave.allocation'].create(vals)


