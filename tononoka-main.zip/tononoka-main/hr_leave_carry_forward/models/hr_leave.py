from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    allow_carry_forward = fields.Boolean()

class HrLeaveEmployee(models.Model):
    _inherit = "hr.leave.type"

    allow_carry_forward = fields.Boolean()

class HrLeaveAllcoation(models.Model):
    _inherit = "hr.leave.allocation"

    carry_forward_type = fields.Selection([('carry_forward','Carry Forward'), ('normal','Normal')], default="normal")   
# block code as suggested by rawish on 2 dec
    # @api.constrains('employee_id','date_from', 'date_to', 'holiday_status_id')
    # def check_validation(self):
    #     for rec in self.filtered(lambda x: x.employee_id and x.employee_id.date_joining):
    #         if (rec.employee_id.date_joining > rec.date_from):       
    #             raise ValidationError(_('Start allocation date is allowed only after joining date "%s"',rec.employee_id.date_joining))
    #         if (rec.employee_id.date_joining > rec.date_to):
    #             raise ValidationError(_('End allocation date is allowed only after joining date "%s"',rec.employee_id.date_joining))
    #         if not (rec.date_from >= rec.holiday_status_id.validity_start and rec.date_to <= rec.holiday_status_id.validity_stop): 
    #             raise ValidationError(_('Wrong leave type is selected'))


