# -*- coding: utf-8 -*-
{
    'name': "HR Leave Carry Forward",
    'summary': "HR Leave Carry Forward",
    'category': 'HR',
    'version': '14.0.0',
    'depends': ['hr_holidays', 'hr_employee', 'hr_shift_allocation'],
    'data': [
            'security/ir.model.access.csv',
            'views/hr_employee_view.xml',
            'wizard/create_allocation.xml'],
    'installable': True,
    'application': True
}
