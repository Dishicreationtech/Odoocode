# -*- coding: utf-8 -*-
{
    'name' : 'Employee Shift Allocation Report',
    'version' : '14.0',
    'category': 'HR',
    'depends' : ['hr_employee', 'pways_zk_attendance'],
    'data': [
        'security/ir.model.access.csv',
        'security/hr_security.xml',
        'wizard/employee_without_shift.xml',
        'wizard/employee_attendance.xml',
        'wizard/employee_attendance_comer.xml',
        'wizard/factory_attendance_wizard.xml',
        'report/report_action.xml',
        'report/employee_without_shift_template.xml',
        'report/employee_attendance_template.xml',
        'report/employee_attendance_comer_template.xml',
        'report/factory_attendance_report.xml',
    ],
    'demo': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
