# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import date, datetime, time, timedelta

from dateutil.relativedelta import relativedelta
import pytz
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import ValidationError
import logging
_logger = logging.getLogger(__name__)
class EmployeeAttendanceComer(models.TransientModel):
    _name = "employee.attendance.comer"
    _description = 'Attendance Comer'

    from_date = fields.Date('From Date', default=lambda self: fields.Date.to_string(date.today()), required=True)
    type = fields.Selection([
        ('all', 'All'),
        ('early_comer', 'Early Comer'),
        ('late_comer', 'Late Comer'),
        ('on_time_comer', 'On Time Comer'),
        ('early_goer', 'Early Goer'),
        ('late_goer', 'Late Goer'),
        ('on_time_goer', 'On Time Goer')
        ], string='Type')
    shift_id = fields.Many2one('hr.shift', required=True, string='Shift')
    department_id = fields.Many2one('hr.department', string='Department')

    def _get_client_time(self, sync_time):
        from datetime import datetime
        date = sync_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(pytz.utc.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date

    def _get_type(self):
        return {
            'all': 'All',
            'early_comer' : 'Early Comer',
            'late_comer' : 'Late Comer',
            'on_time_comer' : 'On Time Comer',
            'early_goer' : 'Early Goer',
            'late_goer' : 'Late Goer',
            'on_time_goer' : 'On Time Goer'
        }

    def _prepaire_in_lines(self, attendance_id):
        in_device = attendance_id.in_device_id.operation_id.name if attendance_id.in_device_id and attendance_id.in_device_id.operation_id.name else False
        return {
          'name' : attendance_id.employee_id.name,
          'payroll_number' : attendance_id.employee_id.payroll_number if attendance_id.employee_id.payroll_number else 0.0,
          'category' : attendance_id.employee_id.category_id and attendance_id.employee_id.category_id.name and attendance_id.employee_id.category_id.name[:2] or '-',
          'department' : attendance_id.department_id.name if attendance_id.department_id else ' ',
          'check_in' :  self._get_client_time(attendance_id.check_in).strftime('%H:%M:%S'),
          'in_device' : in_device,
        }

    def _prepaire_out_lines(self, attendance_id):
        out_device = attendance_id.out_device_id.operation_id.name if attendance_id.out_device_id and attendance_id.out_device_id.operation_id.name else False
        return {
          'name' : attendance_id.employee_id.name,
          'category' : attendance_id.employee_id.category_id and attendance_id.employee_id.category_id.name and attendance_id.employee_id.category_id.name[:2] or '-',
          'payroll_number' : attendance_id.employee_id.payroll_number if attendance_id.employee_id.payroll_number else 0.0,
          'department' : attendance_id.department_id.name if attendance_id.department_id else ' ',
          'check_out' :  self._get_client_time(attendance_id.check_out).strftime('%H:%M:%S'),
          'out_device' : out_device,
        }

    def _prepaire_in_out_lines(self, employee_id, check_in, check_out, in_status, out_status, in_device, out_device):
        return {
            'name' : employee_id.name,
            'category' : employee_id.category_id and employee_id.category_id.name and employee_id.category_id.name[:2] or '-',
            'payroll_number' : employee_id.payroll_number if employee_id.payroll_number else 0.0,
            'department' : employee_id.department_id.name if employee_id.department_id else ' ',
            'check_in' :  check_in,
            'check_out' :  check_out,
            'in_device' : in_device,
            'out_device' : out_device,
            'in_status': in_status,
            'out_status': out_status,
        }

    def get_type(self):
        return {
            'office' : 'campus',
            'Factory' : 'factory'
        }

    def hour_from_time(self, hours):
        minutes = self.shift_id.on_time
        given_time = datetime.strptime(str(hours), '%H.%M')
        final_from_time = given_time + timedelta(minutes=-minutes)
        hours_from = float("{:d}.{:02d}".format(final_from_time.hour, final_from_time.minute))
        return hours_from

    def hour_to_time(self, hours):
        minutes = self.shift_id.on_time
        given_time = datetime.strptime(str(hours), '%H.%M')
        final_to_time = given_time + timedelta(minutes=minutes)
        hours_to = float("{:d}.{:02d}".format(final_to_time.hour, final_to_time.minute))
        return hours_to

    def _get_server_datetime(self, att_time):
        return fields.Datetime.to_string(pytz.timezone(self.env.context['tz']).localize(fields.Datetime.from_string(att_time), is_dst=None).astimezone(pytz.utc))

    def get_all_domain(self):
        user_tz = self.env.user.tz or pytz.utc
        local = pytz.timezone(user_tz)
        domain = []
        att_type = self.get_type()
        att_type = att_type.get(self.shift_id.sub_category_id.category_type)
        select_datetime = datetime(self.from_date.year, self.from_date.month, self.from_date.day)
        if self.shift_id.shift_type == "day":
            date_start = select_datetime.replace(hour=0, minute=0, second=0)
            date_end = select_datetime.replace(hour=23, minute=59, second=0)
            domain = [('check_in', '>', date_start), ('check_in', '<=', date_end), ('att_type', '=', att_type), ('night_shift_id', '=', self.shift_id.id)]
        if self.shift_id.shift_type == "night":
            hours_from = self.env['ir.qweb.field.float_time'].value_to_html(self.shift_id.calender_id.hour_from, {})
            hours_to = self.env['ir.qweb.field.float_time'].value_to_html(self.shift_id.calender_id.hour_to, {})
            date_from = self._get_server_datetime(datetime.strptime(fields.Date.to_string(self.from_date) + ' ' + hours_from + ':00', DEFAULT_SERVER_DATETIME_FORMAT) + relativedelta(hours=-1))
            date_to = self._get_server_datetime(datetime.strptime(fields.Date.to_string(self.from_date) + ' ' + hours_to + ':00', DEFAULT_SERVER_DATETIME_FORMAT) + relativedelta(days=1, hours=1))
            domain = [('check_in', '>', date_from), ('check_in', '<=', date_to), ('att_type', '=', att_type), ('night_shift_id', '=', self.shift_id.id)]
        return domain

    def get_domain(self):
        user_tz = self.env.user.tz or pytz.utc
        local = pytz.timezone(user_tz)
        domain = []
        att_type = self.get_type()
        att_type = att_type.get(self.shift_id.sub_category_id.category_type)
        select_datetime = datetime(self.from_date.year, self.from_date.month, self.from_date.day)
        if self.shift_id.shift_type == "day":
            date_start = select_datetime.replace(hour=0, minute=0, second=0)
            date_end = select_datetime.replace(hour=23, minute=59, second=0)
            if self.type in ['early_comer', 'late_comer', 'on_time_comer']:
                domain = [('check_in', '>', date_start), ('check_in', '<=', date_end), ('att_type', '=', att_type), ('night_shift_id', '=', self.shift_id.id)]
            else:
                domain = [('check_in', '>', date_start), ('check_in', '<=', date_end), ('att_type', '=', att_type), ('night_shift_id', '=', self.shift_id.id)]
        if self.shift_id.shift_type == "night":
            hours_from = self.env['ir.qweb.field.float_time'].value_to_html(self.shift_id.calender_id.hour_from, {})
            hours_to = self.env['ir.qweb.field.float_time'].value_to_html(self.shift_id.calender_id.hour_to, {})
            date_from = self._get_server_datetime(datetime.strptime(fields.Date.to_string(self.from_date) + ' ' + hours_from + ':00', DEFAULT_SERVER_DATETIME_FORMAT) + relativedelta(hours=-1))
            date_to = self._get_server_datetime(datetime.strptime(fields.Date.to_string(self.from_date) + ' ' + hours_to + ':00', DEFAULT_SERVER_DATETIME_FORMAT) + relativedelta(days=1, hours=1))
            if self.type in ['early_comer', 'late_comer', 'on_time_comer']:
                domain = [('check_in', '>', date_from), ('check_in', '<=', date_to), ('att_type', '=', att_type), ('night_shift_id', '=', self.shift_id.id)]
            else:
                domain = [('check_in', '>', date_from), ('check_in', '<=', date_to), ('att_type', '=', att_type), ('night_shift_id', '=', self.shift_id.id)]
        return domain

    def print_report(self):
        lines = []
        data = {}
        type = self._get_type().get(self.type)
        domain = self.get_domain() if self.type != 'all' else self.get_all_domain()
        domain.append(('approved_type', '=', 'approved'))
        attendance_ids = self.env['hr.attendance'].search(domain)
        employee_ids = attendance_ids.mapped('employee_id')
        if not employee_ids:
            raise ValidationError(_('Employee exceptions not found'))
        if self.department_id:
            employee_ids = employee_ids.filtered(lambda x: x.department_id.id == self.department_id.id)
        for employee in employee_ids:
            attendances = attendance_ids.filtered(lambda x: x.employee_id == employee)

            if attendances and self.type == 'all':
                min_date = min(attendances.mapped('check_in'))
                max_date = max(attendances.mapped('check_out'))
                if min_date and max_date:
                    get_min_date = self._get_client_time(min_date)
                    min_hours_minit = float("{:d}.{:02d}".format(get_min_date.hour, get_min_date.minute))
                    min_shift_hour_from = self.shift_id.calender_id.hour_from
                    min_hours_from = self.hour_from_time(min_shift_hour_from)
                    min_hours_to = self.hour_to_time(min_shift_hour_from)
                    attendance_id = self.env['hr.attendance'].search([('employee_id', '=', employee.id), ('check_in', '=', min_date)], limit=1)
                    in_status = ''
                    out_status = ''
                    in_device = attendance_id.in_device_id.operation_id.name if attendance_id.in_device_id and attendance_id.in_device_id.operation_id.name else False
                    if (min_hours_minit < min_hours_from):
                        in_status = 'Early Comer'
                    if (min_hours_minit > min_hours_to):
                        in_status = 'Late Comer'
                    if (min_hours_minit >= min_hours_from) and (min_hours_minit <= min_hours_to):
                        in_status = 'On Time Comer'

                    get_max_date = self._get_client_time(max_date)
                    max_hours_minit = float("{:d}.{:02d}".format(get_max_date.hour, get_max_date.minute))
                    max_shift_hour_from = self.shift_id.calender_id.hour_to
                    max_hours_from = self.hour_from_time(max_shift_hour_from)
                    max_hours_to = self.hour_to_time(max_shift_hour_from)
                    attendance_id = self.env['hr.attendance'].search([('employee_id', '=', employee.id), ('check_out', '=', max_date)], limit=1)
                    out_device = attendance_id.out_device_id.operation_id.name if attendance_id.out_device_id and attendance_id.out_device_id.operation_id.name else False
                    if (max_hours_minit < max_hours_from):
                        out_status = 'Early Goer'
                    if (max_hours_minit > max_hours_to):
                        out_status = 'Late Goer'
                    if (max_hours_minit >= max_hours_from) and (max_hours_minit <= max_hours_to):
                        out_status = 'On Time Goer'
                    lines.append(self._prepaire_in_out_lines(employee, get_min_date, get_max_date, in_status, out_status, in_device, out_device))

            if attendances and self.type in ['early_comer', 'late_comer', 'on_time_comer']:
                min_date = min(attendances.mapped('check_in'))
                if min_date:
                    get_min_date = self._get_client_time(min_date)
                    hours_minit = float("{:d}.{:02d}".format(get_min_date.hour, get_min_date.minute))
                    shift_hour_from = self.shift_id.calender_id.hour_from
                    hours_from = self.hour_from_time(shift_hour_from)
                    hours_to = self.hour_to_time(shift_hour_from)
                    attendance_id = self.env['hr.attendance'].search([('employee_id', '=', employee.id), ('check_in', '=', min_date)], limit=1)
                    if (hours_minit < hours_from) and self.type == 'early_comer':
                        lines.append(self._prepaire_in_lines(attendance_id))
                    if (hours_minit > hours_to) and self.type == 'late_comer':
                        lines.append(self._prepaire_in_lines(attendance_id))
                    if (hours_minit >= hours_from) and (hours_minit <= hours_to) and self.type == 'on_time_comer':
                        lines.append(self._prepaire_in_lines(attendance_id))
            if attendances and self.type in ['early_goer', 'late_goer', 'on_time_goer']:
                max_date = max(attendances.mapped('check_out'))
                if max_date:
                    get_max_date = self._get_client_time(max_date)
                    hours_minit = float("{:d}.{:02d}".format(get_max_date.hour, get_max_date.minute))
                    shift_hour_from = self.shift_id.calender_id.hour_to
                    hours_from = self.hour_from_time(shift_hour_from)
                    hours_to = self.hour_to_time(shift_hour_from)
                    attendance_id = self.env['hr.attendance'].search([('employee_id', '=', employee.id), ('check_out', '=', max_date)], limit=1)
                    if (hours_minit < hours_from) and self.type == 'early_goer':
                        lines.append(self._prepaire_out_lines(attendance_id))
                    if (hours_minit > hours_to) and self.type == 'late_goer':
                        lines.append(self._prepaire_out_lines(attendance_id))
                    if (hours_minit >= hours_from) and (hours_minit <= hours_to) and self.type == 'on_time_goer':
                        lines.append(self._prepaire_out_lines(attendance_id))
        data['from_date'] = self.from_date
        data['shift_name'] = self.shift_id.name
        data['department'] = self.department_id.name
        data['type'] = type
        data['lines'] = lines
        return self.env.ref('hr_report_extended.action_employee_attendance_comer_report').report_action(self, data=data)
