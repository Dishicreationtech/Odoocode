# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import date, datetime, time
from dateutil.relativedelta import relativedelta
from pytz import timezone
from odoo.exceptions import UserError

class EmployeeAttendanceWizard(models.TransientModel):
    _name = "employee.attendance.wizard"
    _description = 'Attendance wizard'

    from_date = fields.Date('From Date', default=lambda self: fields.Date.to_string(date.today().replace(day=1)),required=True)
    to_date = fields.Date("To Date", default=lambda self: fields.Date.to_string((datetime.now() + relativedelta(months=+1, day=1, days=-1)).date()), required=True)
    approved_type = fields.Selection([('both', 'All'), ('approved', 'Approved'), ('to_approved', 'To Be Approved')], string='Approved Type', default="both")
    shift_id = fields.Many2one('hr.shift', required=True)
    department_id = fields.Many2one('hr.department', string='Department')

    def get_sql_data(self):
        sql_query = """ SELECT id FROM hr_attendance where check_in >= '%s' and check_out <= '%s'  and night_shift_id = '%d'""" % (self.from_date, self.to_date, self.shift_id.id)
        if self.approved_type == 'approved':
            domain = [('approved_type', '=', 'approved')]
            sql_query += """ AND approved_type = 'approved' """
        if self.approved_type == 'to_approved':
            sql_query += """ AND approved_type = 'to_approved' """
        if self.department_id and self.department_id.id:
            sql_query += """ AND department_id = %d """ % (self.department_id.id)
        self.env.cr.execute(sql_query)
        data = self.env.cr.fetchall()
        attendance_ids = [item for id in data for item in id]
        return attendance_ids

    def print_report(self):
        data = {}
        attendance_ids = self.get_sql_data()
        if not attendance_ids:
            raise UserError(_('Record not found'))
        data['attendance_ids'] = attendance_ids
        data['from_date'] = self.from_date
        data['to_date'] = self.to_date
        data['approved_type'] = self.approved_type
        return self.env.ref('hr_report_extended.action_attendance_type_report').report_action(self, data=data)