# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date, timedelta
from odoo.tools import date_utils
import time
import json
from dateutil.relativedelta import relativedelta
import datetime
import io
from odoo import fields, models, _
from odoo.exceptions import ValidationError
from odoo.tools import date_utils

import calendar
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import pytz
from itertools import groupby

class FactoryAttendanceReport(models.TransientModel):
    _name = 'factory.attendance.wizard'
    _description = 'FActory Wizard'


    date = fields.Date(string="Date", required=True)
    shift_id = fields.Many2one('hr.shift', required=True)
    department_id = fields.Many2one('hr.department', string='Department')
    category_id = fields.Many2one('employee.category', string='Category')

    def action_print_report(self):
        data = {
            'date': self.date,
            'shift_id': self.shift_id.id,
            'department_id': self.department_id.id,
            'category_id': self.category_id.id,
        }
        return self.env.ref('hr_report_extended.factory_attendance_report').report_action(self, data=data)

class FactoryAttendanceReport(models.AbstractModel):
    _name = 'report.hr_report_extended.factory_attendance_report_template'
    _description = 'Report Hr'

    def _get_server_datetime(self, att_time):
        return fields.Datetime.to_string(pytz.timezone(self.env.context['tz']).localize(fields.Datetime.from_string(att_time), is_dst=None).astimezone(pytz.utc))

    def _get_client_time(self, att_time):
        if not att_time:
            return ''
        """ Need to configure a time in proper manners"""
        from datetime import datetime
        date = att_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(pytz.utc.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date.strftime("%H:%M")

    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        date = data['date']
        shift_id = self.env['hr.shift'].browse(data['shift_id'])
        department_id = self.env['hr.department'].browse(data['department_id'])
        att_data = []
        allocation_ids = self.env['shift.allocation'].search([('date_from','<=', date), ('date_to', '>=', date), ('shift_id', '=', shift_id.id)])
        sr_no = 1
        category_id = self.env['employee.category'].browse(data['category_id'])
        employee_ids = allocation_ids.mapped('employee_id').sorted(key=lambda l: (l.name))
        if department_id:
            employee_ids = employee_ids.filtered(lambda x: x.department_id.id == department_id.id)
        if category_id:
            print ("category_id",category_id)
            employee_ids = employee_ids.filtered(lambda x: x.category_id.id == category_id.id)
        for employee in employee_ids:
            hr_leave = self.env['hr.leave'].search([('employee_id', '=', employee.id), ('request_date_from', '=', date)], limit=1)
            domain = [
                ('date_check_in', '=', date),
                ('employee_id', '=', employee.id),
                ('att_type', '=', 'factory'),
                ('night_shift_id', '=', shift_id.id),
                ('approved_type', '=', 'approved'),
            ]
            hours_from = self.env['ir.qweb.field.float_time'].value_to_html(shift_id.calender_id.hour_from, {})
            hours_to = self.env['ir.qweb.field.float_time'].value_to_html(shift_id.calender_id.hour_to, {})
            attendance_hours = shift_id.attendance_hours
            date_from = self._get_server_datetime(datetime.datetime.strptime(date + ' ' + hours_from + ':00', '%Y-%m-%d %H:%M:%S') + relativedelta(hours=-attendance_hours))
            date_to = self._get_server_datetime(datetime.datetime.strptime(date + ' ' + hours_to + ':00', '%Y-%m-%d %H:%M:%S') + relativedelta(days=1, hours=attendance_hours))
            if shift_id.shift_type == 'night':
                domain = [
                    ('check_in', '>=', date_from),
                    ('check_in', '<=', date_to),
                    ('employee_id', '=', employee.id),
                    ('night_shift_id', '=', shift_id.id),
                    ('att_type', '=', 'factory'),
                    ('approved_type', '=', 'approved'),
                ]

            attendance_ids = self.env['hr.attendance'].search(domain, order='check_in')
            check_in_out = {
                'time1': '',
                'time2': '',
                'time3': '',
                'time4': '',
                'time5': '',
                'time6': '',
                'time7': '',
                'time8': '',
            }
            device = {
                'd1': '',
                'd2': '',
                'd3': '',
                'd4': '',
                'd5': '',
                'd6': '',
                'd7': '',
                'd8': '',
            }
            count = 1
            for att in attendance_ids:
                if count > 8:
                    continue
                in_device_name = att.in_device_id and att.in_device_id.operation_id.name or ''
                out_device_name = att.out_device_id and att.out_device_id.operation_id.name or ''
                check_in_out['time'+str(count)] = self._get_client_time(att.check_in)
                device['d'+str(count)] = in_device_name
                count += 1
                check_in_out['time'+str(count)] = self._get_client_time(att.check_out)
                device['d'+str(count)] = out_device_name
                count += 1
            if hr_leave.number_of_days > 0 and hr_leave.number_of_days < 1 and len(attendance_ids) < 4:
                for key, value in check_in_out.items:
                    if not value:
                        check_in_out[key] = 'Half Leave'

            att_data.append({
                'sr_no': sr_no,
                'name': employee.name,
                # 'job_title': employee.job_title,
                'department': employee.department_id.name,
                'identification_id': employee.identification_id,
                'worked_hours': self.env['ir.qweb.field.float_time'].value_to_html(sum(attendance_ids.mapped('worked_hours')), {}),
                'absent': False if len(attendance_ids) else True,
                'leave_status': hr_leave.holiday_status_id.name if not attendance_ids and hr_leave else 'Absent',
                'check_in_out': check_in_out,
                'device': device,
                'job_title': employee.job_title and employee.job_title[:12] or '-',
                'category_id': employee.category_id and employee.category_id.name and employee.category_id.name[:2] or '-',

            })
            sr_no += 1
        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'date': date,
            'shift_name': shift_id.name,
            'department': department_id and department_id.name or False,
            'attendance_data': att_data,
            'category_id': category_id,
        }
