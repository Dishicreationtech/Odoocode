# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class EmployeeWithoutShift(models.TransientModel):
    _name = "employee.without.shift"
    _description = 'Employee Shift'

    date = fields.Date('Date')


    def print_report(self):
        data = {}
        date = self.date
        shift_allocation = self.env['shift.allocation'].search([('date_from','<=', date), ('date_to', '>=', date)])
        employee_ids = self.env['hr.employee'].search([])
        data['date'] = date
        if not employee_ids:
            raise UserError(_('All employee have shift allocation'))
        if not shift_allocation:
            data['employee_ids'] = employee_ids.ids
        else:
            shift_employee_ids = shift_allocation.mapped('employee_id')
            employee_without_shift = employee_ids - shift_employee_ids
            data['employee_ids'] = employee_without_shift.ids
        # print ("===================employee_ids",employee_ids)
        return self.env.ref('hr_report_extended.action_employee_without_summer_report').report_action(self, data=data)

    