# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class EmployeeShiftReport(models.AbstractModel):
    _name = 'report.hr_report_extended.report_without_shift'
    _description = 'Report Hr'

    @api.model
    def _get_report_values(self, docids, data=None):
        employee_ids = self.env['hr.employee'].browse(data.get('employee_ids'))
        return {
            'employee_ids' : employee_ids,
        }