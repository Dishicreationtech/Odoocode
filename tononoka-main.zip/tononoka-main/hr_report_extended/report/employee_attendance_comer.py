# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import datetime
from datetime import datetime, timedelta

class EmployeeAttendanceComerReport(models.AbstractModel):
    _name = 'report.hr_report_extended.report_employee_attendance_comer'
    _description = 'Report Type'

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'lines' : data.get('lines') if data.get('lines') else [],
            'from_date' : fields.Date.from_string(data.get('from_date')).strftime('%d/%b/%Y'),
            'type' : data.get('type'),
            'shift_id': data.get('shift_name'),
            'department': data.get('department')
        }