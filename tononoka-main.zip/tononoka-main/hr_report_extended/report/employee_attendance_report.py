# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import datetime
from datetime import datetime, timedelta
import pytz
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

class EmployeeAttendanceReport(models.AbstractModel):
    _name = 'report.hr_report_extended.report_employee_attendance'
    _description = 'Report Hr'

    def _get_client_time(self, sync_time):
        """ Need to configure a time in proper manners"""
        from datetime import datetime
        if not sync_time:
            return ''
        date = sync_time.strftime('%Y-%m-%d %H:%M:%S')
        if date:
            user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
            local = pytz.timezone(user_tz)
            date = datetime.strptime(datetime.strftime(pytz.utc.localize(datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date

    def _get_type(self):
        return {
            'both' : 'All',
            'approved' : 'Approved',
            'to_approved' : 'To Be Approved',
        }

    def _prepaire_data(self, attendance_id):
        work_hours = ''
        if attendance_id.employee_id.resource_calendar_id and attendance_id.employee_id.resource_calendar_id.hour_from and attendance_id.employee_id.resource_calendar_id.hour_to:
            hours_from = self.env['ir.qweb.field.float_time'].value_to_html(attendance_id.employee_id.resource_calendar_id.hour_from, {})
            hours_to = self.env['ir.qweb.field.float_time'].value_to_html(attendance_id.employee_id.resource_calendar_id.hour_to, {})
            work_hours = hours_from + ' To ' + hours_to
        in_device = attendance_id.in_device_id.operation_id.name if attendance_id.in_device_id and attendance_id.in_device_id.operation_id.name else False
        out_device = attendance_id.out_device_id.operation_id.name if attendance_id.out_device_id and attendance_id.out_device_id.operation_id.name else False
        in_time = self._get_client_time(attendance_id.check_in)
        out_time = self._get_client_time(attendance_id.check_out)
        return {
            'name' : attendance_id.employee_id.name,
            'payroll_number' : attendance_id.employee_id.payroll_number if attendance_id.employee_id.payroll_number else 0.0,
            'category' : attendance_id.employee_id.category_id and attendance_id.employee_id.category_id.name and attendance_id.employee_id.category_id.name[:2] or '-', 
            'department_id' : attendance_id.department_id.name if attendance_id.department_id else '',
            'check_in' : in_time and in_time.strftime('%d-%m-%Y %H:%M:%S') or '',
            'check_out' : out_time and out_time.strftime('%d-%m-%Y %H:%M:%S') or '',
            'work_hours' : work_hours if work_hours else 00.00,
            'in_device' : in_device,
            'out_device' : out_device
        }

    @api.model
    def _get_report_values(self, docids, data=None):
        attendance_ids = self.env['hr.attendance'].browse(data.get('attendance_ids'))
        lines = [self._prepaire_data(line) for line in attendance_ids]
        print(data.get('attendance_ids'))
        type = self._get_type()
        return {
            'attendance_lines' : lines,
            'from_date' : fields.Date.from_string(data.get('from_date')).strftime('%d/%b/%Y'),
            'to_date' : fields.Date.from_string(data.get('to_date')).strftime('%d/%b/%Y'),
            'type' : type.get(data.get('approved_type'))
        }