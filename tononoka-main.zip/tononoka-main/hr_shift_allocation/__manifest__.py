# -*- coding: utf-8 -*-
{
    'name': "HR Shift Allocation",
    'summary': "HR Shift Allocation",
    'category': 'HR',
    'version': '14.0.0',
    'depends': ['hr'],
    'data': [
                'security/ir.model.access.csv',
                'data/data.xml',
                'views/employee_category.xml',             
                'views/hr_employee.xml',                  
                'views/hr_shift.xml',
                'views/shift_allocation_view.xml',
                'views/sub_category_view.xml',
                'wizard/bulk_allocation.xml',            
                'wizard/import_allocation.xml',            
            ],
    'installable': True,
    'application': True
}
