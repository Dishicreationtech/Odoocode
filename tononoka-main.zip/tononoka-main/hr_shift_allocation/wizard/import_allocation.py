from odoo import models, api, fields, _
import io
import tempfile
import xlrd
import logging
import binascii
from odoo.exceptions import ValidationError
from datetime import date, datetime

_logger = logging.getLogger(__name__)

try:
	import xlwt
except ImportError:
	_logger.debug('Cannot `import xlwt`.')
try:
	import cStringIO
except ImportError:
	_logger.debug('Cannot `import cStringIO`.')
try:
	import base64
except ImportError:
	_logger.debug('Cannot `import base64`.')

class ImportAllocation(models.TransientModel):
	_name = "import.allocation.wizard"
	_description = "import.allocation.wizard"

	excel_file = fields.Binary('Select File')

	def button_cancel(self):
		return True

	def _find_employee(self, emp_name):
		if emp_name:
			employee_id = self.env['hr.employee'].sudo().search([('name', 'ilike', emp_name)], limit=1)
			if not employee_id:
				raise ValidationError(_('Please create employee : %s' %emp_name))
			return employee_id
		return False

	def _sub_category(self, sub_category):
		if sub_category:
			category_id = self.env['sub.category'].sudo().search([('name', 'ilike', sub_category)], limit=1)
			if not category_id:
				raise ValidationError(_('Please create sub category : %s ' %sub_category))
			return category_id
		return False

	def _sub_shift(self, shift_name):
		if shift_name:
			shift_id = self.env['hr.shift'].sudo().search([('name', 'ilike', shift_name)], limit=1)
			if not shift_id:
				raise ValidationError(_('Please create shift : %s' %shift_name))
			return shift_id
		return False

	def import_allocation(self):
		if not self.excel_file:
			raise ValidationError(_('Please Select a xlsx file.'))
		try:
			fp = tempfile.NamedTemporaryFile(delete= False,suffix=".xlsx")
			fp.write(binascii.a2b_base64(self.excel_file))
			fp.seek(0)
			values = {}
			workbook = xlrd.open_workbook(fp.name)
			sheet = workbook.sheet_by_index(0)
			for row_no in range(sheet.nrows):
				val = {}
				if row_no <= 0:
					fields = map(lambda row:row.value.encode('utf-8'), sheet.row(row_no))
				else:
					line = list(map(lambda row:isinstance(row.value, bytes) and row.value.encode('utf-8') or str(row.value), sheet.row(row_no)))
					from_date = int(float(line[0]))
					to_date = int(float(line[1]))
					from_date_datetime = datetime(*xlrd.xldate_as_tuple(from_date, workbook.datemode))
					to_date_datetime = datetime(*xlrd.xldate_as_tuple(to_date, workbook.datemode))
					from_string = from_date_datetime.date().strftime('%Y-%m-%d')
					to_string = to_date_datetime.date().strftime('%Y-%m-%d')

					employee_id = self._find_employee(line[2])
					sub_category_id = self._sub_category(line[3])
					shift_id = self._sub_shift(line[4])
					if not employee_id.shift_id:
						employee_id.shift_id = shift_id.id

					vals = {
						'date_from' : from_string,
						'date_to' : to_string,
						'employee_id' : employee_id.id,
						'sub_category_id' : sub_category_id.id,
						'shift_id' : shift_id.id,
					}
					self.env['shift.allocation'].create(vals)
		except Exception as e:
			raise ValidationError('Allocation Error: "%s"' % (e,))

