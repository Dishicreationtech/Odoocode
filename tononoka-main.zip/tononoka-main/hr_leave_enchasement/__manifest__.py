# -*- coding: utf-8 -*-
{
    'name': "Hr Enchasement",
    'summary': "Hr Enchasement",
    'category': 'HR',
    'version': '14.0.0',
    'depends': ['hr', 'hr_contract', 'hr_shift_allocation'],
    'data': [
            'security/ir.model.access.csv',
            'data/data.xml',
            'views/hr_contract.xml',             
            'views/hr_enchasement.xml',             
             ],
    'installable': True,
    'application': True
}
