from odoo import models, fields, api, _
from datetime import datetime

class HrEncasement(models.Model):
	_name = "hr.employee.enchasement"
	_description = 'Enchasment'
	_order = 'id desc'
	_inherit = ['mail.thread', 'mail.activity.mixin']


	@api.onchange('contract_id.wage','days', 'enchase_type')
	def onchange_type(self):
		total_amount = 0.0
		for record in self:
			if record.contract_id and record.contract_id.wage and record.days and record.enchase_type == 'day_salary':
				total_amount = record.contract_id.wage / record.days
			record.amount = total_amount 

	@api.depends('leave', 'amount')
	def _get_sum(self):
		for rec in self:
			rec.total = rec.leave*rec.amount

	name = fields.Char('Name', required=True, index=True, readonly=True, copy=False, default='New')
	employee_id = fields.Many2one("hr.employee",required=True)
	date_to = fields.Datetime(required=True, string='Date', default=fields.Datetime.now)
	department_id = fields.Many2one('hr.department')
	job_id = fields.Many2one('hr.job')
	leave = fields.Float(default=1.0)
	amount = fields.Float()
	description = fields.Text()
	enchase_type = fields.Selection([('day_salary','Daily Salary'),('fixed_amount','Fixed Amount')],required=True, default='fixed_amount')
	contract_id = fields.Many2one("hr.contract",required=True)
	state = fields.Selection([('draft', 'Draft'),('approve', 'Approve'),('cancel','Cancel')], default='draft')
	total = fields.Float(compute='_get_sum')
	days = fields.Float(default=22)
	
	

	def button_approve(self):
		self.state = 'approve'

	def button_set_to_draft(self):
		self.state = 'draft'

	def button_cancel(self):
		self.state = 'cancel'


	@api.onchange('employee_id')
	def _onChangeEmployee(self):
		if self.employee_id:
			self.department_id = self.employee_id.department_id and self.employee_id.department_id.id	
			self.job_id = self.employee_id.job_id and self.employee_id.job_id.id 		
	
	@api.model
	def create(self, vals):
		if vals.get('name', 'New') == 'New':
			vals['name'] = self.env['ir.sequence'].next_by_code('hr.employee.enchasement') or ('New')
		return super(HrEncasement, self).create(vals)

class HrContract(models.Model):
	_inherit = 'hr.contract'

	enchasement_ids = fields.One2many('hr.employee.enchasement', 'contract_id')
