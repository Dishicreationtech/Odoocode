from odoo import models, fields, api, _

class HrEncasement(models.Model):
	_name = "hr.employee.enchasement"
	_description = 'Enchasment'
	_inherit = ['mail.thread', 'mail.activity.mixin']

	employee_id = fields.Many2one("hr.employee")
	date_to = fields.Datetime(required=True)
	department_id = fields.Many2one('hr.department')
	job_id = fields.Many2one('hr.job')
	leave = fields.Float()
	amount = fields.Float()
	description = fields.Text()
	payslip_id = fields.Many2one('hr.payslip')
	enchase_type = fields.Selection([('day_salary','Day Salary'),('fixed_amount','Fixed Amount')])
	contact_id = fields.Many2one("hr.contact")
	state = fields.Selection([('draft', 'Draft'),('approve', 'Approve'),('cancel','Cancel')], default='draft')


	def button_approve(self):
		self.state = 'approve'

	def button_set_to_draft(self):
		self.state = 'draft'

	def button_cancel(self):
		self.state = 'cancel'

# add one2many in hr.contact and link all encash of that perticular employee
# start
