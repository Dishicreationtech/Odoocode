# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class SalesEbmCustomerInvoice(models.Model):
    _inherit = 'sale.order'

    def _prepare_invoice(self):

        self.ensure_one()
        str_type = ''
        if self.types == 'accessories':
            str_type = 'Accessories'
        elif self.types == 'glass':
            str_type = 'Glass Work'
        elif self.types == 'aluminium':
            str_type = 'Aluminium profiles'
        elif self.types == 'projects':
            str_type = 'Projects'
        else:
            str_type = ''

        # self = self.with_context(default_company_id=self.company_id.id,
        #                          force_company=self.company_id.id)
        journal = self.env['account.move']. \
            with_context(default_type='out_invoice')._get_default_journal()
        if not journal:
            raise UserError(_('Please define an accounting sales journal '
                              'for the company %s (%s).') %
                            (self.company_id.name, self.company_id.id))

        invoice_vals = {
            'ref': self.client_order_ref or '',
            'type': 'out_invoice',
            'narration': self.note,
            'currency_id': self.pricelist_id.currency_id.id,
            'campaign_id': self.campaign_id.id,
            'medium_id': self.medium_id.id,
            'source_id': self.source_id.id,
            'invoice_user_id': self.user_id and self.user_id.id,
            'team_id': self.team_id.id,
            'partner_id': self.partner_invoice_id.id,
            'partner_shipping_id': self.partner_shipping_id.id,
            'invoice_partner_bank_id': self.company_id.partner_id.
            bank_ids[:1].id,
            'fiscal_position_id': self.fiscal_position_id.id or
            self.partner_invoice_id.property_account_position_id.id,
            'journal_id': journal.id,  # company comes from the journal
            'invoice_origin': self.name,
            'invoice_payment_term_id': self.payment_term_id.id,
            'invoice_payment_ref': self.reference,
            'transaction_ids': [(6, 0, self.transaction_ids.ids)],
            'invoice_line_ids': [],
            'company_id': self.company_id.id,
            'types': str_type
        }
        return invoice_vals


class SalesLineEbmCustomerInvoice(models.Model):
    _inherit = 'sale.order.line'

    def _prepare_invoice_line(self):

        self.ensure_one()
        price_unit = None
        if self.order_id.types == 'aluminium':
            price_unit = self.xlength * self.price_unit
        elif self.order_id.types == 'glass':
            price_unit = self.sqm * self.price_unit
        elif self.order_id.types == 'projects':
            price_unit = self.sqm * self.price_sqm
        else:
            price_unit = self.price_unit

        res = {
            'display_type': self.display_type,
            'sequence': self.sequence,
            'name': self.name,
            'product_id': self.product_id.id,
            'product_uom_id': self.product_uom.id,
            'quantity': self.qty_to_invoice,
            'discount': self.discount,
            'price_unit': price_unit,
            'total_sqm': self.total_sqm,
            'total_mtr': self.total_meter,
            'sqm': self.sqm,
            'pp_sqm': self.price_sqm,
            'new_price': self.price_unit,
            'length': self.xlength,
            # 'sqm': self.sqm,
            'new_total': self.price_subtotal,
            'tax_ids': [(6, 0, self.tax_id.ids)],
            'analytic_account_id': self.order_id.analytic_account_id.id,
            'analytic_tag_ids': [(6, 0, self.analytic_tag_ids.ids)],
            'sale_line_ids': [(4, self.id)],
        }
        if self.display_type:
            res['account_id'] = False
        return res


class EbmCustomerInvoiceAccountMove(models.Model):
    _inherit = 'account.move'

    types = fields.Char(string='Quotation Type', readonly=True)


class AccountMoveLineEbm(models.Model):
    _inherit = "account.move.line"

    total_sqm = fields.Float(string='Total SQM', readonly=True)
    new_price = fields.Float(string='Price ')
    total_mtr = fields.Float(string='Total Meter', readonly=True)
    sqm = fields.Float(string='SQM', readonly=True)
    pp_sqm = fields.Float(string='Price per SQM', readonly=True)
    length = fields.Float(readonly=True)
    # sqm = fields.Float(readonly=True)
    new_total = fields.Float(string='Subtotal ', readonly=True)
    # price_unit = fields.Float(compute='_compute_new_price')
    # non_total = fields.Float(string='Subtotal ', readonly=True,
    #                          compute='_compute_new_total')

    def _get_price_total_and_subtotal(self, price_unit=None, quantity=None,
                                      discount=None, currency=None,
                                      product=None, partner=None, taxes=None,
                                      move_type=None):
        self.ensure_one()
        return self._get_price_total_and_subtotal_model(
            price_unit=self.price_unit,
            # price_unit=self.new_price,
            quantity=self.quantity,
            # quantity=quantity or self.quantity,
            discount=self.discount,
            currency=self.currency_id,
            product=self.product_id,
            partner=self.partner_id,
            taxes=self.tax_ids,
            move_type=move_type or self.move_id.type,
        )

    @api.model
    def _get_price_total_and_subtotal_model(self, price_unit, quantity,
                                            discount, currency, product,
                                            partner, taxes, move_type,
                                            ):

        res = {}

        # Compute 'price_total'.
        logging.info("I am None of the types")
        logging.info("Unit price")
        logging.info(price_unit)
        price_unit_wo_discount = price_unit * (1 - (discount / 100.0))
        subtotal = quantity * price_unit_wo_discount
        if taxes:
            force_sign = -1 if move_type in \
                ('out_invoice', 'in_refund', 'out_receipt') else 1
            taxes_res = taxes._origin.with_context(force_sign=force_sign). \
                compute_all(price_unit_wo_discount,
                            quantity=quantity,
                            currency=currency, product=product,
                            partner=partner, is_refund=move_type in
                            ('out_refund', 'in_refund'))
            logging.info("Taxes")
            logging.info(taxes_res)
            res['price_subtotal'] = taxes_res['total_excluded']
            res['price_total'] = taxes_res['total_included']
        else:
            res['price_total'] = res['price_subtotal'] = subtotal
            # res['price_subtotal'] = subtotal

        if currency:
            res = {k: currency.round(v) for k, v in res.items()}
        return res
