# -*- coding: utf-8 -*-
{
    'name': "Customer Invoice",

    'summary': """
        This module gives the ability to include sales order fields""",

    'description': """
        This module gives the ability to include sales order fields
    """,

    'author': "erpSOFTapp",
    'website': "http://www.erpsoftapp.com",

    # for the full list
    'category': 'Uncategorized',
    'version': '13.0.0.0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'sale', 'account', 'custom_sales_order_qweb_report'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
}
