# -*- coding: utf-8 -*-
{
    'name': "Custom Sales Order With Qweb Report",

    'summary': """
        This module gives the ability to add more fields on the quotation
        and adjusments on the quotation printout""",

    'description': """
        This module gives the ability to add more fields on the quotation
        and adjusments on the quotation printout
    """,

    'author': "erpSOFTapp",
    'website': "http://www.erpsoftapp.com",

    'category': 'Uncategorized',
    'version': '13.0.0.0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'sale', 'products_additional_fields', 'web'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        # 'views/templates.xml',
        'reports/report_menu.xml',
        'reports/report_accessories.xml',
        'reports/report_projects.xml',
        'reports/report_aluminium.xml',
        'reports/report_glass.xml',
        'reports/report_template.xml',
    ],
    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
}
