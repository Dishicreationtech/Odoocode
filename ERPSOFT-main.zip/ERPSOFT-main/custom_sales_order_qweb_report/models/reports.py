# -*- coding: utf-8 -*-
# import logging
from odoo import models, api, _
from odoo.exceptions import ValidationError


class SaleOrderAccessoriesReport(models.AbstractModel):
    _name = 'report.custom_sales_order_qweb_report.report_accessories'
    _description = 'Sale Order Accessories Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['sale.order'].browse(docids)

        for doc in docs:
            terms = self.env['sales.terms']. \
                search([('typex', '=', 'accessories')])
            if doc.types != 'accessories':
                raise ValidationError(_('You can only print for the type '
                                        'of quotation selected'))

            return {
                'doc_ids': docs.ids,
                'doc_model': 'sale.order',
                'docs': docs,
                'terms': terms
            }


class SaleOrderGlassReport(models.AbstractModel):
    _name = 'report.custom_sales_order_qweb_report.report_glass'
    _description = 'Sale Order Glass Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['sale.order'].browse(docids)

        for doc in docs:
            terms = self.env['sales.terms']. \
                search([('typex', '=', 'glass')])
            if doc.types != 'glass':
                raise ValidationError(_('You can only print for the type '
                                        'of quotation selected'))

            return {
                'doc_ids': docs.ids,
                'doc_model': 'sale.order',
                'docs': docs,
                'terms': terms
            }


class SaleOrderAluminiumReport(models.AbstractModel):
    _name = 'report.custom_sales_order_qweb_report.report_aluminium'
    _description = 'Sale Order Aluminium Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        # logging.info("Testing Aluminium")
        docs = self.env['sale.order'].browse(docids)

        for doc in docs:
            terms = self.env['sales.terms']. \
                search([('typex', '=', 'aluminium')])
            # logging.info(terms.notes)
            if doc.types != 'aluminium':
                raise ValidationError(_('You can only print for the type '
                                        'of quotation selected'))

            return {
                'doc_ids': docs.ids,
                'doc_model': 'sale.order',
                'docs': docs,
                'terms': terms
            }


class SaleOrderProjectsReport(models.AbstractModel):
    _name = 'report.custom_sales_order_qweb_report.report_projects'
    _description = 'Sale Order Projects Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['sale.order'].browse(docids)

        for doc in docs:
            terms = self.env['sales.terms']. \
                search([('typex', '=', 'projects')])
            if doc.types != 'projects':
                raise ValidationError(_('You can only print for the type '
                                        'of quotation selected'))

            return {
                'doc_ids': docs.ids,
                'doc_model': 'sale.order',
                'docs': docs,
                'terms': terms
            }
