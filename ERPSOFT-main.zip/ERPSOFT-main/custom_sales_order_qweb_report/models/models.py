# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class SalesPartnerBankInherit(models.Model):
    _inherit = 'res.partner.bank'

    display_on_sales = fields.Boolean(string='Display On Sales Quotation '
                                             'Report', readonly=False)
    location = fields.Char()
    tag = fields.Char(compute='_compute_tag', store=True)

    @api.depends('location')
    def _compute_tag(self):
        for rec in self:
            locate_count = self.env['res.partner.bank']. \
                search_count([('location', '!=', None),
                              ('location', '=', rec.location)])

            if locate_count > 1:
                # logging.info('I am more than 0')
                locations = self.env['res.partner.bank']. \
                    search([('location', '!=', None),
                            ('location', '=', rec.location)],
                           order='id desc', limit=1)

                if locations.id:

                    locations.write({
                        'tag': 'original'
                    })
                    rec.tag = 'test'
                else:
                    logging.info("There is NOne")
                    rec.tag = 'test'
            else:
                rec.tag = 'original'

    def name_get(self):
        # logging.info('checking for context')
        # logging.info(self.env.context)
        # sale = self.env['sale.order']
        # logging.info("Get sale model")

        result = []
        # name = None
        for rec in self:
            if 'location_id' in self.env.context or ('params' in
                                                     self.env.context and
                                                     self.env.context
                                                     ['params']['model']
                                                     == 'sale.order'):
                # logging.info("Testing location params")
                name = rec.location
            else:
                # logging.info("Params for Employee")
                name = rec.acc_number
            # name = rec.location if self.env.context.get('location_id') \
            #         else rec.acc_number
            result.append((rec.id, name))
        return result

    @api.model
    def create(self, vals_list):
        if 'location' in vals_list and vals_list['location']:
            vals_list['location'] = vals_list['location']. \
                replace(" ", "").upper()
        res = super(SalesPartnerBankInherit, self).create(vals_list)
        return res

    def write(self, vals_list):
        if 'location' in vals_list and vals_list['location']:
            vals_list['location'] = vals_list['location']. \
                replace(" ", "").upper()
        res = super(SalesPartnerBankInherit, self).write(vals_list)
        return res


class CustomSalesInherit(models.Model):
    _inherit = 'sale.order'

    def _fetch_location(self):
        locations = self.env['res.partner.bank'].\
            search([('location', '!=', None),
                    ('tag', '=', 'original')])
        availables = []

        for rec in locations:
            availables.append(rec.id)

        return [('id', 'in', availables)]

    types = fields.Selection([
        ('accessories', 'Accessories'),
        ('glass', 'Glass Work'),
        ('aluminium', 'Aluminium profiles'),
        ('projects', 'Projects'),
    ], 'Types of Quotations')

    glass = fields.Selection([
        ('ebm_glass', 'EBM Glass'),
        ('customer_glass', "Customer's Glass")
    ], 'Glass Source')
    quotation = fields.Text(string='Quotation Title', readonly=False,
                            compute='_compute_quotation_title',
                            store=True)
    total_quantity = fields.Float(default=0.00, compute='_compute_total_order',
                                  store=True)
    total_weight = fields.Float(default=0.00, compute='_compute_total_weight',
                                store=True)
    # location = fields.Many2one('res.partner.bank',
    #                            domain=[('location', '!=', None),
    #                            ('location', '!=', 'location')],
    #                            string='Bank Account Location')
    location = fields.Many2one('res.partner.bank',
                               domain=_fetch_location,
                               string='Bank Account Location')

    @api.onchange('types')
    def _compute_quotation_title(self):
        for record in self:
            if record.types == 'accessories':
                record.quotation = 'Quotation For Accessories'
            elif record.types == 'glass':
                record.quotation = 'Quotation For Glass Work'
            elif record.types == 'aluminium':
                logging.info("aluminium")
                record.quotation = 'Quotation For Aluminium Profiles'
                logging.info(record.quotation)
            else:
                record.quotation = None

    @api.depends('order_line.product_uom_qty')
    def _compute_total_order(self):
        for record in self:

            # logging.info("I am total quantity")
            total_quantity = 0.00

            for line in record.order_line:
                # if line.product_uom_qty:
                if line.product_uom_qty:
                    total_quantity += line.product_uom_qty
                    # total_weight += line.weight
            record.total_quantity = total_quantity

    @api.depends('order_line.weight')
    def _compute_total_weight(self):
        for record in self:
            total_weight = 0.00

            for line in record.order_line:
                total_weight += line.weight
            record.update({
                'total_weight': total_weight
            })

    # @api.model
    # def create(self, vals):
    #     count = 0
    #     logging.info(vals)
    #     for order in vals['order_line']:
    #         count += 1
    #         logging.info(count)
    #     return super(CustomSalesInherit, self).create(vals)

    def _write(self, values):
        count = 0

        for line in self:
            # self = self.with_context({}, key2=True)
            # logging.info("Checking for sales after context")
            # logging.info(self._context)
            for rec in line.order_line:
                if rec.product_id:
                    count += 1
                    rec['no'] = count

        return super(CustomSalesInherit, self)._write(values)


class SalesTermsAndConditions(models.Model):
    _name = 'sales.terms'
    _description = 'Terms and Conditions'
    _rec_name = 'typex'

    typex = fields.Selection([
        ('accessories', 'Accessories'),
        ('glass', 'Glass Work'),
        ('aluminium', 'Aluminium profiles'),
        ('projects', 'Projects')
    ], 'Types of Quotations')
    # n_type = fields.Selection([
    #     ('type1', 'Type 1'),
    #     ('type2', 'Type 2'),
    # ], 'Type', default='type1')
    d_active = fields.Boolean(string='Active')
    notes = fields.Text()
    # select = fields.Selection(selection=[
    #     ('a', 'A')
    # ])

    @api.onchange('d_active')
    def _onchange_active(self):
        for rec in self:
            terms = self.env['sales.terms']. \
                search([('typex', '=', rec.typex),
                        ('d_active', '=', True)],
                       order='create_date desc', limit=1)

            if terms.id:
                raise UserError(_("There is an Active terms and condition "
                                  "for the type selected already, there can "
                                  "be one active terms and conditons "
                                  "at a time"))


class CustomSalesLine(models.Model):
    _inherit = 'sale.order.line'

    xlength = fields.Float(string='Length', default=0.00,
                           compute='_compute_xlength',
                           readonly=False,
                           store=True, digits=(12, 2))
    weight = fields.Float(default=0.00, compute='_compute_weight',
                          store=True, digits=(12, 2))
    unit_weight = fields.Float(default=0.00, compute='_compute_unit_weight',
                               store=True, digits=(12, 2))
    width = fields.Float(default=0.00, compute='_compute_width',
                         readonly=False,
                         store=True, digits=(12, 2))
    height = fields.Float(default=0.00, compute='_compute_height',
                          readonly=False,
                          store=True, digits=(12, 2))
    image = fields.Binary(default=False, store=True,
                          #   compute='_compute_image'
                          )
    sqm = fields.Float(default=0.00, compute='_compute_sqm',
                       store=True, digits=(12, 2))
    price_sqm = fields.Float(string='Price Per SQM', default=0.00,
                             store=True, digits=(12, 2))
    total_sqm = fields.Float(default=0.00, string='Total SQM',
                             readonly=False,
                             compute='_compute_total_sqm', store=True)
    total_meter = fields.Float(default=0.00, compute='_compute_total_meter',
                               store=True)
    edging = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')
    ])
    no = fields.Integer(string='No.', readonly=True)
    new_des = fields.Text(compute='_compute_description', store=True)
    price_unit = fields.Float(compute='_compute_price_unit', store=True)

    @api.depends('product_uom', 'product_uom_qty', 'sqm', 'price_sqm')
    def _compute_price_unit(self):
        # self.ensure_one()
        logging.info("Price unit")
        for record in self:
            if not record.product_uom or not record.product_id:
                record.price_unit = 0.0
                return
            if record.order_id.pricelist_id and record.order_id.partner_id:
                if record.order_id.types == 'projects':
                    record.price_unit = record.sqm * record.price_sqm
                    # for record in record:
                    #     record.price_unit = record.sqm * record.price_sqm
                else:
                    product = record.product_id.with_context(
                        lang=record.order_id.partner_id.lang,
                        partner=record.order_id.partner_id,
                        quantity=record.product_uom_qty,
                        date=record.order_id.date_order,
                        pricelist=record.order_id.pricelist_id.id,
                        uom=record.product_uom.id,
                        fiscal_position=record.env.context.get('fiscal_position')
                    )
                    record.price_unit = record.env['account.tax']. \
                        _fix_tax_included_price_company(record._get_display_price(
                                                        product), product.taxes_id,
                                                        record.tax_id,
                                                        record.company_id)

    @api.depends('name')
    def _compute_description(self):
        for rec in self:
            # logging.info(rec.name)

            if rec.name:
                new_name = rec.name.split('\n')
                rec.new_des = ' '.join(new_name[1:])
                # logging.info(rec.new_des)
            else:
                rec.new_des = None

    @api.depends('product_id')
    def _compute_xlength(self):
        # logging.info("Test")
        for record in self:
            # logging.info(record.product_template_id.length)
            # logging.info("Before assigning lenght")
            # logging.info(record.xlength)
            record.xlength = record.product_template_id.length

    @api.depends('product_id')
    def _compute_unit_weight(self):
        for record in self:
            if record.product_id.is_product_variant:
                # logging.info("Yes i am variant")
                # logging.info(record.product_id.weight)
                record.unit_weight = record.product_id.weight
            else:
                record.unit_weight = record.product_template_id.weight

    @api.depends('product_id')
    def _compute_width(self):
        for record in self:
            record.width = record.product_template_id.width

    @api.depends('product_id')
    def _compute_height(self):
        # count = 0
        # logging.info(self)
        # logging.info("height")
        for record in self:
            record.height = record.product_template_id.height

    @api.depends('height', 'width')
    def _compute_sqm(self):
        for record in self:
            record.sqm = record.height * record.width
            # record.sqm = record.product_template_id.sqm

    @api.onchange('product_id')
    def _onchange_image(self):
        for record in self:
            if record.order_id.types == 'aluminium':
                # logging.info("Find image here")
                # logging.info(record.product_template_id.image_1920)
                record.image = record.product_template_id.image_1920
            #     if record.product_template_id.image_1920:
            #         record.image = record.product_template_id.image_1920
            #         logging.info("Find image is here")
            #         # logging.info(record.image)
            #     else:
            #         record.image = False
            #         logging.info("Find image not here")
            #         logging.info(record.product_template_id.image_1920)
            # else:
            #     record.image = False

    # @api.depends('product_id')
    # def _compute_image(self):
    #     for record in self:
    #         if record.product_id:
    #             if record.product_template_id.image_1920:
    #                 record.image = record.product_template_id.image_1920
    #                 logging.info("Find image is here")
    #                 logging.info(record.image)
    #             else:
    #                 record.image = False
    #                 logging.info("Find image not here")
    #                 logging.info(record.image)
            # else:
            #     record.image = None
                # if record.product_template_id.image_1920 else None

    @api.depends('unit_weight', 'product_uom_qty')
    def _compute_weight(self):
        for record in self:
            record.weight = (record.unit_weight * record.xlength) * \
                record.product_uom_qty
            # record.weight = record.unit_weight * record.product_uom_qty

    @api.onchange('sqm', 'product_uom_qty')
    def _compute_total_sqm(self):
        for record in self:
            # if record.sqm:
            # logging.info("checking sqm")
            # logging.info(record.sqm)
            record.total_sqm = record.sqm * record.product_uom_qty

    @api.depends('xlength', 'product_uom_qty')
    def _compute_total_meter(self):
        for record in self:
            record.total_meter = record.xlength * record.product_uom_qty

    # @api.onchange('product_uom', 'product_uom_qty', 'sqm', 'price_sqm')
    # def product_uom_change(self):
    #     if not self.product_uom or not self.product_id:
    #         self.price_unit = 0.0
    #         return
    #     if self.order_id.pricelist_id and self.order_id.partner_id:
    #         if self.order_id.types == 'projects':
    #             self.price_unit = self.sqm * self.price_sqm
    #             # for rec in self:
    #             #     rec.price_unit = rec.sqm * rec.price_sqm
    #         else:
    #             product = self.product_id.with_context(
    #                 lang=self.order_id.partner_id.lang,
    #                 partner=self.order_id.partner_id,
    #                 quantity=self.product_uom_qty,
    #                 date=self.order_id.date_order,
    #                 pricelist=self.order_id.pricelist_id.id,
    #                 uom=self.product_uom.id,
    #                 fiscal_position=self.env.context.get('fiscal_position')
    #             )
    #             self.price_unit = self.env['account.tax']. \
    #                 _fix_tax_included_price_company(self._get_display_price(
    #                                                 product), product.taxes_id,
    #                                                 self.tax_id,
    #                                                 self.company_id)

    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_id',
                 'total_meter', 'total_sqm')
    def _compute_amount(self):
        """
        Compute the amounts of the SO line.
        """
        for line in self:
            # price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            # taxes = line.tax_id.compute_all(price, line.order_id.currency_id,
            #                                 line.product_uom_qty,
            #                                 product=line.product_id,
            #                                 partner=line.order_id.
            #                                 partner_shipping_id)
            if line.order_id.types == 'aluminium':
                price = (line.total_meter * line.price_unit) * \
                    (1 - (line.discount or 0.0) / 100.0)
                taxes = line.tax_id.compute_all(price,
                                                line.order_id.currency_id,
                                                # line.product_uom_qty,
                                                product=line.product_id,
                                                partner=line.order_id.
                                                partner_shipping_id)
                line.update({
                    'price_tax': sum(t.get('amount', 0.0)
                                     for t in taxes.get('taxes', [])),
                    'price_total': taxes['total_included'],
                    'price_subtotal': taxes['total_excluded'],
                })

            elif line.order_id.types == 'glass':
                price = (line.total_sqm * line.price_unit) * \
                    (1 - (line.discount or 0.0) / 100.0)
                taxes = line.tax_id.compute_all(price,
                                                line.order_id.currency_id,
                                                # line.product_uom_qty,
                                                product=line.product_id,
                                                partner=line.order_id.
                                                partner_shipping_id)
                line.update({
                    'price_tax': sum(t.get('amount', 0.0)
                                     for t in taxes.get('taxes', [])),
                    'price_total': taxes['total_included'],
                    'price_subtotal': taxes['total_excluded'],
                })
            elif line.order_id.types == 'projects':
                price = (line.product_uom_qty * line.price_unit) * \
                    (1 - (line.discount or 0.0) / 100.0)
                taxes = line.tax_id.compute_all(price,
                                                line.order_id.currency_id,
                                                # line.product_uom_qty,
                                                product=line.product_id,
                                                partner=line.order_id.
                                                partner_shipping_id)
                line.update({
                    'price_tax': sum(t.get('amount', 0.0)
                                     for t in taxes.get('taxes', [])),
                    'price_total': taxes['total_included'],
                    'price_subtotal': taxes['total_excluded'],
                })
            else:
                price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
                taxes = line.tax_id.compute_all(price,
                                                line.order_id.currency_id,
                                                line.product_uom_qty,
                                                product=line.product_id,
                                                partner=line.order_id.
                                                partner_shipping_id)

                line.update({
                    'price_tax': sum(t.get('amount', 0.0)
                                     for t in taxes.get('taxes', [])),
                    'price_total': taxes['total_included'],
                    'price_subtotal': taxes['total_excluded'],
                })
