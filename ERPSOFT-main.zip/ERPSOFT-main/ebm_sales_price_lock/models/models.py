# -*- coding: utf-8 -*-
# import logging
from odoo import models, fields


class SalesPriceLock(models.Model):
    _inherit = 'sale.order'

    def get_compute_check(self):
        groups = self.env['sale.order'].search([], order='id desc', limit=1)
        check = groups.user_in_price_control

        return check

    user_in_price_control = fields.\
        Boolean(compute='_compute_user_in_price_control')
    created = fields.Boolean(default=False, compute='_compute_created')
    check = fields.Boolean(default=get_compute_check, compute='_compute_check')

    def _compute_user_in_price_control(self):
        group = self.env.user.has_group('ebm_sales_price_lock.'
                                        'group_sale_price_control')
        for rec in self:
            rec.user_in_price_control = group

    def _compute_created(self):
        for rec in self:
            rec.created = rec.id

    def _compute_check(self):
        group = self.env.user.has_group('ebm_sales_price_lock.'
                                        'group_sale_price_control')
        for rec in self:
            rec.check = group
