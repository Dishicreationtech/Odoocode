# -*- coding: utf-8 -*-

from odoo import models, fields, api
# import logging


class AutoGenerateCustomerID(models.Model):
    _inherit = 'res.partner'
    # _description = 'Auto generate Customer ID'

    customer_id = fields.Char(string='Customer ID',
                              readonly=True, copy=False)
    _sql_constraints = [
        ('customer_id_unique', 'unique(customer_id)',
         'The customer id must be unique across all Customer(s)')
    ]

    @api.model
    def create(self, vals):
        # logging.info(self._context)
        # seq_date = None
        # logging.info("after context")
        # logging.info(vals)
        # cus_context = self._context['res_partner_search_mode']
        cus_context = self.env.context.get('res_partner_search_mode')
        if cus_context == 'customer':
            # logging.info("I am customer")
            if 'company_id' in vals:
                vals['customer_id'] = self.env['ir.sequence']. \
                    with_context(force_company=vals['company_id']). \
                    next_by_code('res.partner')
            else:
                vals['customer_id'] = self.env['ir.sequence']. \
                    next_by_code('res.partner')

            # if 'company_id' in vals and \
            # vals.get('customer_id', _('New')) == _('New'):
            #     vals['customer_id'] = self.env['ir.sequence']. \
            #         with_context(force_company=vals['company_id']). \
            #         next_by_code('res.partner') or \
            #         _('New')
            # else:
            #     vals['customer_id'] = self.env['ir.sequence']. \
            #         next_by_code('res.partner') or _('New')
        # if vals.get('customer_id', _('New')) == _('New'):
        #     seq_date = None
        #     vals['customer_id'] = self.env['ir.sequence']. \
        #         next_by_code('res.partner', sequence_date=seq_date) or \
        #         _('New')

        return super(AutoGenerateCustomerID, self).create(vals)
