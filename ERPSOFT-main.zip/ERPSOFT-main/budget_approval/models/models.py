# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api
# from odoo.exceptions import UserError


class BudgetApproval(models.Model):
    _inherit = 'crossovered.budget'

    name = fields.Char('Budget Name', required=True)
    date_from = fields.Date('Start Date', required=True)
    date_to = fields.Date('End Date', required=True)
    budget = fields.Float(string='Budget Notify %', readonly=False)
    notify = fields.Boolean(string='Disable Notification')
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('cancel', 'Cancelled'),
        ('confirm', 'Confirmed'),
        ('validate', 'Validated'),
        ('done', 'Done'),
    ], selection_add=[
        ('approved', 'Approved'),
        ('validate',)
    ], result=[
        ('draft', 'Draft'),
        ('cancel', 'Cancelled'),
        ('confirm', 'Confirmed'),
        ('approved', 'Approved'),
        ('validate', 'Validated'),
        ('done', 'Done'),
    ], string='Status', default=None, index=True, required=False,
        readonly=True, copy=False, tracking=True)
    crossovered_budget_line = fields.One2many('crossovered.budget.lines',
                                              'crossovered_budget_id',
                                              'Budget Lines',
                                              copy=True)
    # test_budget_line = fields.One2many('test.budget.lines',
    #                                           'crossovered_budget_id',
    #                                           'Test Budget Lines',
    #                                           copy=True)
    user_in_budget_approval = fields.\
        Boolean(compute='_compute_check_for_user_budget_approval')

    def _compute_check_for_user_budget_approval(self):
        group = self.env.user.has_group('budget_approval.'
                                        'budget_approval_group')
        logging.info(group)
        for record in self:
            record.user_in_budget_approval = group

    def action_approve_one(self):
        for rec in self:
            rec.state = 'approved'

    @api.model
    def create(self, vals_list):
        # self.state = 'draft'
        vals_list['state'] = 'draft'
        return super(BudgetApproval, self).create(vals_list)


class CrossoverBudgetLineInherit(models.Model):
    _inherit = 'crossovered.budget.lines'

    # budget = fields.Float(string='Budget Notify %', readonly=False)
    # notify = fields.Boolean(string='Disable Notification')
    # percentage = fields.Float(store=True, compute='_compute_percentage',
    #                           string='Achievement',
    #                           help="Comparison between practical and "
    #                                "theoretical amount. This measure tells "
    #                                "you if you are below or over budget.")

    @api.model
    def get_email_to(self):
        # advisor_group = self.env.user. \
        #     has_group("account.group_account_manager")
        # budget_group = self.env.user. \
        #     has_group("budget_approval.budget_approval_group")
        # if advisor_group or budget_group:
        return self.env.user.email
        # return None

    @api.model
    def get_name_of_user(self):
        # advisor_group = self.env.user. \
        #     has_group("account.group_account_manager")
        # budget_group = self.env.user. \
        #     has_group("budget_approval.budget_approval_group")
        # if advisor_group or budget_group:
        return self.env.user.name

        # return None
    @api.model
    def _send_mail_template(self):
        # self.ensure_one()
        # Find the e-mail template
        templ = self.env.ref('budget_approval.budget_email_template')
        logging.info(templ)
        advisor_group = self.env.user. \
            has_group("account.group_account_manager")
        budget_group = self.env.user. \
            has_group("budget_approval.budget_approval_group")
        logging.info("cron job working")

        check = self.search([('crossovered_budget_id.notify', '=', False),
                             ('crossovered_budget_id.state',
                             'in', ['confirm', 'validate'])])
        logging.info(check)
        for rec in check:

            if (rec.percentage >= rec.crossovered_budget_id.budget) and \
               (advisor_group or budget_group):
                logging.info("I am equal or greater")
                logging.info(rec)

                self.env['mail.template'].browse(templ.id). \
                    send_mail(rec.id, force_send=True, raise_exception=True)
