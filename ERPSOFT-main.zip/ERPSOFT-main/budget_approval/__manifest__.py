# -*- coding: utf-8 -*-
{
    'name': "Budget Approval",

    'summary': """
        This module enables the ability to create budget without
        confirmation""",

    'description': """
        This module enables the ability to create budget without confirmation
    """,

    'author': "erpSOFTapp",
    'website': "http://www.erpsoftapp.com",

    'category': 'Uncategorized',
    'version': '13.0.0.0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'account_budget', 'mail', 'contacts', 'account'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'security/security.xml',
        'views/views.xml',
        'data/cron.xml',
        # 'views/templates.xml',
    ],
    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
}
