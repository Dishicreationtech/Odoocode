# -*- coding: utf-8 -*-
from odoo import fields, models
# from odoo.exceptions import UserError, ValidationError

# -----------------------------------Sales Module Extension--------------------------------------------- #


class SalesWorkFlow(models.Model):
    _inherit = 'sale.order'

    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('approve 1', 'Sales Manager'),
        ('approve 2', 'CFO'),
        ('sale', 'Sales Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True, copy=False, index=True, track_visibility='onchange', default='draft')

    # return string

    '''def get_str(self, string):
        total_amount = sum([line.total_amount for line in self.expense_line_ids])
        limit = self.env['expense.monetary.limit'].search(
            ['&', ('company_id', '=', self.company_id.id), ('sequence', '=', string)], limit=1)
        if not limit:
            return string
        if total_amount >= limit.monetary_limit:
            string = int(string) + 1
            return str(string)
        return string'''

    def switch_approval_state(self, str='1'):
        if self.company_id.skip_workflow is False:
            self.action_confirm()
            return True
        if str == '1':
            # self.write({'state': 'approve ' + '1'})
            self.write({'state': 'approve %s' % ('1')})
        elif str == '2':
            # self.write({'state': 'approve ' + '2'})
            self.write({'state': 'approve %s' % ('2')})
        elif str == '3':
            self.button_approve(confirm=True)
        else:
            # self.write({'state': 'approve ' + strs})
            self.write({'state': 'approve %s' % (str)})
        return True

    # @api.multi
    def button_approve_3(self, force=False):
        self.action_confirm()
        self.message_subscribe(partner_ids=[self.env.user.partner_id.id])
        return {}

    # @api.multi
    def button_approve_2(self, force=False):
        d_str = '2'
        self.message_subscribe(partner_ids=[self.env.user.partner_id.id])
        return self.switch_approval_state(d_str)

    # @api.multi
    def button_confirm_quotation(self, force=False):
        # d_str = self.get_str('1')
        self.message_subscribe(partner_ids=[self.env.user.partner_id.id])
        return self.switch_approval_state('1')

    # @api.multi
    def _track_subtype(self, init_values):
        self.ensure_one()
        if 'state' in init_values and self.state == 'sale':
            return self.env.ref('sale.mt_order_confirmed')
            # return 'sale.mt_order_confirmed'
        elif 'state' in init_values and self.state == 'sent':
            return self.env.ref('sale.mt_order_sent')
            # return 'sale.mt_order_sent'
        elif 'state' in init_values and self.state == 'approve 1':
            return self.env.ref('sales_approval_workflow.mt_sale_approved_one')
            # return 'sales_approval_workflow.mt_sale_approved_one'
        elif 'state' in init_values and self.state == 'approve 2':
            return self.env.ref('sales_approval_workflow.mt_sale_approved_two')
            # return 'sales_approval_workflow.mt_sale_approved_two'
        return super(SalesWorkFlow, self)._track_subtype(init_values)
