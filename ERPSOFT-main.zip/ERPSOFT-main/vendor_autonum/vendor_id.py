# -*- coding: utf-8 -*-
# import random
# import string
import logging
from odoo import fields, models, api
# from odoo.exceptions import Warning


class VendorAutonum(models.Model):
    _inherit = "res.partner"
    f_vendor_no = fields.Char('Vendor ID', readonly=True, copy=False)
    _sql_constraints = [
        ('vendoreno_uniq', 'unique(f_vendor_no)',
         'The Vendor Number must be unique accross the vendor(s).'),
    ]

    @api.model
    def create(self, vals):
        logging.info(self._context)
        # supplier_context = self._context['res_partner_search_mode']
        supplier_context = self.env.context.get('res_partner_search_mode')
        if supplier_context == 'supplier':
            vals['f_vendor_no'] = self.env['ir.sequence']. \
                next_by_code('res_partner1')
            logging.info(vals)
        return super(VendorAutonum, self).create(vals)
