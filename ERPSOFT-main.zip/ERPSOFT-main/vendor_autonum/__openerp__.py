# -*- coding: utf-8 -*-
{
    'name': 'Vendor Auto Numbering',
    'version': '13.0.0.0.1',
    'author': 'erpSOFTapp',
    'category': 'Purchase',
    'website': '',
    'description': """
This module enables the ability to have a unique number to Vendor
===============================================================================================================


**Example:**
    """,
    'depends': ["base", "purchase"],
    'demo': [],
    'data': ['sequence.xml', 'vendor_id.xml'],
    'auto_install': False,
    'installable': True,
}
