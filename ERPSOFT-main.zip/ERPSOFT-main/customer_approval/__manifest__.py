# -*- coding: utf-8 -*-
{
    'name': "Customer Approvals",

    'summary': """
       This module enables the approval of a customer from finance""",

    'description': """
       This module enables the approval of a customer from finance
    """,

      'author': 'erpSOFTapp <support@erpsoftapp.com>',
    'website': 'http://www.erpsoftapp.com',

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'CRM',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','crm','account','sale','sales_approval_workflow'],

    # always loaded
    'data': [
         'security/ir.model.access.csv',
       'views/views.xml',
        'views/approval_view.xml',

    ],
    # only loaded in demonstration mode
    'demo': [

    ],
}
