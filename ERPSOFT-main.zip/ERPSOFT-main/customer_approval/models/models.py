# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import datetime
from odoo.exceptions import Warning
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class CurrencyModel(models.Model):
    _inherit = 'res.currency'

    def _get_latest_currency_rate(self):
        self.env.cr.execute("""
                                select a.name, b.name, a.symbol, b.rate
                                from
                                res_currency a,
                                res_currency_rate b
                                where
                                a.id = b.currency_id and a.name = %s
                                    and a.active = 't'
                                        and b.name = (select max(c.name) from res_currency_rate c where b.currency_id = c.currency_id);
                                                """, (self.name,)
                          )
        result = self.env.cr.dictfetchall()

        return result



    def get_current_rate(self):

        return self._get_latest_currency_rate()

class ResPartnerApprovalModel(models.Model):
    _inherit = 'res.partner'

    customer_type_cash = fields.Boolean(string='Cash')
    customer_type_credit = fields.Boolean(string='Credit')
    customer_type_deposit = fields.Boolean(string='Deposit')
    current_customer_status = fields.Char('Current​ ​ Customer​ ​ Status', readonly=True)
    last_approval_date = fields.Datetime('Last Approval Date', readonly=True)
    approval_name = fields.Many2one('res.users', string='Approval ', readonly=True)

    @api.onchange('customer_type_cash')
    def cash_on(self):
        if self.customer_type_cash :
           self.customer_type_credit = False
        self.customer_type_deposit = False

    @api.onchange('customer_type_deposit')
    def deposit_on(self):
        if self.customer_type_deposit:
           self.customer_type_credit = False
        self.customer_type_cash = False

    @api.onchange('customer_type_credit')
    def credit_on(self):
        if self.customer_type_credit :
           self.customer_type_cash = False
        self.customer_type_deposit = False

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals['customer_type_credit'] = True
        res = super(ResPartnerApprovalModel, self).create(vals_list)
        return res
    


class CustomerApproval(models.Model):
    _name = 'customer.approval'
    _inherit = ['mail.thread']
    _description = "Customer Approval"
    _order = 'approval_date desc, id desc'

    @api.constrains('state','customer')
    def _validate_work_hours(self):
        if self.customer:
            customer_app = self.env['customer.approval'].search(
                        [('customer.id', '=', self.customer.id), ('state', '=', 'approved')], order='approval_date desc')


            if self.state  == 'approved' and len(customer_app)>1:
                raise ValidationError("Sorry this customer already has an approved credit")

    def _get_default_currency_id(self):
        # for record in self:
        #     record.currency_id = self.env.user.company_id.currency_id
        #     record.currency_default_id = self.env.user.company_id.currency_id
        return self.env.user.company_id.currency_id.id

    @api.depends('customer')
    def _get_balance(self):
        for rec in self:
            # balance = rec.customer.get_partner_balance_sql()
            balance = rec.customer.credit - rec.customer.debit
            rec.balance = balance

    @api.depends('customer')
    def _get_balance_for_sales(self):
        for rec in self:
            # balance = rec.customer.get_partner_balance_sql()
            balance = rec.customer.credit - rec.customer.debit
            return balance

    def calculate_restated_balance(self,balance):

        rates = self.currency_id.get_current_rate()
        if len(rates) == 0:
            raise UserError(_('Missing currency rate, Please enter currency rate!'))
        rate = rates[0]['rate']
        return  round(balance * rate, 2)

    @api.depends('currency_id')
    def _get_restated_balance(self):
        for rec in self:
            if rec.balance == 0:
                rec.restated_balance = 0
                return
            if not rec.approval_date:
                raise UserError(_('Missing approval date, Please enter approval date!'))
            rates = rec.currency_id.get_current_rate()
            if len(rates) == 0:
                raise UserError(_('Missing currency rate, Please enter currency rate!'))
            rate = rates[0]['rate']
            rec.restated_balance = round(rec.balance * rate, 2)

    
    first_time = fields.Boolean(string='switch', default=False)
    customer = fields.Many2one('res.partner', string='Customer',
                               domain=['|', ('customer_type_credit', '=', True), ('customer_type_deposit', '=', True)],
                               track_visibility='onchange', index=True, required=True
                               )
    approval_date = fields.Datetime('Approval Date', readonly=True, track_visibility='onchange', index=True, copy=False,
                                    default=datetime.datetime.today())
    approver = fields.Many2one('res.users', string='Approver', track_visibility='onchange', index=True,
                               readonly=True, copy=False)
    balance = fields.Monetary('Balance',currency_field='currency_default_id',compute=_get_balance, store=True,)
    restated_balance = fields.Monetary('Restated Balance', currency_field='currency_id',
                                       compute='_get_restated_balance', store=True)
    credit_limit = fields.Monetary('Credit Limit',currency_field='currency_id')
    currency_default_id = fields.Many2one('res.currency', required=True, default=_get_default_currency_id)
    currency_id = fields.Many2one('res.currency', required=True, default=_get_default_currency_id)
    state = fields.Selection([
        ('pending', 'Pending'),
        ('approved', 'Finance Approved'),
        ('rejected', 'Rejected'),
        ('cancelled', 'Cancelled'),
    ], string='Status', readonly=True, index=True, copy=False, default='pending', track_visibility='onchange')
    
    _rec_name = 'customer'

    # @api.multi
    def action_approve_customer(self):
        approval_date= datetime.datetime.today().strftime(DEFAULT_SERVER_DATETIME_FORMAT)
        if self.customer:
            self.customer.write({'last_approval_date': approval_date,
                                 'approval_name': self.env.user.id,
                                 'current_customer_status': 'approved'})
        self.write({'state': 'approved',
                    'approver': self.env.user.id,
                    'approval_date':approval_date})
 

    # @api.multi
    def button_cancel(self):

        if self.customer:
            self.customer.write({
                'current_customer_status': 'rejected'})
            self.write({'state': 'rejected'})

    # @api.multi
    def button_cancel_approve(self):

        if self.customer:
            self.customer.write({
                'current_customer_status': 'cancelled'})
            self.write({'state': 'cancelled'})


    # @api.multi
    def button_draft(self):
        if self.customer:
            self.customer.write({
                'current_customer_status': 'pending'})
            self.write({'state': 'pending'})


class CrmLeadModel(models.Model):
    _inherit = 'crm.lead'

    surety_one = fields.Many2one('res.partner', string='Surety 1', track_visibility='onchange', index=True)
    surety_two = fields.Many2one('res.partner', string='Surety 2', track_visibility='onchange', index=True)

class SalesQuotation(models.Model):
    _inherit = 'sale.order'



    # @api.multi
    def button_confirm_quotation(self):
        # logging.info("I am quotation from customer credit")
        # balance = self.partner_id.credit - self.partner_id.debit
        # logging.info("Partner balance")
        # partner_ledger =  self.env['res.partner']. \
        #         search([('id', '=', self.partner_id.id)])
        #     # logging.info(partner_ledger.balance)
        # bal = 0
        # for partner in partner_ledger:
        
        #     bal = partner.credit - partner.debit
        if  not self.company_id.credit_limit_check:
            return super(SalesQuotation, self).button_confirm_quotation()
        if self.env.user.has_group('sales_approval_workflow.group_approval_2'):
            return super(SalesQuotation, self).button_confirm_quotation()
        if self.partner_id.customer_type_credit:
            payment = self.env['account.payment']. \
                search([('partner_id', '=', self.partner_id.id),
                        ('state', '=', 'posted')])
            logging.info("Payment")
            credit = 0
            debit = 0
            # for pay in payment:
            #     if pay.payment_type == 'inbound':
            #     # if pay.payment_type == 'inbound' and pay.payment_date.year == datetime.datetime.now().year:
            #         logging.info("Credit from payment")
            #         logging.info(pay.amount)
            #         logging.info(pay.payment_date.year)
            #         credit += pay.amount

            # logging.info("Sum total of credit")
            # logging.info(credit)
            # logging.info("Sum total of debit")
            # logging.info(debit)
            # logging.info("End of payment")
            # logging.info("Invoice")
            invoice = self.env['account.move']. \
                search([
                        ('partner_id', '=', self.partner_id.id),
                        ('state', '=', 'posted')
                        ])
            invoices = self.env['account.move.line']. \
                search([('partner_id', '=', self.partner_id.id),
                        # ('state', '=', 'posted')
                        ])
            ins_name = [(ix.move_id.name, ix.move_id.amount_total) for ix in invoices if ix.move_id.state == 'posted']

            credit_ins = [ix.move_id
                          for ix in invoices 
                          if ix.move_id.state == 'posted' and 
                          ix.move_id.type in ['in_invoice', 'entry']
                          ]
            _logger.info("Credit Moves: %s", list(set(credit_ins)))
            credit_res = list(set(credit_ins))

            debit_ins = [ix.move_id
                          for ix in invoices 
                          if ix.move_id.state == 'posted' and 
                          ix.move_id.type == 'out_invoice']
            _logger.info("Debit Moves: %s", list(set(debit_ins)))
            debit_res = list(set(debit_ins))
            for inv in credit_res:
                logging.info("Credit from Invoice")
                logging.info(inv.name)
                logging.info(inv.amount_total)
                logging.info(inv.type)
                credit += inv.amount_total
                # if inv.type in ['in_invoice', 'entry']:
                #     logging.info("Credit from Invoice")
                #     logging.info(inv.amount_total)
                #     logging.info(inv.type)
                #     credit += inv.amount_total

            for inv1 in debit_res:
                logging.info("Debit from invoice")
                logging.info(inv1.amount_total)
                logging.info(inv1.type)
                debit += inv1.amount_total
                # if inv1.type == 'out_invoice':
                #     logging.info("Debit from invoice")
                #     logging.info(inv1.amount_total)
                #     logging.info(inv1.type)
                #     debit += inv1.amount_total
            # logging.info("Sum total of Debit")
            # logging.info(debit)
            # logging.info("End Invoice")
            # logging.info("I am customer with credit check")
            # balance = self.partner_id.credit - self.partner_id.debit
            logging.info("Total Credit")
            logging.info(credit)
            logging.info("Total Debit")
            logging.info(debit)
            # logging.info("Partner balance")
            # partner_ledger =  self.env['account.move.line']. \
            #     search([('partner_id', '=', self.partner_id.id)], order='create_date desc', limit=1)
            # partner_ledger =  self.env['res.partner']. \
            #     search([('id', '=', self.partner_id.id)])
            # # logging.info(partner_ledger.balance)
            # bal = 0
            # for partner in partner_ledger:
            #     logging.info(partner.credit)
            #     bal = partner.credit - partner.debit
            bal = debit - credit
            logging.info(bal)
            logging.info("After Partner balance")
            customer_app = self.env['customer.approval'].search([('customer.id','=',self.partner_id.id),('state','=','approved')], order='approval_date desc', limit=1)
            # logging.info(customer_app)

            if customer_app:
                # logging.info("I am customer app")
                restated_balance = customer_app.calculate_restated_balance(bal)

                if restated_balance >= customer_app.credit_limit:
                    raise UserError(
                        _(
                            'Please contact finance team customer restated balance more than customer credit!'))
                if  customer_app.currency_id.id != self.currency_id.id:
                    raise UserError(_(
                        'Currency on customer approval must be the same with currency on this quotation'))

                # logging.info(customer_app.credit_limit)
                # logging.info(self.amount_total)
                # logging.info("vals before checker")
                base_currency = self.env.user.company_id.currency_id.id
                checker = None
                if customer_app.currency_id.id is base_currency:
                    logging.info("Using balance when currency is "
                                 "the same as base currency")
                    # logging.info(customer_app._get_balance_for_sales())
                    logging.info(bal)
                    checker = (customer_app.credit_limit - bal) - self.amount_total
                else:
                    logging.info("Using restated balance when currency is "
                                 "not the same as base currency")
                    logging.info(restated_balance)
                    checker = (customer_app.credit_limit - restated_balance) - self.amount_total
                
                if bal < 0:
                    if checker < 0:
                            raise Warning(_('This transaction will exceed the customers credit limit, please contact the finance department.'))
                else:
                    logging.info("I am positive balance")
                    if customer_app.credit_limit - self.amount_total < 0:
                        raise Warning(_('This transaction will exceed the customers credit limit, please contact the finance department.'))
                if self.company_id.apply_val_p:
                    date_1 = datetime.datetime.strptime(customer_app.approval_date, "%Y-%m-%d %H:%M:%S")
                    date = date_1 + datetime.timedelta(days=self.company_id.amt_days)
                    if date.date() < datetime.date.today():
                        raise Warning(_('The validity period for this customer has expired, please contact finance to reapprove the customer'))
            else:
                raise UserError(
                    _('Please create and approve customer credit first before confirming quotation for credit customer!'))
        return super(SalesQuotation, self).button_confirm_quotation()
