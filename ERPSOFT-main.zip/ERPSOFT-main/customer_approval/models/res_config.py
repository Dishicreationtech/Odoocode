# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class Invoicing(models.Model):
    _inherit = 'res.company'
    apply_val_p = fields.Boolean("Apply Validity Period", readonly=False)
    credit_limit_check = fields.Boolean("Credit Limit Check", readonly=False)
    amt_days = fields.Integer(readonly=False)


class IvoicingSettings(models.TransientModel):

    _inherit = 'res.config.settings'

    apply_val_p = fields.Boolean(related='company_id.apply_val_p',
                                 string="Apply Validity Period",
                                 readonly=False)
    credit_limit_check = fields.Boolean(related='company_id.'
                                        'credit_limit_check',
                                        string="Credit Limit Check",
                                        readonly=False)
    amt_days = fields.Integer(related='company_id.amt_days', readonly=False)
