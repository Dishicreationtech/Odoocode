# -*- coding: utf-8 -*-
{
    'name': "Store form",

    'summary': """ This module gives ability to process store requisition""",

    'description': """
    """,

    'author': 'erpSOFTapp',
    'website': 'http://www.erpsoftapp.com',

    'license': 'AGPL-3',

    'version': '12.0.0.0.1',


    # any module necessary for this one to work correctly
    'depends': ['base', 'website', 'hr', 'stock', 'purchase', 'documents'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/custom.xml',
        'views/views.xml',
        'views/templates.xml'
    ],

}
