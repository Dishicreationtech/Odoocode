$(document).ready(function () {
    if (location.href.includes("store_request_web")) {
        console.log("This .js file is loaded");

    
        // button = document.getElementById('delete_row"');
        
        $(document).on('click','#delete_row', function(){
            // odoo.define('store_request_web.get_unit_js', function (require) {
            //     "use strict";

                // var ajax = require('web.ajax');
                console.log($('#product_body').children())
                if($('#product_body').children().length==1){
                console.log('Sorry cannot delete last item')
                return
                }
                $(this).parent().parent('tr').remove();
                // var values = {};
                // var get_del, get_row;
                    
                    
             
        });
        
        function addRow() {
            console.log(333)
            /* Declare variables */
            var elements, templateRow, rowCount, row, className, newRow, element;
            var i, s, t;

            /* Get and count all "tr" elements with class="row".    The last one will
             * be serve as a template. */
            if (!document.getElementsByTagName)
                return false; /* DOM not supported */
            elements = document.getElementsByTagName("tr");
            templateRow = null;
            rowCount = 0;
            for (i = 0; i < elements.length; i++) {
                row = elements.item(i);

                // e = get_button.item(i);
                

                /* Get the "class" attribute of the row. */
                className = null;
                if (row.getAttribute)
                    className = row.getAttribute('class')
                if (className == null && row.attributes) {    // MSIE 5
                    /* getAttribute('class') always returns null on MSIE 5, and
                     * row.attributes doesn't work on Firefox 1.0.    Go figure. */
                    className = row.attributes['class'];
                    if (className && typeof(className) == 'object' && className.value) {
                        // MSIE 6
                        className = className.value;
                    }
                }

                /* This is not one of the rows we're looking for.    Move along. */
                if (className != "row_to_clone")
                    continue;

                /* This *is* a row we're looking for. */
                templateRow = row;
                rowCount++;

                ro = null;
                ro = row.getAttribute("name");
                if (ro == null)
                    continue;
                td = ro.split("/");
                if (td.length < 2)
                    continue;
                ro = td[0] + "/" + rowCount.toString() + "/";
                row.setAttribute("name", ro);
                // ele.value = "";
                console.log(ro)

            }
            
            if (templateRow == null)
                return false; /* Couldn't find a template row. */
           

            /* Make a copy of the template row */
            newRow = templateRow.cloneNode(true);
            console.log(newRow);
            
            // get_row = newRow.getElementsByTagName("tr");
            // for (i = 0; i < newRow.length; i++) {
            //     elem = newRow.item(i);
            //     ro = null;
            //     ro = elem.getAttribute("name");
            //     if (ro == null)
            //         continue;
            //     td = ro.split("[");
            //     if (td.length < 2)
            //         continue;
            //     ro = td[0] + "[" + rowCount.toString() + "]";
            //     elem.setAttribute("name", ro);
            //     // ele.value = "";
            //     console.log(ro)
            // }

            get_button = newRow.getElementsByTagName("button");
            for (i = 0; i < get_button.length; i++) {
                e = get_button.item(i);
                rel = null;
                rel = e.getAttribute("name");
                if (rel == null)
                    continue;
                tb = rel.split("/");
                if (tb.length < 2)
                    continue;
                rel = tb[0] + "/" + rowCount.toString() + "/";
                e.setAttribute("name", rel);
                // ele.value = "";
                console.log(rel)
            }

            select_elements = newRow.getElementsByTagName("select");
            for (i = 0; i < select_elements.length; i++) {
                ele = select_elements.item(i);
                sel = null;
                sel = ele.getAttribute("name");
                if (sel == null)
                    continue;
                o = sel.split("/");
                if (o.length < 2)
                    continue;
                sel = o[0] + "/" + rowCount.toString() + "/";
                ele.setAttribute("name", sel);
                // ele.value = "";
                console.log(sel)
            }

            // prodLength = newRow.getElementsByTagName("input");
            // for (i = 0; i < prodLength.length; i++) {
            //     prod = prodLength.item(i);
            //     // product = null;
                
            //     // if (product == null)
            //     //     continue;
            //     prod.value = rowCount.toString();
            //     // ele.value = "";
            //     // console.log(product)
            // }

            /* Change the form variables e.g. price[x] -> price[rowCount] */
            elements = newRow.getElementsByTagName("input");
            for (i = 0; i < elements.length; i++) {
                element = elements.item(i);
                s = null;
                s = element.getAttribute("name");
                if (s == null)
                    continue;
                t = s.split("/");
                if (t.length < 2)
                    continue;
                s = t[0] + "/" + rowCount.toString() + "/";
                element.setAttribute("name", s);
                element.value = "";
                console.log(s)
            }
            // console.log(333)
            /* Add the newly-created row to the table */
            templateRow.parentNode.appendChild(newRow);
            return true;
        }

        document.getElementById('store_addAttachment').addEventListener('click', addRow);
        // el = document.getElementById('delete_row')
        // if(el){
        //     el.addEventListener('click', deleteRow);
        //   }
    }
   
});
