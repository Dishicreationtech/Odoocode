$(document).ready(function () {
    if (location.href.includes("store_request_web")) {// && !location.href.includes("form")) {
        
            odoo.define('store_request_web.get_unit_js', function (require) {

                $(document).on('click','#product', function(){

               var product_uom = $('#Custom_table').data('uom');

                    // $('select[name="product"]').click(function(){
                "use strict";
                        console.log("You clicked me");
                        
                var ajax = require('web.ajax');
                var values = {};
                    
                     console.log(product_uom [51])
                     console.log(product_uom [51])
                     console.log(product_uom [51])
                $('select[name^="name"]').each(function() {
                        console.log(this.value)

                        var index = this.name.split('/')[1]
                        var quan_name = 'unit_of_quantity/'+index+'/'
                        console.log(quan_name)
                        console.log(product_uom[this.value])
                        console.log('in here')
                        $('input[name="'+quan_name+'"]').val(product_uom[this.value]);

                        });

/*                ajax.jsonRpc("/page/store_request_web/get_unit", "call", {
                    "store_product": values
                }).then(function (data) {
                    console.log(data);
                    
                    Object.keys(data).forEach(function(key) {
                        console.log(key);
                        
                        var word ='[name="XXX"]';
                        $(word.replace('XXX', key)).val(data[key]);
                        });
                });*/

            });
        });



        // $('#store_product').click(function(){
        //     odoo.define('store_request.main1', function (require) {
        //         "use strict";

        //         var ajax = require('web.ajax');
        //         console.log('A test');
                

        //         ajax.jsonRpc("/page/store_request_web/get_unit", "call", {
        //             // "store_product[0]": values
        //             "products" : $("#store_product").val()
        //         }).then(function (data) {
        //             var units = data["store_uom"];
        //             console.log(data);
                    
        //             // units.forEach(function(key) {
        //                 // var word ='[name="XXX"]';
        //                 // $(word.replace('XXX', key)).val(data[key]);
        //                 document.getElementById("store_uom").value = units; 
        //                 // });
        //         });

        //     });
        // });
        odoo.define("store_request.get_employee", function (require) {
            $("#store_form_section").click(function(){
                
                "use strict";
                
            var ajax = require("web.ajax");
            ajax.jsonRpc("/page/store_request_web/request", "call", {
            "section" : $("#store_form_section").val()
            }).then(function (data){
                console.log(data);
                
                var request_by = data["requested_by"];
                console.log(request_by);
                
                const parent = document.getElementById("store_form_requested_by");
                while (parent.firstChild) {
                parent.removeChild(parent.firstChild);
                }
                
                request_by.forEach(request_by => {
                const state_option = document.createElement("option");
                
                state_option.setAttribute("value", request_by.id);
                // state_option.setAttribute('text', request_by.name)
                state_option.appendChild(document.createTextNode(request_by.name));
                
                document.getElementById("store_form_requested_by").appendChild(state_option);
                    });
                });
            });
        });


    }
});

