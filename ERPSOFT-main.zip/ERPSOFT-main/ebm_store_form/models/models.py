# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class AddRequisition(models.Model):
    _inherit = 'hr.employee.category'

    display_req = fields.Boolean(store=True)


class CardLine(models.Model):
    _name = 'store.request.line'
    _description = 'Line for store form'

    number = fields.Integer(default=0)
    name = fields.Many2one('product.product', string='Product', required=True)
    description = fields.Char(required=True)
    quantity = fields.Integer(required=True)
    unit_of_quantity = fields.Many2one('uom.uom', related='name.uom_id',
                                       string='Units of Measures',
                                       required=True)

    @api.onchange('name')
    def _onchange_product_id(self):
        self.description = self.name.get_product_multiline_description_sale()


class StoreFormWizard(models.Model):

    _name = 'store.request.wizard'
    _description = "Wizard for store request"

    store_request_id = fields.Many2one('store.request')
    refuse_request = fields.Char()

    def refuse_stock_request(self):
        for record in self:
            record.store_request_id.status = 'refused'
            var_for_pep = record.refuse_request
            record.store_request_id.message_post(
                body=_("Store requisition has been refused."))
            record.store_request_id.message_post(body=_(
                "Reason : {}").format(var_for_pep))


class CreateRequest(models.Model):
    _name = 'store.request'
    _description = 'Store Request'
    _inherit = 'mail.thread'

    reference = fields.Char(default=lambda self: _('New'),)
    request_date = fields.Date(required=True)
    approve_date = fields.Date()

    amount_transfers = fields.Integer(compute='_compute_count_transfers')
    amount_rfq = fields.Integer(compute='_compute_count_rfq')
    transfered = fields.Boolean(default=False, copy=False)
    rfq = fields.Boolean(default=False, copy=False)
    section = fields.Many2one('hr.employee.category',
                              domain=[('display_req', '=', True)],
                              required=True)
    request_by = fields.Many2one(
        'hr.employee', required=True, track_visibility='onchange')
    store_line = fields.One2many('store.request.line', 'number',
                                 string='Store Request', copy=True,
                                 index=True)

    transfer_line = fields.One2many('stock.move.line', 'picking_id',
                                    'Operations without package',
                                    domain=['|', ('package_level_id', '=',
                                                  False),
                                            ('picking_type_entire_packs',
                                             '=', False)])

    submission_type = fields.Selection(
        [('direct', 'Direct'), ('website', 'Website')],
        default='direct', track_visibility='onchange', index=True,
        readonly=True, copy=False
    )

    @api.onchange('section')
    def _onchnage_request_by(self):
        return {'domain': {'request_by': [('category_ids', '=',
                                           self.section.id)]}}

    status = fields.Selection(
        [('draft', 'Draft'),
         ('confirmed', 'Confirmed'),
         ('approved', 'Approved'),
         ('cancelled', 'Cancelled'),
         ('refused', 'Refused')
         ],
        default='draft', track_visibility='onchange', index=True,
        readonly=True, copy=False
    )

    # @api.onchange('section')
    # def onchange_subject_ids(self):
    #     listids=[]
    #     if self.subject_ids:
    #         for each in self.section:
    #             listids.append(each.id)
    #             domain = {'request_by': [('id', 'in', listids)]}
    #             return {'domain': domain, 'value': {'request_by': []}}

    def _compute_count_transfers(self):
        for record in self:
            var1 = self.env['stock.picking'] \
                .search([('store_request', '=', record.id)])
            record.amount_transfers = len(var1.ids)

    def _compute_count_rfq(self):
        for record in self:
            var2 = self.env['purchase.order'] \
                .search([('store_request', '=', record.id)])
            record.amount_rfq = len(var2.ids)

    # @api.multi
    def generate_amount(self):
        pass

    # @api.multi
    def call_popup_refuse_menu(self):
        wizard = self.env['store.request.wizard'].sudo().create(
            {'store_request_id': self.id, 'refuse_request': ''})
        return {
            'name': "Refuse Request",
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'store.request.wizard',
            'res_id': int(wizard.id),
            'view_id': self.env.ref("ebm_store_form.view_store_form_refuse")
            .id,
            'target': 'new',
            "context": {'record': self}
        }

    def create_transfer(self):

        Picking = self.env['stock.picking']
        location = self.env['stock.location'].search(
            [('store_requisition', '=', True)], limit=1)
        type_id = self.env['stock.picking.type'].search(
            [('store_requisition', '=', True)], limit=1)
        if not type_id or not location:
            raise UserError(
                _('No default picking type or location'
                  + 'with store requisition'))
        name = self.env['stock.picking'].default_get(['name'])
        cre = []
        # product_product = self.env['product.product'].search([])
        test = None
        for record in self.store_line:
            get_variants = self.env['product.product'].search(
                [('id', '=', record.name.product_variant_id.id)])
            logging.info(get_variants)
            for rec in get_variants:
                test = rec.id
                cre.append((0, 0, {
                            'product_id': test,
                            'product_uom_qty': record.quantity,
                            'location_id': location.id,
                            'location_dest_id': location.id,
                            'name': 'From Store Requisition',
                            'product_uom': record.unit_of_quantity.id,
                            }))
                # for prod in rec.product_tmpl_id:
                # cre.append((0, 0, {
                #     'product_id': rec.id,
                #     'product_uom_qty': record.quantity,
                #     'location_id': location.id,
                #     'location_dest_id': location.id,
                #     'name': 'From Store Requisition',
                #     'product_uom': record.unit_of_quantity.id,
                # }))

        pick = Picking.create({
            'name': name['name'],
            'location_id': location.id,
            'location_dest_id': location.id,
            'picking_type_id': type_id.id,
            'move_ids_without_package': cre,
            'origin': self.reference,
            'state': 'draft',
            'store_request': self.id,
        })
        self.message_post(body=_('New Transfer %s created ') % (pick.name))
        for r in self:
            r.transfered = True

    def create_rfq(self):
        inv_obj = self.env['purchase.order']
        vendor = self.env['res.partner'].search([('category_id.name', '=',
                                                  'Default Vendor')])

        if not vendor:
            raise UserError(_('Please create a default vendor'))

        name = self.env['purchase.order'].default_get(['name'])
        # product_product = self.env['product.product'].search([])
        cre2 = []
        test = None
        for record in self.store_line:
            logging.info(record.name)
            get_variants = self.env['product.product'].search(
                [('id', '=', record.name.product_variant_id.id)])
            logging.info("after product")

            for rec in get_variants:
                logging.info(rec)
                test = rec.id
                logging.info("after test")
                cre2.append((0, 0, {
                    'product_id': test,
                    'product_qty': record.quantity,
                    'date_planned': self.request_date,
                    'price_unit': record.name.standard_price,

                    'name': record.description,
                    'product_uom': record.unit_of_quantity.id,
                }))
            # logging.info(cre2)
        inv_obj.create({
            'name': name['name'],
            'partner_id': vendor.id,
            'order_line': cre2,
            'requested_by': self.request_by.id,
            'state': 'draft',
            'store_request': self.id,
        })
        logging.info(inv_obj)
        for r in self:
            r.rfq = True

    def reset_request(self):
        for record in self:
            record.status = 'draft'

    def confirm_stock_request(self):
        for record in self:
            record.status = 'confirmed'

    def approve_stock_request(self):
        for record in self:
            record.approve_date = fields.Date.context_today(record)
            record.status = 'approved'

    @api.model
    def create(self, vals_list):
        vals_list['request_date'] = fields.Date.context_today(self)
        vals_list['reference'] = self.env['ir.sequence'].\
            next_by_code('referen')
        res = super(CreateRequest, self).create(vals_list)
        logging.info(self.request_by.name)
        return res

    # @api.multi
    def name_get(self):
        super(CreateRequest, self).name_get()
        data = []
        for record in self:
            display_value = record.reference or ""
            data.append((record.id, display_value))
        return data

    def open_transfer(self):
        for rec in self:
            picking = self.env['stock.picking'].sudo().search(
                [('store_request', '=', rec.id)], limit=1)
            return {
                'name': 'Transfers',
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'stock.picking',
                # 'view_id': record.picking_id.id,
                'context': {},

                'res_id': picking.id,
            }

    def open_rfq(self):
        for rec in self:
            rfq = self.env['purchase.order'].sudo().search(
                [('store_request', '=', rec.id)], limit=1)
            return {
                'name': 'RFQ',
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'purchase.order',
                # 'view_id': record.picking_id.id,
                'context': {},

                'res_id': rfq.id,
            }


class AddStoreInLocation(models.Model):
    _inherit = "stock.location"

    store_requisition = fields.Boolean()


class AddStoreInType(models.Model):
    _inherit = "stock.picking.type"

    store_requisition = fields.Boolean()


class AddCounterFromButtonTransfers(models.Model):
    _inherit = 'stock.picking'

    store_request = fields.Many2one(
        'store.request', required=False, copy=False)


class AddCounterFromButtonRFQ(models.Model):
    _inherit = 'purchase.order'

    requested_by = fields.Many2one('hr.employee')
    store_request = fields.Many2one(
        'store.request', required=False, copy=False)
