# -*- coding: utf-8 -*-
import json
import logging
from datetime import datetime
from odoo import http
_logger = logging.getLogger(__name__)


class StoreForm(http.Controller):
    @http.route('/page/store_request_web', auth='public', website=True)
    def index(self, **kw):
        section = http.request.env['hr.employee.category'].sudo().\
            search([('display_req', '=', True)])
        # requested_by = http.request.env['hr.employee'].sudo().\
        #     search([('category_ids', '=', 'section')])
        # requested_by = http.request.env['hr.employee'].sudo().\
        #     search([])
        company = http.request.env['res.company']\
            ._company_default_get('ebm_store_form')
        address = http.request.env['res.company']._compute_address()
        reque = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        product = http.request.env['product.product'].sudo().search([])
        product_uom = {prod.id: prod.uom_id.name for prod in product}
        varibles = {'section': section,
                    'reque': reque, 'product': product, 'company': company,
                    'address': address, 'product_uom': json.dumps(product_uom)}
        return http.request.render('ebm_store_form.store_request_web',
                                   varibles)

    @http.route('/page/store_request_web/request', type='json', auth='public',
                website=True)
    def get_employee(self, **kw):
        '''
        Returns the employees in a given category.
        '''
        section = kw.get("section")
        # logging.info(section)
        if not section.isdigit():
            return {'requested_by': []}

        if section:
            section = int(section)
            # logging.info(section)
            requested_by = http.request.env["hr.employee"].sudo().search(
                [("category_ids.id", "=", section)]
            )
            if requested_by:
                response = list()
                for state in requested_by:
                    response.append({'id': state.id, 'name': state.name})
                    # logging.info(response)
                return {'requested_by': response}
            # else:
        return {}

    @http.route('/page/store_request_web/get_unit', type='json',
                auth='public', website=True)
    def get_unit(self, **kw):
        product_id = kw['store_product']
        i = 0
        data = {}
        for key in product_id:
            answer = http.request.env['product.product'].sudo(). \
                search([('id', '=', int(product_id[key]))])
            for record in http.request.env['uom.uom']. \
                    sudo().search([('id', '=', answer.uom_id.id)]):
                data['unit_of_quantity/{}/'.format(i)] = record.name
            i += 1

        return data

    # @http.route('/page/store_request_web/get_unit', type='json',
    #             auth='public', website=True)
    # def get_unit(self, **kw):
    #     logging.info(kw)
    #     product_id = kw['products']
    #     answer = http.request.env['product.template'].sudo(). \
    #         search([('id', '=', int(product_id))], limit=1)

    #     return {'store_uom': answer.uom_id.name}
    def parse_dict(self, kw):
        # logging.info(kw)
        arr = [{} for i in range(100)]

        for k, v in kw.items():
            # logging.info(k)
            # logging.info(v)
            if '/' in k:
                word = k.split('/')
                # logging.info(word)
                arr[int(word[1])][word[0]] = v

        return [(0, 0, x) for x in arr if bool(x) is True]

    @http.route('/page/store_submit_form', auth='user', website=True)
    def submit_form(self, **kw):
        # logging.info(kw)
        lines = self.parse_dict(kw)
        # logging.info(test)

        section = kw['section']
        employee_id = kw['requested_by']
        date = kw['date']
        # product_id = kw['product']
        # logging.info(product_id)
        # description = kw['desc']
        # quantity = kw['quantity']
        # uom_id = kw['uom']
        # lines = [(0, 0, {
        #     'name': int(product_id),
        #     'description': description,
        #     'quantity': int(quantity),
        #     'unit_of_quantity': uom_id
        # })]
        exp_sheet_model = http.request.env['store.request']
        # date = datetime.strptime(date, '%Y-%m-%d %H:%M:%S').date()
        # date = datetime.datetime.now().strftime("%m-%d-%Y %H:%M:%S")
        # test = self.parse_dict(kw)
        # logging.info(test)
        data = {
            'section': section,
            'request_by': employee_id,
            'request_date': date,

            'store_line': lines,
            # 'status': 'draft',
            'submission_type': 'website'
        }
        # logging.info(data)
        ret = exp_sheet_model.sudo().create(data)
        if ret:
            ret.message_post(body=kw['notes'])

        logging.info(ret)

        http.request.env.cr.commit()
        return http.request.render('ebm_store_form.form_thanks')
