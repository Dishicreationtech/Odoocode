# -*- coding: utf-8 -*-

# import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class SalesDiscountApproval(models.Model):
    _name = 'sales.discount.approval'
    _description = 'Sales Discount Approval'
    _inherit = 'mail.thread'
    _rec_name = 'discount_reference'
    # _description = 'sales_discount_approval.sales_discount_approval'

    discount_reference = fields.Char(
        required=True,
        copy=False,
        readonly=True,
        index=True,
        default=lambda self: _('New'),
    )
    discount = fields.Integer(required=True, string="Discount(%)")
    salesperson = fields.Many2one('res.users', required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed')
    ], string="Status", default="draft",
        readonly=True, track_visibility='onchange', copy=False)
    check_for_confirm = fields.Boolean(default=False, readonly=False)

    @api.model
    def create(self, vals_list):
        vals_list['discount_reference'] = self.env['ir.sequence'].\
            next_by_code('refSD')
        res = super(SalesDiscountApproval, self).create(vals_list)
        return res

    def action_confirm(self):
        for rec in self:
            rec.state = 'confirmed'
            rec.check_for_confirm = True
            # logging.info(rec.check_for_confirm)

    @api.onchange('salesperson')
    def onchange_many2onefield(self):
        """
        :param self:
        :return:
        """

        # users = self.env.ref('base.module_category_sales_sales')
        sales_groups = self.env['res.groups'].sudo()
        sales_cat = self.env['ir.module.category'].sudo()
        sales_cat_search = sales_cat.search([('name', '=', 'Sales')])
        sales_group_search = sales_groups. \
            search([('category_id', 'in', sales_cat_search.ids)])
        # user_groups.search([('group_ids', 'in', sales_group_search.ids)])

        # logging.info(sales_group_search)
        # for ai in sales_group_search:
        #     user_groups.extend(ai.id)
        #     logging.info(ai.name)
        return {
            'domain': {
                'salesperson': [
                    ('groups_id', 'in', sales_group_search.ids)]}}


class SalesDiscountApprovalWork(models.Model):
    _inherit = "sale.order"

    def button_confirm_quotation(self, force=False):
        # logging.info('I am confrim Quotation')
        get_confirm_sales_discount = self.env['sales.discount.approval']
        for rec in self:
            # get_create_user = rec.create_uid
            # logging.info(rec.create_uid)
            search_confirm_discount_user = get_confirm_sales_discount. \
                search([('salesperson', '=', self.env.user.id),
                        ('check_for_confirm', '=', True)])
            # logging.info(search_confirm_discount_user.salesperson.name)
            # logging.info(search_confirm_discount_user.discount)
            # logging.info(rec.order_line.discount)
            if not self.env.user.has_group('sales_approval_workflow.'
                                           'group_approval_2'):
                # logging.info("IM not a approval 2 group")
                for od in rec.order_line:
                    # logging.info(od.discount)
                    if od.discount > search_confirm_discount_user.discount:
                        # logging.info('Im greater than')
                        raise UserError(_("This quotation has a discount that"
                                          "is higher than the salesperson "
                                          "approved limit. This quotation can "
                                          "only be approved by the General "
                                          "Manager / Operations Manager"))

        res = super(SalesDiscountApprovalWork, self).\
            button_confirm_quotation()
        return res
