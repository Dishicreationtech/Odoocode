from odoo import models, fields, api, _
import odoo.addons.decimal_precision as dp

class CustomerStatement(models.Model):
    _inherit = 'hr.contract'
    a_1 = fields.Float("Allowance 1", digits=dp.get_precision('Custom1'))
    a_2 = fields.Float("Allowance 2", digits=dp.get_precision('Custom1'))
    a_3 = fields.Float("Allowance 3", digits=dp.get_precision('Custom1'))
    a_4 = fields.Float("Allowance 4", digits=dp.get_precision('Custom1'))
    d_1 = fields.Float("Deduction 1", digits=dp.get_precision('Custom1'))
    d_2 = fields.Float("Deduction 2", digits=dp.get_precision('Custom1'))
    d_3 = fields.Float("Deduction 3", digits=dp.get_precision('Custom1'))
    d_4 = fields.Float("Deduction 4", digits=dp.get_precision('Custom1'))






