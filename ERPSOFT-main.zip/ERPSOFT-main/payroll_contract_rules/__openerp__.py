{
    'name': 'Payroll Contract Rules',
    'version': '1.0',
    'author': 'erpSOFTapp',
    'category': 'HR',
    'website': 'https://www.erpsoftapp.com',
    'description': """
This module enables the ability to create additional payoll salary rules for allowances and deduction specific to each employee
===============================================================================================================================


**Example:**
    """,
    'depends': ["hr","hr_contract"],
    'demo': [],
    'data': ['contract_rules.xml', ],
    'auto_install': False,
    'installable': True,
}
