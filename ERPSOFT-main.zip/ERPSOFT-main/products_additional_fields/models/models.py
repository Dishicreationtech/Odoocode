# -*- coding: utf-8 -*-

from odoo import models, fields


class ProductsAdditionalFields(models.Model):
    _inherit = 'product.template'
    _description = 'To add additional fields to product template'

    length = fields.Float(digits=(12, 2))
    width = fields.Float(digits=(12, 2))
    height = fields.Float(digits=(12, 2))
    sqm = fields.Float('SQM', digits=(12, 2))
