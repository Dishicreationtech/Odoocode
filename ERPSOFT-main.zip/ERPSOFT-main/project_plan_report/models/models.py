# -*- coding: utf-8 -*-
# import logging
from datetime import date
from odoo import models, fields, api, _
# from odoo.exceptions import UserError


class ProjectPlanReport(models.Model):
    _name = 'project.plan.report'
    _description = 'model for work in progress'
    _inherit = 'mail.thread'
    _rec_name = 'project_ref'

    project_ref = fields.Char(
        required=True,
        copy=False,
        readonly=True,
        index=True,
        default=lambda self: _('New'),
    )
    start_date = fields.Date(states={'confirm': [('readonly', True)]})
    end_date = fields.Date(states={'confirm': [('readonly', True)]})
    work_type = fields.Selection([
        ('aluminium', 'Aluminium Work Plan'),
        ('curtain', 'Curtain Wall Work Plan'),
    ], 'Work Plan', default="aluminium", states={'confirm':
                                                 [('readonly', True)]})
    state = fields.Selection([
        ('draft', 'DRAFT'),
        ('confirm', 'CONFIRMED'),
    ], 'Status', default='draft', readonly=True,
        track_visibility="onchange", states={'confirm': [('readonly', True)]},
        copy=False)
    boq = fields.Integer(string='BOQ(%)',
                         states={'confirm': [('readonly', True)]})
    check_measure = fields.Integer(string='Check Measuremnt(%)',
                                   states={'confirm': [('readonly', True)]})
    sub_measure = fields.Integer(string='Sub-frame Measurement(%)',
                                 states={'confirm': [('readonly', True)]})
    prod_measure = fields.Integer(string='Production Measurement(%)',
                                  states={'confirm': [('readonly', True)]})
    add_work = fields.Integer(string='Additional Work(%)',
                              states={'confirm': [('readonly', True)]})
    receive_material = fields.Integer(string='Receive Material On Site(%)',
                                      states={'confirm': [('readonly', True)]})
    installation = fields.Integer(string='Installation(%)',
                                  states={'confirm': [('readonly', True)]})
    work_completed = fields.Integer(string='Work Completed(%)',
                                    states={'confirm': [('readonly', True)]})
    mullum_measure = fields.Integer(string='Mullum/Tranzum Measurement(%)',
                                    states={'confirm': [('readonly', True)]})

    def action_confirm(self):
        for record in self:
            record.state = 'confirm'

    @api.model
    def create(self, vals_list):
        vals_list['project_ref'] = self.env['ir.sequence'].\
            next_by_code('project_reference')
        res = super(ProjectPlanReport, self).create(vals_list)
        return res


class ProjectPlanInherit(models.Model):
    _inherit = 'project.project'

    colour = fields.Char(string='Colour Of Aluminium')
    type_of_glass = fields.Char()
    date_today = fields.Date(string='Date', default=date.today())
    aluminium = fields.Boolean(string='Aluminium Work Plan', readonly=False)
    curtain = fields.Boolean(string='Curtain Wall Work Plan', readonly=False)


class ProjectTaskInherit(models.Model):
    _inherit = 'project.task'

    aluminium = fields.Boolean(related='project_id.aluminium',
                               string='Aluminium Work Plan', readonly=False)
    curtain = fields.Boolean(related='project_id.curtain',
                             string='Curtain Wall Work Plan', readonly=False)
    project_aluminium_line = fields.One2many('project.aluminium.line',
                                             'project_task_id')
    project_curtain_line = fields.One2many('project.curtain.line',
                                           'project_task_id')


class ProjectSaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    def _timesheet_create_task_prepare_values(self, project):
        self.ensure_one()
        planned_hours = self._convert_qty_company_hours(self.company_id)
        sale_line_name_parts = self.name.split('\n')
        title = sale_line_name_parts[0] or self.product_id.name
        description = '<br/>'.join(sale_line_name_parts[1:])
        get_boq_val = []

        for num_qty in range(int(self.product_uom_qty)):
            get_boq_val.append((0, 0, {'boq_length': self.width,
                                       'boq_height': self.height,
                                       }))

        if self.product_uom.name == 'NR':
            return {
                'name': title if project.sale_line_id else
                '%s: %s' % (self.order_id.name or '', title),
                'planned_hours': planned_hours,
                'partner_id': self.order_id.partner_id.id,
                'email_from': self.order_id.partner_id.email,
                'description': description,
                'project_id': project.id,
                'project_aluminium_line': get_boq_val,
                'sale_line_id': self.id,
                'company_id': project.company_id.id,
                'user_id': False,
            }

        if self.product_uom.name == 'SQM':
            return {
                'name': title if project.sale_line_id else
                '%s: %s' % (self.order_id.name or '', title),
                'planned_hours': planned_hours,
                'partner_id': self.order_id.partner_id.id,
                'email_from': self.order_id.partner_id.email,
                'description': description,
                'project_id': project.id,
                'project_curtain_line': get_boq_val,
                'sale_line_id': self.id,
                'company_id': project.company_id.id,
                'user_id': False,
            }
        return super(ProjectSaleOrderLine, self). \
            _timesheet_create_task_prepare_values(project)
