# -*- coding: utf-8 -*-
import logging
# from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class AluminiumWorkLine(models.Model):
    _name = 'project.curtain.line'
    _description = 'Line for Curtain tab'

    proj_name = fields.Char(string='Project', compute='_compute_project_name',
                            store=True)
    proj_manager = fields.Char(string='Project Manager',
                               compute='_compute_project_manager')
    project_task_id = fields.Many2one('project.task', string='Task')
    boq_length = fields.Float()
    boq_height = fields.Float()
    boq = fields.Char(string='BOQ(mm)', compute='_compute_boq', store=True)
    check_measure_length = fields.Float()
    check_measure_height = fields.Float()
    check_measure = fields.Char(string='Check Measurement (mm)',
                                compute='_compute_check_measure', store=True)
    # subframe_length = fields.Integer()
    # subframe_height = fields.Integer()
    # subframe = fields.Char(string='Sub-frame Measurement(mm)',
    #                        compute='_compute_subframe')
    mullum_length = fields.Float()
    mullum_height = fields.Float()
    mullum = fields.Char(string='Mullum / Tranzum Measurement(mm)',
                         compute='_compute_mullum', store=True)
    production_length = fields.Float()
    production_height = fields.Float()
    production = fields.Char(string='Production Measurement(mm)',
                             compute='_compute_production', store=True)
    add_work = fields.Char(string='Additional Work(mm)',
                           compute='_compute_add_work', readonly=True,
                           store=True)
    receive_material = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No'),
    ], 'Receive Material On Site', default="no")
    installation = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No'),
    ], default="no")
    work_completed = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No'),
    ], default="no", compute='_compute_work_completed', readonly=True,
        store=True)
    work_in_progress = fields.Integer(readonly=True,
                                      compute='_compute_work_progress',
                                      store=True)
    silicone = fields.Boolean(string='Silicone inside and acrylic outside',
                              readonly=False)
    rubber = fields.Boolean(string='Rubber gasket are well correct',
                            readonly=False)
    window = fields.Boolean(string='The Window is locked well', readonly=False)
    everything = fields.Boolean(string='Everything is fine', readonly=False)
    comments = fields.Char()

    @api.model
    def fields_get(self, field=None):
        fields_to_hide = ['boq_length', 'boq_height', 'check_measure_length',
                          'check_measure_height', 'mullum_length',
                          'mullum_height', 'production_length', 'window',
                          'production_height', 'silicone', 'rubber',
                          'everything', 'comments', 'project_task_id']
        res = super(AluminiumWorkLine, self).fields_get(field)
        for my_field in fields_to_hide:
            if res[my_field]:
                res[my_field]['selectable'] = False

        return res

    @api.depends('project_task_id')
    def _compute_project_name(self):
        proj_name = None
        for rec in self:
            for record in rec.project_task_id:
                proj_name = record.project_id.name
            rec.proj_name = proj_name

    @api.depends('project_task_id')
    def _compute_project_manager(self):
        proj_manager = None
        for rec in self:
            for record in rec.project_task_id:
                proj_manager = record.project_id.user_id.name
            rec.proj_manager = proj_manager

    # @api.onchange('boq')
    @api.depends('boq_length', 'boq_height')
    def _compute_boq(self):
        for record in self:
            boq_add = str(record.boq_length) + " X " + str(record.boq_height)
            record.update({
                'boq': boq_add
            })
            logging.info(record.boq)

    @api.depends('check_measure_length', 'check_measure_height')
    def _compute_check_measure(self):
        for record in self:
            check_add = str(record.check_measure_length) + " X " + \
                str(record.check_measure_height)
            record.update({
                'check_measure': check_add
            })
            logging.info(record.check_measure)

    @api.depends('boq_length', 'boq_height', 'check_measure_length',
                 'check_measure_height', 'production_length',
                 'production_height')
    def _compute_add_work(self):
        add_work = None
        add_length = None
        add_height = None
        for record in self:
            if record.production_length > 0 and record.production_height > 0:
                add_length = record.check_measure_length - record.boq_length
                add_height = record.check_measure_height - record.boq_height
                # if (add_length and add_height) > 0:
                # time.sleep(5)
                work = "{0:.2f} X {1:.2f}"
                add_work = work.format(add_length, add_height)
            record.add_work = add_work

    @api.depends('mullum_length', 'mullum_height',
                 'check_measure_length', 'check_measure_height')
    def _compute_mullum(self):
        for record in self:
            mullum_length = record.mullum_length
            mullum_height = record.mullum_height
            mullum_add = str(mullum_length) + " X " + str(mullum_height)
            if mullum_length > record.check_measure_length or \
               mullum_height > record.check_measure_height:
                raise UserError(_("The Mullum/Tranzum Measurement cannot "
                                  "be higher than the Check Measurement. "
                                  "Confirm the values entered."))
            record.update({
                'mullum': mullum_add
            })

    @api.depends('production_length', 'production_height',
                 'mullum_length', 'mullum_height')
    def _compute_production(self):
        for record in self:
            prod_length = record.production_length
            prod_height = record.production_height
            production_add = str(prod_length) + " X " + str(prod_height)
            # if record.subframe_length and record.subframe_height:
            #     if prod_length > record.subframe_length or \
            #         prod_height > record.subframe_height:
            #         raise UserError(_("The Production Measurement cannot be "
            #                         "higher than the Sub-frame Measurement. "
            #                         "Confirm the values entered."))

            if record.mullum_length and record.mullum_height:
                if prod_length > record.mullum_length or \
                   prod_height > record.mullum_height:
                    raise UserError(_("The Production Measurement cannot be "
                                      "higher than the Mullum/Tranzum "
                                      "Measurement. Confirm the values "
                                      "entered."))
            record.update({
                'production': production_add
            })

    @api.depends('silicone', 'rubber', 'window', 'everything')
    def _compute_work_completed(self):
        for rec in self:
            if (rec.silicone and rec.rubber and rec.window and
               rec.everything) is True:
                rec.work_completed = 'yes'
            else:
                rec.work_completed = 'no'

    @api.depends('boq_length', 'boq_height', 'check_measure_length',
                 'check_measure_height', 'mullum_length',
                 'mullum_height', 'production_length', 'production_height',
                 'work_completed', 'installation', 'receive_material',
                 'add_work')
    def _compute_work_progress(self):
        alum_work_progress = self.env['project.plan.report'].search([
            ("work_type", "=", "curtain")])
        # today = date.today()

        # get_active_work = alum_work_progress. \
        #     filtered(lambda x: x.start_date and x.end_date and
        #              x.start_date < today and
        #              x.end_date > today)
        # total_work_progress = 0

        for record in self:
            for line in record.project_task_id.project_id:
                proj_date = line.date_today
                logging.info(proj_date)
                get_active_work = alum_work_progress. \
                    filtered(lambda x, pd=proj_date: x.start_date and
                             x.end_date and x.start_date <= pd and
                             x.end_date >= pd)
                if record.boq_length > 0 and record.boq_height > 0:
                    record.work_in_progress = get_active_work.boq

                if record.check_measure_length > 0 and \
                        record.check_measure_height > 0:
                    record.work_in_progress = get_active_work.check_measure

                if record.mullum_length > 0 and record.mullum_height > 0:
                    record.work_in_progress = get_active_work.mullum_measure

                if record.production_length > 0:
                    record.work_in_progress = get_active_work.prod_measure

                if record.add_work:
                    record.work_in_progress = get_active_work.add_work

                if record.receive_material == 'yes':
                    logging.info('I am yes')
                    record.work_in_progress = get_active_work.receive_material

                if record.installation == 'yes':
                    record.work_in_progress = get_active_work.installation

                if record.work_completed == 'yes':
                    # logging.info('I am yes')
                    record.work_in_progress = get_active_work.work_completed
                # else:
                #     record.work_in_progress = None

            # record.update({
            #     'work_in_progress': total_work_progress
            # })

        logging.info(get_active_work.project_ref)
