# -*- coding: utf-8 -*-
{
    'name': "Project Plan Report",

    'summary': """
        This module gives the ability to generate reports""",

    'description': """
        This module gives the ability to generate reports
    """,

    'author': "erpSOFTapp",
    'website': "http://www.erpsoftapp.com",

    # for the full list
    'category': 'Uncategorized',
    'version': '13.0.0.0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'project', 'sale', 'sale_timesheet',
                'custom_sales_order_qweb_report'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
}
