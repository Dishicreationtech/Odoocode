# -*- coding: utf-8 -*-

from odoo import models, fields


class ProjectOverviewProject(models.Model):
    _inherit = 'project.project'

    note = fields.Text()
