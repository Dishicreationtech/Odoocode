# -*- coding: utf-8 -*-
{
    'name': "Project Overview",

    'summary': """
        This module gives the ability to add additional field on project""",

    'description': """
        This module gives the ability to add additional field on project
    """,

    'author': "erpSOFTapp",
    'website': "http://www.erpsoftapp.com",

    # for the full list
    'category': 'Uncategorized',
    'version': '13.0.0.0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'project'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        # 'views/templates.xml',
    ],
    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
}
