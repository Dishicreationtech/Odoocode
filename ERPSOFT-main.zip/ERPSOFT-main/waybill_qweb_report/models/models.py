# -*- coding: utf-8 -*-
import logging
from collections import namedtuple
from dateutil.relativedelta import relativedelta
from odoo import models, fields, api
from odoo.tools import float_compare

# from odoo.exceptions import UserError


class WaybillQwebReport(models.Model):
    _inherit = 'stock.picking'
    _description = 'waybill qweb report'

    man_order_no = fields.Char(string='Manufacturing Order No')
    vehicle_no = fields.Char()
    site = fields.Char()
    total = fields.Float(compute='_compute_total_all')
    dispatch = fields.Many2one('hr.employee',
                               domain=[('category_ids.name', '=',
                                        'Dispatch User')])
    approved = fields.Many2one('hr.employee',
                               domain=[('category_ids.name', '=',
                                        'Dispatch User')])
    driver_customer = fields.Char(string='Driver/Customer ')
    non_prof_driver_customer = fields.Char(string='Driver/Customer')
    manager = fields.Many2one('hr.employee',
                              domain=[('category_ids.name', '=',
                                       'Dispatch User')])
    non_prof_manager = fields.Many2one('hr.employee', string='Manager ',
                                       domain=[('category_ids.name', '=',
                                                'Dispatch User')])
    store_keeper = fields.Many2one('hr.employee',
                                   domain=[('category_ids.name', '=',
                                            'Dispatch User')])
    quality = fields.Many2one('hr.employee',
                              domain=[('category_ids.name', '=',
                                       'Dispatch User')])

    @api.depends('move_lines.quantity_done')
    def _compute_total_all(self):
        """
        Compute the total amounts of the done quantity.
        """
        for rec in self:
            amount_total = 0.0
            for line in rec.move_lines:
                amount_total += line.quantity_done
            rec.update({
                'total': amount_total
            })

    # def button_validate(self):
    #     self.ensure_one()
    #     res = super(WaybillQwebReport, self).button_validate()
    #     if self.backorder_id.id:
    #         back = self.backorder_id.move_ids_without_package
    #         for rec, ix in zip(self.move_ids_without_package, back):
    #             logging.info("Current Done")
    #             logging.info(rec.quantity_done)
    #             logging.info("Initial Demand")
    #             logging.info(rec.initial_demand)
    #             # back_ids = self.env['stock.picking'].search([])
    #             # logging.info("Initial Doc done")
    #             # logging.info(self.backorder_id.quantity_done)
    #             logging.info("Initial Doc done")
    #             logging.info(ix.quantity_done)
    #             logging.info("Initial Balance")
    #             logging.info(ix.balance)
    #             ## Commented by Maulik.
    #             """rec.balance = rec.product_uom_qty - rec.product_uom_qty \
    #                 if rec.quantity_done == 0.0 \
    #                 else ix.balance - rec.quantity_done"""
    #             rec.balance = rec.initial_demand - ix.quantity_done
    #             print("rec.balance if................................................",rec.balance)
    #             print("rec.initial_demand.............................................................",rec.initial_demand)
    #             print("rec.quantity_done........................................................",ix.quantity_done)
    #             # rec.balance = rec.product_uom_qty - rec.product_uom_qty \
    #             #     if rec.quantity_done == 0.0 else rec.initial_demand - \
    #             #     (ix.quantity_done + rec.quantity_done)
    #     else:
    #         for rec in self.move_ids_without_package:
    #             logging.info("Current Done")
    #             logging.info(rec.quantity_done)
    #             logging.info("Initial Demand")
    #             logging.info(rec.initial_demand)
    #             ## Commented by Maulik.
    #             """rec.balance = rec.product_uom_qty - rec.product_uom_qty \
    #                 if rec.quantity_done == 0.0 \
    #                 else rec.initial_demand - rec.quantity_done"""
    #             rec.balance = rec.initial_demand - rec.quantity_done
    #             print("rec.balance else.....................................................",rec.balance)
    #             print("rec.initial_demand.............................................................",rec.initial_demand)
    #             print("rec.quantity_done........................................................",rec.quantity_done)

            # for rec in self.move_lines:
        #     logging.info("Current Done")
        #     logging.info(rec.quantity_done)
        #     logging.info("Initial Demanf")
        #     logging.info(rec.initial_demand)
        #     if self.backorder_id.id:
        #         # back_ids = self.env['stock.picking'].search([])
        #         # logging.info("Initial Doc done")
        #         # logging.info(self.backorder_id.quantity_done)
        #         for ix in self.backorder_id.move_ids_without_package:
        #             logging.info("Initial Doc done")
        #             logging.info(ix.quantity_done)
        #             rec.balance = rec.initial_demand - \
        #                 (ix.quantity_done + rec.quantity_done)
        #     else:
        #         rec.balance = rec.product_uom_qty - rec.product_uom_qty \
        #             if rec.quantity_done == 0.0 \
        #                 else rec.initial_demand - rec.quantity_done

        # no_back_ids = self.env['stock.picking'].search([])
        # for rec in self:
        #     # logging.info(rec.backorder_id.id)
        #     get_no_back_ids = no_back_ids.filtered(lambda l, rc=rec: l.id is
        #                                            rc.backorder_id.id)
        #     # logging.info(get_no_back_ids)
        #     get_mapped = get_no_back_ids.mapped('move_lines')
        #     for no_back_move in rec.move_lines:
        #         if no_back_move.backorder_id.id is False:
        #             # logging.info(no_back_move.quantity_done)
        #             if no_back_move.quantity_done == 0.0:
        #                 no_back_move.balance = \
        #                     no_back_move.product_uom_qty - \
        #                     no_back_move.product_uom_qty
        #             else:
        #                 no_back_move.balance = no_back_move.initial_demand -\
        #                     no_back_move.quantity_done
        #             # if no_back_move.quantity_done > no_back_move.balance:
        #             #     raise UserError(_('Done Quantity '
        #             #                       'cannot exceed balance'))
        #             # logging.info("No Back")
        #     if get_mapped:
        #         for move, idx in zip(rec.move_lines, get_mapped):
        #             # logging.info(get_mapped.quantity_done)

        #             if move.backorder_id:
        #                 # logging.info(idx.balance)
        #                 # logging.info(move.quantity_done)
        #                 # move.balance = move.initial_demand - \
        #                 #     (idx.quantity_done + move.quantity_done)
        #                 # for idx in get_mapped:
        #                 if move.quantity_done == 0.0:
        #                     # logging.info("Quantity is 0")
        #                     # logging.info(move.initial_demand)
        #                     # logging.info(idx.quantity_done)
        #                     # logging.info(move.product_uom_qty)
        #                     # move.balance = move.initial_demand - \
        #                     #     (idx.quantity_done + move.product_uom_qty)
        #                     move.balance = move.product_uom_qty - \
        #                         move.product_uom_qty
        #                 else:
        #                     logging.info(move.initial_demand)
        #                     logging.info(idx.balance)
        #                     logging.info(move.quantity_done)
        #                     # move.balance = move.initial_demand - \
        #                     #     (idx.quantity_done + move.quantity_done)
        #                     move.balance = idx.balance - move.quantity_done
        #                 # if move.quantity_done > move.balance:
        #                 #     raise UserError(_('Done Quantity cannot '
        #                 #                       'exceed balance'))
        #                 # move.balance = move.initial_demand - \
        #                 #     (idx.quantity_done + move.quantity_done)
        #                 # logging.info("back")

        
        #return res

    @api.model
    def create(self, vals):

        if 'man_order_no' in vals and vals['man_order_no']:
            vals['man_order_no'] = vals['man_order_no'].upper()
        if 'vehicle_no' in vals and vals['vehicle_no']:
            vals['vehicle_no'] = vals['vehicle_no'].upper()
        if 'site' in vals and vals['site']:
            vals['site'] = vals['site'].upper()
        res = super(WaybillQwebReport, self).create(vals)

        return res

    def write(self, vals):
        if 'man_order_no' in vals and vals['man_order_no']:
            vals['man_order_no'] = vals['man_order_no'].upper()
        if 'vehicle_no' in vals and vals['vehicle_no']:
            vals['vehicle_no'] = vals['vehicle_no'].upper()
        if 'site' in vals and vals['site']:
            vals['site'] = vals['site'].upper()

        res = super(WaybillQwebReport, self).write(vals)
        return res


class WaybillStockMoveInherit(models.Model):
    _inherit = 'stock.move'

    serial_no = fields.Integer(string='S/N')
    length = fields.Char(string='Length (In Mtr)')
    initial_demand = fields.Float(string='Initial Demand ', readonly=True)
    balance = fields.Float(readonly=True, compute='_compute_balance',
                                store=True)

    @api.model_create_multi
    def create(self, vals_list):
        counter = 0
        for vals in vals_list:
            # logging.info(vals)
            counter += 1
            # logging.info(counter)
            vals['serial_no'] = counter
            # logging.info(vals['serial_no'])
            # logging.info("No back")
            # if self.backorder_id.id is False:
            # logging.info("yes there is")
            vals['initial_demand'] = vals['product_uom_qty']
            if 'rounding_method' in self.env.context and \
                    self.env.context.get('rounding_method') == 'HALF-UP':

                # logging.info("back back")
                # logging.info(counter)
                vals['serial_no'] = self.serial_no
                # logging.info(vals['serial_no'])
                vals['initial_demand'] = self.initial_demand

        res = super(WaybillStockMoveInherit, self).create(vals_list)
        return res

    @api.depends('quantity_done')
    def _compute_balance(self):
        self.balance = 0.0
        for rec in self:
            if not rec.quantity_done == 0.0:
                rec.balance = rec.initial_demand - rec.quantity_done


    


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"
    
    
    def _prepare_procurement_values(self, group_id=False):
        res = super(SaleOrderLine, self)._prepare_procurement_values(group_id)
        res.update({'length': self.xlength})
        return res
        
class StockRule(models.Model):
    _inherit = "stock.rule"
    
    def _get_stock_move_values(self, product_id, product_qty, product_uom,location_id, name, origin, company_id, values):
        res = super(StockRule, self)._get_stock_move_values(product_id, product_qty, product_uom,location_id, name, origin, company_id, values)

        res['length'] = values.get('length', False)
        return res
        
