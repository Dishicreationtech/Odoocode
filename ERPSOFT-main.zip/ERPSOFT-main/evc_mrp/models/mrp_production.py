from odoo import models, fields, api


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    product_length = fields.Float(default=6)
    total_meter = fields.Float(compute='compute_product_measure')
    total_weight = fields.Float(compute='compute_product_measure', store=True)
    attribute_name = fields.Char()

    @api.depends('product_id', 'product_qty', 'product_length')
    def compute_product_measure(self):
        self.total_meter = 0
        self.total_weight = 0
        for rec in self:
            if rec.product_id and rec.product_qty > 0:
                rec.total_meter = rec.product_length * rec.product_qty
                rec.total_weight = rec.total_meter * rec.product_id.weight

    @api.onchange('total_weight', 'product_length')
    def onchange_product_weight(self):
        for mo in self:
            if mo.product_id and mo.bom_id:
                bom_weight = mo.bom_id.total_weight
                actual_weight = mo.total_weight
                for line in mo.move_raw_ids:
                    bom_line = self.env['mrp.bom.line'].search(
                        [('bom_id', '=', mo.bom_id.id), ('product_id', '=', line.product_id.id),
                         ('fix_qty', '=', False)])
                    if len(bom_line) == 1 and bom_line.product_qty > 0 and bom_weight != 0:
                        line.product_uom_qty = (actual_weight * bom_line.product_qty) / bom_weight
                    elif len(bom_line) > 1:
                        for rec in bom_line:
                            record_line = rec.search([('bom_product_template_attribute_value_ids', 'in', mo.product_id.product_template_attribute_value_ids.ids)], limit=1)
                            if record_line and record_line.bom_product_template_attribute_value_ids:
                                line.product_uom_qty = (actual_weight * record_line.product_qty) / bom_weight

    # @api.onchange('product_id', 'product_qty')
    # def onchange_product_length(self):
    #     if self.product_id:
    #         self.product_length = self.product_id.length
