import datetime
from odoo import models, fields, api, _


class MrpPlanningSheet(models.Model):
    _name = 'mrp.planning.sheet'
    _description = 'MRP Planning Sheet'

    name = fields.Char(default='New', copy=False, required=True, readonly=True)
    date = fields.Date()
    workorder_count = fields.Integer(compute='compute_view_workorder')
    workorder_done_count = fields.Integer(copmute='compute_view_workorder')
    mo_ids = fields.Many2many('mrp.production')
    delivery_count = fields.Integer(string='Delivery Orders', compute='compute_picking_ids')
    is_approve = fields.Boolean(compute='compute_approve_button')
    is_plan = fields.Boolean(compute='compute_plan_button')

    @api.depends('mo_ids', 'mo_ids.state')
    def compute_approve_button(self):
        self.is_approve = False
        for rec in self:
            state = rec.mo_ids.filtered(lambda line: line.state == 'confirmed')
            if len(rec.mo_ids) == len(state):
                rec.is_approve = True

    @api.depends('mo_ids', 'mo_ids.state')
    def compute_plan_button(self):
        self.is_plan = False
        for rec in self:
            state = rec.mo_ids.filtered(lambda line: line.state == 'finance')
            if len(rec.mo_ids) == len(state):
                rec.is_plan = True

    @api.depends('mo_ids.procurement_group_id')
    def compute_picking_ids(self):
        for sheet in self:
            picking_ids = []
            for order in sheet.mo_ids:
                pickings = self.env['stock.picking'].search([
                    ('group_id', '=', order.procurement_group_id.id), ('group_id', '!=', False),
                ])
                for picking in pickings:
                    picking_ids.append(picking.id)
            if picking_ids:
                sheet.delivery_count = len(picking_ids)
            return {
                'name': _('Transfers'),
                'type': 'ir.actions.act_window',
                'view_mode': 'tree,form',
                'view_id': False,
                'views': [(self.env.ref('stock.vpicktree').id, 'tree'),
                          (self.env.ref('stock.view_picking_form').id, 'form')],
                'res_model': 'stock.picking',
                # 'context': {'search_default_ready': True},
                'res_id': sheet.id,
                'domain': [('id', 'in', picking_ids)],
                'target': 'current',
            }

    @api.model
    def create(self, vals):
        if vals.get('name', '/') == '/':
            vals['name'] = self.env['ir.sequence'].next_by_code('mrp.planning.sheet') or '/'
        return super(MrpPlanningSheet, self).create(vals)

    def approve_mos(self):
        for rec in self:
            for line in rec.mo_ids:
                line.finance_approve()

    def plan_mos(self):
        for rec in self:
            for line in rec.mo_ids:
                line.button_plan()

    @api.depends('mo_ids.workorder_ids', 'mo_ids.workorder_ids.state')
    def compute_view_workorder(self):
        for rec in self:
            workorder = []
            done_workorder = 0
            for mo in rec.mo_ids:
                for line in mo.workorder_ids:
                    if line.state == 'done':
                        done_workorder += 1
                    workorder.append(line.id)
            rec.workorder_count = len(workorder)
            rec.workorder_done_count = done_workorder
            return {
                'name': _('WorkOrders'),
                'type': 'ir.actions.act_window',
                'view_mode': 'tree,form',
                'view_id': False,
                'views': [(self.env.ref('mrp.mrp_production_workorder_tree_view_inherit').id, 'tree'), (self.env.ref('mrp.mrp_production_workorder_form_view_inherit').id, 'form')],
                'res_model': 'mrp.workorder',
                'context': {'search_default_ready': True},
                'res_id': rec.id,
                'domain': [('id', 'in', workorder)],
                'target': 'current',
            }


class MRPProduction(models.Model):
    _inherit = 'mrp.production'

    sheet_id = fields.Many2one('mrp.planning.sheet')

    def create_mrp_sheet(self):
        mos = []
        for rec in self:
            if not rec.sheet_id:
                mos.append(rec.id)
        if mos:
            planning_sheet = self.env['mrp.planning.sheet'].create(
                {'date': datetime.datetime.today().date(), 'mo_ids': mos})
            if planning_sheet:
                for mo in mos:
                    mo_id = self.env['mrp.production'].browse(mo)
                    mo_id.write({'sheet_id': planning_sheet.id})
