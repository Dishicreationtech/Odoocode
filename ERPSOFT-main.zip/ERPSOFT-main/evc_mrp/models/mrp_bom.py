from odoo import models, fields, api


class MrpProduction(models.Model):
    _inherit = 'mrp.bom'

    product_length = fields.Float()
    total_meter = fields.Float(compute='compute_product_measure')
    total_weight = fields.Float(compute='compute_product_measure')

    @api.onchange('product_tmpl_id', 'product_qty')
    def onchange_product_length(self):
        if self.product_tmpl_id:
            self.product_length = self.product_tmpl_id.length

    @api.depends('product_tmpl_id', 'product_qty', 'product_length')
    def compute_product_measure(self):
        self.total_meter = 0
        self.total_weight = 0
        for rec in self:
            if rec.product_tmpl_id and rec.product_qty > 0:
                rec.total_meter = rec.product_length * rec.product_qty
                rec.total_weight = rec.total_meter * rec.product_tmpl_id.weight


class MrpBomLine(models.Model):
    _inherit = 'mrp.bom.line'

    fix_qty = fields.Boolean()
