# -*- coding: utf-8 -*-
{
    'name': 'EV MRP',
    'version': '15.0',
    'category': 'MRP',
    'license': 'LGPL-3',
    'depends': ['mrp', 'products_additional_fields', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/mrp_planning_sheet_sequence.xml',
        'views/mrp_planning_sheet_views.xml',
        'views/mrp_form_view.xml',
        'views/mrp_bom_form_view.xml',
        'report/report_menu_view.xml',
        'report/report_planning_sheet.xml',
    ],
    'application': True,
    'installable': True,
    'auto_install': False
}
