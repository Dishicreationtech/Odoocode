# -*- coding: utf-8 -*-
{
    'name': "EBM Manufacturing Production (Approval)",

    'summary': """
       This module is affects cbi manufacturing""",

    'description': """

    """,

    'author': 'erpSOFTapp <support@erpsoftapp.com>',
    'website': 'http://www.erpsoftapp.com',

    'category': 'Manufacturing',
    'version': '13.0.0.0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'mrp'],

    # always loaded
    'data': [
        'security/flow_security.xml',
        'security/ir.model.access.csv',
        'data/sub_type.xml',

        'views/views.xml',

    ],
    # only loaded in demonstration mode
    'demo': [

    ],
}
