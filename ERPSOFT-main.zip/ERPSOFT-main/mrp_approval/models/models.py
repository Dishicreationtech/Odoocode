# -*- coding: utf-8 -*-

import logging
from odoo import fields, models


class ManufacturingFlow(models.Model):
    _inherit = 'mrp.production'

    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('finance', 'Finance Approved'),
        ('planned', 'Planned'),
        ('progress', 'In Progress'),
        ('to_close', 'To Close'),
        ('done', 'Done'),
        ('cancel', 'Cancelled')],
        compute='_compute_state', copy=False, index=True, readonly=True,
        store=True, tracking=True,
        help=" * Draft: The MO is not confirmed yet.\n"
             " * Confirmed: The MO is confirmed, the stock rules and the"
             " reordering of the components are trigerred.\n"
             " * Planned: The WO are planned.\n"
             " * In Progress: The production has started"
             " (on the MO or on the WO).\n"
             " * To Close: The production is done, the MO has to be closed.\n"
             " * Done: The MO is closed, the stock moves are posted. \n"
             " * Cancelled: The MO has been cancelled, can't"
             " be confirmed anymore.")

    # @api.multi
    def finance_approve(self):
        orders_to_confirm = self.filtered(lambda order:
                                          order.state == 'confirmed')
        logging.info("I am approve")
        logging.info(orders_to_confirm.state)
        return orders_to_confirm.write({'state': 'finance'})
        # for rec in self:
        #     logging.info(rec.state)
        #     logging.info(rec.routing_id)
        #     if rec.state == 'confirmed':
        #         logging.info("I am True")
        #         rec.write({'state': 'finance'})

    # @api.multi
    def button_plan(self):
        """ override function to change tge filter condition. """
        orders_to_plan = self.filtered(lambda order: order.routing_id and
                                       order.state == 'finance')
        for order in orders_to_plan:
            qty = order.product_uom_id. \
                _compute_quantity(order.product_qty,
                                  order.bom_id.product_uom_id) / \
                order.bom_id.product_qty
            boms, lines = order.bom_id.explode(order.product_id, qty,
                                               picking_type=order.bom_id.
                                               picking_type_id)
            order._generate_workorders(boms)
            order._plan_workorders()
        return orders_to_plan.write({'state': 'planned'})

    # @api.multi
    def _track_subtype(self, init_values):
        self.ensure_one()
        if 'state' in init_values and self.state == 'finance':
            return self.env.ref('mrp_approval.mt_mrp_approved_one')
            # return 'mrp_approval.mt_mrp_approved_one'
        return super(ManufacturingFlow, self)._track_subtype(init_values)
