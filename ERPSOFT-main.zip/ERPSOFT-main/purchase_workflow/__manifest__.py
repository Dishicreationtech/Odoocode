# -*- coding: utf-8 -*-
{
    'name': "Purchase Approval Monetary With Limit",

    'summary': """
       Activate purchase workflow with monetary limit""",

    'description': """
       This module activates purchase workflow and monetary limits in purchase order 
    """,

    'author': 'erpSOFTapp',
    'website': 'http://www.erpsoftapp.com',

    'category': 'Purchase',
    'version': '13.0.0.0.1',

    'depends': ['base', 'hr', 'purchase'],

    'data': [
        'views/views.xml',
        'security/security.xml',
        'security/ir.model.access.csv',

    ],
    'demo': [

    ],


}
