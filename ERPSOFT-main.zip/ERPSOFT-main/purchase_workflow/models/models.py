from odoo import fields, models, api, _
from odoo.exceptions import UserError
from odoo.http import request
from odoo import sql_db
from odoo.api import Environment
from odoo import SUPERUSER_ID



class ResCompany(models.Model):

    _inherit = 'res.company'

    additional_po_workflow = fields.Boolean(default=False)
    direct_approvals = fields.Boolean( default=False)
    multiple_po_types = fields.Boolean( default=False)

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    additional_po_workflow = fields.Boolean( default=False, readonly=False, related='company_id.additional_po_workflow')
    direct_approvals = fields.Boolean(default=False, readonly=False, related='company_id.direct_approvals', help='If active, POs will move directly from ‘To Approve’ status to the correct approver based on the monetary limit set')
    multiple_po_types = fields.Boolean(default=False, readonly=False,
                                       related='company_id.multiple_po_types')

class POType(models.Model):

    _name = 'purchase.order.approval.type'
    _description = 'Purchase Order Approval Types'

    name = fields.Char(string='PO type', required=True)
    active = fields.Boolean(default=False)


class PurchaseOrder(models.Model):

    _inherit = 'purchase.order'

    state = fields.Selection([
        ('initiation', 'Initiation'),
        ('draft', 'RFQ'),
        ('sent', 'RFQ Sent'),
        ('to approve', 'To Approve'),
        ('custom_state', 'Awaiting Approval'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, index=True, copy=False, default='initiation', tracking=True)


    hide_custom_state_button = fields.Boolean(default=False, compute='_compute_hide_custom_state_button')
    show_po_type = fields.Boolean(compute='_compute_po_type' )
    additional_po = fields.Boolean(compute='_compute_additional_po')
    direct_approvals = fields.Boolean(compute='_compute_direct_approvals')
    lock_po_type = fields.Boolean()
    po_type = fields.Many2one('purchase.order.approval.type', required=False, domain=[('active', '=', True)])
    custom_state_ids = fields.One2many('purchase.order.approval.state', 'order_id')

    def button_confirm(self):
        #if self.env.user.has_group('purchase_workflow.group_purchase_po_approval_two') or self.env.user.has_group('purchase_workflow.group_purchase_po_approval_three') or\
        #        self.env.user.has_group('purchase_workflow.group_purchase_po_approval_four') or self.env.user.has_group('purchase.group_purchase_manager'):
        #    raise UserError(_('Only Approval 1 and User can confirm order!'))
        if not self.env.user.company_id.additional_po_workflow:
            return super().button_confirm()
        for order in self:
            if order.state not in ['draft', 'sent']:
                continue
            order._add_supplier_to_product()
            order.write({'state': 'to approve'})
            order.create_approval()
        return True


    @api.depends('state')
    def _compute_hide_custom_state_button(self):
        custom_state = self.custom_state_ids.filtered("current_state")
        if custom_state:
            if custom_state[0].approval_id.security_role_id.id in self.env.user.groups_id.ids:
                self.hide_custom_state_button = False
                return
        self.hide_custom_state_button = True

    def button_approve(self, force=False):
        #if force != 0:
        #     if  self.env.user.has_group('purchase_workflow.group_purchase_po_approval_two') or self.env.user.has_group('purchase_workflow.group_purchase_po_approval_three') or\
        #        self.env.user.has_group('purchase_workflow.group_purchase_po_approval_four') or self.env.user.has_group('purchase.group_purchase_manager'):
        #        raise UserError(_('Only Approval 1 can approve at this stage !'))        
        for order in self:
            if self.env.company.direct_approvals and order.custom_state_ids.filtered("approved"):

                return  super().button_approve(force=force)
            #print(order.custom_state_ids.sorted(lambda r: r.approval_id.sequence))
            for cus_state in order.custom_state_ids.sorted(lambda r: r.approval_id.sequence):
                #print(cus_state.approval_id.sequence)
                converted_amount = self.env.company.currency_id._convert(
                                cus_state.approval_id.monetary_limit, cus_state.approval_id.currency_id, cus_state.approval_id.company_id, order.date_order or fields.Date.today())
                #print(converted_amount)
                #print(cus_state.approved)
                if cus_state.approved and converted_amount >= order.amount_total:
                    break
                if not cus_state.approved and self.env.company.direct_approvals and order.amount_total < converted_amount:
                    order.message_post(body='Awaiting Approval <b>{}</b>'.format(cus_state.approval_id.label))
                    #order.update_custom_state(cus_state.approval_id.label)
                    #print(cus_state.approval_id.sequence)
                    #print(cus_state.approval_id.label)
                    cus_state.write({'approved': True, 'current_state': True})
                    return order.write({'state': 'custom_state'})
                elif not cus_state.approved and not self.env.company.direct_approvals:
                    order.message_post(body='Awaiting Approval <b>{}</b>'.format(cus_state.approval_id.label))
                    # order.update_custom_state(cus_state.approval_id.label)
                    # print(cus_state.approval_id.sequence)
                    # print(cus_state.approval_id.label)
                    cus_state.write({'approved': True, 'current_state': True})
                    return order.write({'state': 'custom_state'})
        self.custom_state_ids.write({'current_state': False})
        return super().button_approve(force=force)

    def action_approve_custom(self):
        return self.button_approve()

    @api.depends('company_id')
    def _compute_po_type(self):

        self.show_po_type =  self.company_id.multiple_po_types

    @api.depends('company_id')
    def _compute_additional_po(self):
        self.additional_po =  self.company_id.additional_po_workflow

    @api.depends('company_id')
    def _compute_direct_approvals(self):
        self.direct_approvals =  self.company_id.direct_approvals

    @api.model
    def update_custom_state(self, name):
        selection_field = self.env['ir.model.fields'].sudo().search(
            [('name', '=', 'state'), ('model_id.name', '=', 'Purchase Order')], limit=1)
        self._cr.execute(
            " UPDATE ir_model_fields_selection SET name='%s' WHERE field_id=%s AND value='%s';" % (name, selection_field.id,'custom_state'))
    
    def create_approval(self):
        domain = None
        if self.po_type:
            domain = [('po_type', '=', self.po_type.id)]
        approvals = self.env['purchase.order.approval'].sudo().search(domain or [],  order="sequence asc")

        approval_list = []
        for approve in approvals:
            approval_list.append((0, 0 , {'approval_id' : approve.id}))
        self.write({'custom_state_ids': approval_list, 'lock_po_type': True})

    @api.model
    def create(self, vals):
        if self.env.user.company_id.additional_po_workflow and not self.env.user.has_group('purchase_workflow.group_purchase_initiation'):
            raise UserError(_('Only purchase initiation user can create !'))
        return super(PurchaseOrder, self).create(vals)


    def action_approve_init(self):

        self.write({'state': 'draft'})


class PurchaseOrderApproval(models.Model):

    _name = 'purchase.order.approval.state'
    _description = 'Approval State'

    order_id = fields.Many2one('purchase.order', string='Order Reference', index=True, required=True,
                               ondelete='cascade')
    approval_id = fields.Many2one('purchase.order.approval')
    approved = fields.Boolean(default=False)
    current_state = fields.Boolean(default=False)

    def write(self, vals):
        if  vals.get('current_state'):
            other_states = self.env['purchase.order.approval.state'].search([('order_id', '=', self.order_id.id), ('id', '!=', self.id)])
            other_states.write({'current_state': False})
        return super().write(vals)



class POApproval(models.Model):

    _name = 'purchase.order.approval'
    _description = 'Purchase Order Approval'
    _rec_name = 'label'

    # _sql_constraints = [
    #     ('unique_security_company', 'unique (security_role_id,company_id,po_type )', 'Security role must be unique per company per po type !')
    # ]

    def _get_group_domain(self):
        return [('category_id', '=', self.env.ref('base.module_category_operations_purchase').id)]

    company_id = fields.Many2one('res.company', string='Company', default= lambda self: self.env.user.company_id, required=True)
    security_role_id = fields.Many2one('res.groups', domain=_get_group_domain, required=True)
    label = fields.Char(required=True)
    sequence = fields.Integer(readonly=True)
    monetary_limit = fields.Monetary(required=True)
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda self: self.env.user.company_id.currency_id)
    active = fields.Boolean(default=False)
    show_po_type = fields.Boolean(compute='_compute_po_type')
    po_type = fields.Many2one('purchase.order.approval.type',  domain=[('active', '=', True)])

    @api.depends('company_id')
    def _compute_po_type(self):
        if self.company_id:
            self.show_po_type = self.company_id.multiple_po_types

    def write(self, vals):
        for rec in self:
            if 'monetary_limit' in vals:
                domain = [('company_id.id', '=', rec.company_id.id)]
                if vals.get('po_type'):
                    domain.append(('po_type', '=', vals['po_type']))
                domain.append(('active', '=', True))
                prev_money = self.env['purchase.order.approval'].sudo().search(domain + [('sequence', '>', rec.sequence), ('monetary_limit', '<=', vals['monetary_limit'])])
                if len(prev_money.ids) > 0:
                    raise UserError(_('Monetary limits cannot be greater than previous monetary limit with higher sequence!'))
                prev_money = self.env['purchase.order.approval'].sudo().search(
                    domain + [('sequence', '<', rec.sequence), ('monetary_limit', '>=', vals['monetary_limit'])])
                if len(prev_money.ids) > 0:
                    raise UserError(_('Monetary limits cannot be lower than previous monetary limit !'))

        ret = super(POApproval, self).write(vals)
        if 'active' in vals:
            self.reset_sequence()
        self.update_employee_limit()
        return ret

    def update_employee_limit(self):
        users_id = []
        for rec in self.env['purchase.order.approval'].sudo().search([('active','=', True)], order='monetary_limit DESC'):
            users = self.env['res.users'].search([('groups_id', '=', rec.security_role_id.id)])
            users = [user.id for user in users if user.id not in users_id]
            if not users:
                continue
            users_id.extend(users)
            employees = self.env['hr.employee'].search([('user_id', 'in', users)])
            employees._compute_purchase_role(rec)


    @api.model
    def create(self, vals):

        domain = [('company_id.id', '=', vals['company_id'])]
        if vals.get('po_type'):
            domain.append(('po_type', '=', vals['po_type']))
        domain.append(('active', '=', True))
        money_domain = domain.copy()
        money_domain.append(('monetary_limit', '>=', vals['monetary_limit']))
        prev_money = self.env['purchase.order.approval'].sudo().search(money_domain)
        if len(prev_money.ids) > 0:
            raise UserError(_('Monetary limits cannot be lower than previous monetary limit !'))

        prev_active_po = self.env['purchase.order.approval'].sudo().search(domain, order="create_date asc")

        domain[-1] = ('active', '=', False)

        prev_inactive_po = self.env['purchase.order.approval'].sudo().search(domain, order="create_date asc")

        vals['sequence'] = len(prev_inactive_po.ids)+len(prev_active_po.ids)+1
        ret = super(POApproval, self).create(vals)
        self.update_employee_limit()
        self.reset_sequence()
        return ret

    def _reset(self):
        index = 1
        for po in self:
            po.write({'sequence': index})
            index += 1
    def reset_sequence(self):
        prev_po = self.env['purchase.order.approval'].sudo().search([('active', '=', True), ('po_type', '=', False)], order="create_date asc")
        prev_po._reset()
        po_types = self.env['purchase.order.approval.type'].sudo().search([('active', '=', True)])
        for typ in po_types:
            prev_po = self.env['purchase.order.approval'].sudo().search([('active', '=', True), ('po_type', '=', typ.id)],
                                                                 order="create_date asc")
            prev_po._reset()


    def unlink(self):
        ret = super(POApproval, self).unlink()
        # for approval in self:
        #     domain = [('company_id.id', '=', approval.company_id.id), ('sequence' , '>',approval.sequence )]
        #     if approval.po_type:
        #         domain.append(('po_type', '=', approval.po_type.id))
        self.reset_sequence()
        self.update_employee_limit()
        return ret


class HrEmployeePrivate(models.Model):

    _inherit = 'hr.employee'

    purchase_role = fields.Char()
    monetary_limit = fields.Monetary()
    currency_id = fields.Many2one('res.currency', string='Currency')

    def _compute_purchase_role(self, order_approval):
    #     groups = self.env['res.groups'].search([('category_id', '=', self.env.ref('base.module_category_operations_purchase').id)])
    #
    #     user_groups = [group.id for group in groups if group.id in self.user_id.groups_id.ids]
    #     order_approval = self.env['purchase.order.approval'].search([('security_role_id.id', 'in', user_groups)], limit=1, order='monetary_limit DESC')

        if order_approval:
            for rec in self:
                print(order_approval.security_role_id.name)
                rec.monetary_limit = order_approval.monetary_limit
                rec.purchase_role = order_approval.security_role_id.name
                rec.currency_id = order_approval.currency_id

