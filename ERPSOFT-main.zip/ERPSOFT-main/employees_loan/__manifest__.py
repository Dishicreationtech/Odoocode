# -*- coding: utf-8 -*-

{
    'name': 'Employees Loan',
    'version': '13.0.0.0.0',
    'category': 'Employee',
    'summary': 'Automatic calculation of employee loan repayment',
    'description': """
Employees Loan
==============
This module enables the automatic calculation of employee loan repayment and other related loan
""",
    'author': 'erpSOFTapp',
    'website': "https://www.erpsoftapp.com",
    'depends': [
                'account'
                ,'hr_payroll_account','payroll_staff_deductions'
        ],
    'data': [
        'view/view.xml',
        'security/ir.model.access.csv'
        ],
    'demo': [

        ],
    'test': [],
    'installable': True,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
