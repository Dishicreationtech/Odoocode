import calendar
from datetime import datetime, timedelta
from dateutil.relativedelta import *
from odoo import fields, models, api, _
from odoo.exceptions import UserError
import logging

logger = logging.getLogger(__name__)

class HRContract(models.Model):

    _inherit = 'hr.contract'

    esa_terminate_loan = fields.Boolean('Terminate Loan', track_visibility="onchange")
    interest_rate = fields.Float()
    interest_payment = fields.Float(related='current_amortized_id.interest_payment', readonly=True)
    loan_repayment = fields.Monetary(related='current_amortized_id.loan_repayment', readonly=True)
    loan_balance = fields.Monetary(related='current_amortized_id.loan_balance', readonly=True)
    esa_end_date = fields.Date(string='End Date', compute='_compute_end_date', store=True)
    esa_monthly_payment = fields.Monetary('Monthly Payment', default=0.0,
                                       help="The Monthly Payment", compute='_compute_principal')
    principal_amount = fields.Monetary(compute='_compute_principal', store=True)
    monthly_interest_payment = fields.Monetary(compute='_compute_principal', store=True)
    loan_monthly_payment = fields.Monetary(compute='_compute_principal', store=True)
    amortization_ids = fields.One2many('hr.loan.amortization', 'contract_id', compute='_compute_amor_table', store=True, readonly=False)
    current_amortized_id = fields.Many2one('hr.loan.amortization')

    @api.depends('esa_start_date', 'esa_number_of_payments')
    def _compute_end_date(self):
        for rec in self:
            if rec.esa_start_date and rec.esa_number_of_payments:
                rec.esa_end_date = rec.esa_start_date + relativedelta(months=rec.esa_number_of_payments-1)
            else:
                rec.esa_end_date = None
    @api.onchange('esa_terminate_loan')
    def _onchange_loan(self):
       for rec in self:
          if rec.esa_terminate_loan:
             rec.esa_active_flg = False

    @api.depends('esa_loan_amount', 'esa_number_of_payments', 'interest_rate')
    def _compute_principal(self):
        for rec in self:
            if rec.esa_loan_amount and rec.esa_number_of_payments and rec.interest_rate:
                rec.principal_amount = rec.esa_loan_amount/ rec.esa_number_of_payments
                rec.monthly_interest_payment = ((((rec.interest_rate * 0.01) / 12) * rec.principal_amount) / rec.esa_number_of_payments) * 100
                rec.loan_monthly_payment = rec.principal_amount + rec.monthly_interest_payment
                interest_payment_percen = rec.interest_rate * 0.01
                f_ineres = 1+ (interest_payment_percen / 12 )
                mid_percen = f_ineres ** (-1 * rec.esa_number_of_payments)
                monthly_payment =  ((1 - mid_percen) / (interest_payment_percen / 12))
                monthly_payment = rec.esa_loan_amount / monthly_payment
                rec.esa_monthly_payment = monthly_payment
            else:
                rec.principal_amount = 0
                rec.monthly_interest_payment = 0
                rec.loan_monthly_payment = 0
                rec.esa_monthly_payment = 0


    def amortization_value(self):
        for rec in self:
            if rec.esa_active_flg and rec.interest_rate and rec.esa_number_of_payments and rec.esa_start_date:
                amors = []
                amors.append((0, 0, {'start_date': datetime.today(), 'period_month': 0, 'loan_balance': rec.esa_loan_amount}))
                principal = rec.principal_amount
                monthly_payment = rec.esa_monthly_payment
                initial_bal = rec.esa_loan_amount
                rec.amortization_ids.unlink()
                for period in range(rec.esa_number_of_payments):
                    #monthly_payment = principal + monthly_interest_payment
                    interest_payment =   ((rec.interest_rate * 0.01) / 12) * initial_bal#(rec.esa_number_of_payments - period)) * principal
                    loan_repayment = monthly_payment - interest_payment
                    loan_balance =  initial_bal - loan_repayment
                    if loan_balance <= 0:
                        loan_balance = 0
                    initial_bal = loan_balance
                    #print(monthly_payment, interest_payment, loan_repayment, loan_balance, initial_bal)
                    date = rec.esa_start_date + relativedelta(months=period)
                    last_date = calendar.monthrange(date.year, date.month)[1]
                    date = date.replace(day=last_date)
                    amors.append((0, 0, {'start_date': date, 'period_month': period+1,
                                         'monthly_payment': monthly_payment, 'month': date.month, 'year': date.year,
                                         'interest_payment': interest_payment,
                                         'loan_repayment': loan_repayment, 'loan_balance': loan_balance} ))
                rec.write({'amortization_ids': amors})
            else:
                #rec.amortization_ids.unlink()e
                rec.amortization_ids = []
        self.set_current_amor()

    def _cron_update(self):
        for contract in self.env['hr.contract'].sudo().search([('esa_active_flg','=', True)]):
            date = datetime.today()
            amor = self.env['hr.loan.amortization'].search([('month', '=', date.month),('year', '=', date.year)], limit=1)
            logger.info('Found amor %s balance %s for contract %s'%(amor, amor.loan_balance, contract.id))
            if amor:
                contract.write({'current_amortized_id': amor.id})
                if amor.loan_balance == 0:
                    contract.write({'esa_terminate_loan': True, 'esa_active_flg': False})

    @api.depends('esa_active_flg')
    def _compute_amor_table(self):
        self.amortization_value()

    def set_current_amor(self):
        if len(self.amortization_ids.ids) > 1:
            self.write({'current_amortized_id': self.amortization_ids[1].id})

    @api.model
    def create(self, vals):

        res = super(HRContract, self).create(vals)
        if vals.get('esa_active_flg'):
            self.env['loan.history'].create({'employee': vals.get('employee_id'), 'contract': res.id, 'interest_rate': res.interest_rate,'principal_amount': res.esa_loan_amount,
                                             'start_date': res.esa_start_date, 'end_date': res.esa_end_date, 'currency_id': res.currency_id.id,'repayment': res.esa_monthly_payment})
        return res

    def write(self, vals):
        res = super(HRContract, self).write(vals)
        history = self.env['loan.history'].search([('contract','=', self.id)], limit=1)
        if vals.get('esa_active_flg') and not history:
            self.env['loan.history'].create({'employee': vals.get('employee_id') or self.employee_id.id, 'contract': self.id, 'interest_rate': vals.get('interest_rate') or self.interest_rate,
                                             'start_date': vals.get('esa_start_date') or self.esa_start_date, 'end_date': vals.get('esa_end_date') or self.esa_end_date, 'currency_id': vals.get('currency_id') or self.currency_id.id,
                                             'repayment': vals.get('esa_monthly_payment') or self.esa_monthly_payment ,'principal_amount': self.esa_loan_amount
                                             })
        return res

class HRAmortizationTable(models.Model):

    _name = 'hr.loan.amortization'
    _description = 'Amortization Table'

    monthly_payment = fields.Monetary()
    loan_repayment = fields.Monetary()
    loan_balance = fields.Monetary()
    interest_payment = fields.Float()
    period_month = fields.Integer(string='Period (Months)')
    start_date = fields.Date()
    month = fields.Integer()
    year = fields.Integer()
    move_id = fields.Many2one('account.move')
    status = fields.Selection([('draft', 'Draft'), ('paid', 'Paid')], default='draft')
    contract_id = fields.Many2one('hr.contract')
    currency_id = fields.Many2one('res.currency', related='contract_id.currency_id', readonly=True)

    def set_to_draft(self):
        self.write({'status': 'draft'})
        if self.move_id:
            self.move_id.button_draft()


class AccountPayslip(models.Model):
#
    _inherit = 'hr.payslip'

    def refund_sheet(self):
        res = super(AccountPayslip, self).refund_sheet()
        for rec in self:
            if rec.contract_id.esa_active_flg and rec.state == 'done':
                raise UserError(_('You cannot refund a payslip linked to a loan. First unreconcile the loan'))
        return res
    #
    # def action_payslip_done(self):
    #     res = super(AccountPayslip, self).action_payslip_done()
    #     amor = self.env['hr.loan.amortization'].search([('start_date','=', self.date_from), ('contract_id', '=', self.contract_id.id)], limit=1)
    #     if amor:
    #         self.contract_id.write({'current_amortized_id':amor.id})
    #         if amor.loan_balance == 0:
    #             self.contract_id.write({'esa_terminate_loan': True, 'esa_active_flg': False})
    #     return res

class LoanHistory(models.Model):
    _name = 'loan.history'
    _description = 'Loan History Record'

    employee = fields.Many2one('hr.employee')
    contract = fields.Many2one('hr.contract')
    principal_amount = fields.Monetary()
    repayment = fields.Monetary()
    start_date = fields.Date()
    end_date = fields.Date()
    currency_id = fields.Many2one('res.currency')
    interest_rate = fields.Float()

class AccounMove(models.Model):

    _inherit = 'account.move'

    def action_post(self):
        res = super(AccounMove, self).action_post()
        slip = self.env['hr.payslip'].search([('move_id','=', self.id)], limit=1)
        if slip:
            if slip.contract_id and slip.contract_id.esa_active_flg:
                amor = self.env['hr.loan.amortization'].search([('start_date', '=', self.date), ('contract_id', '=', slip.contract_id.id)],
                                                               limit=1)
                if amor:
                    first_amor = self.env['hr.loan.amortization'].search(
                        [('period_month', '=', 0), ('contract_id', '=', slip.contract_id.id)],
                        limit=1)
                    if first_amor:
                        first_amor.write({'status':'paid'})
                    amor.write({'status':'paid', 'move_id': self.id})
                    if amor.loan_balance == 0:
                        slip.contract_id.write({'esa_terminate_loan': True, 'esa_active_flg': False})
                    else:
                        next_amor = self.env['hr.loan.amortization'].search(
                            [('period_month', '=', amor.period_month + 1), ('contract_id', '=', slip.contract_id.id)],
                            limit=1)
                        if next_amor:
                            slip.contract_id.write({'current_amortized_id': next_amor.id})

        return res
